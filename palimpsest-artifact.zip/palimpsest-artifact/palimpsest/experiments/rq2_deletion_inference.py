"""Experiment B (RQ2, Fig. 5): deletion inference, sweeping k.

Targets come from a population DISJOINT from the background (see
common.di_population), so the H0 world never contains a target's records and
each k in the sweep is a real number of deleted records.
"""
from __future__ import annotations
import numpy as np

from ..config import Config
from ..systems import HnswlibSUT, FaissSUT
from ..defense import LSEDSystem
from ..attacks import run_deletion_inference
from .common import setup, di_population, make_native_hnsw, make_lsed
from . import save_json


def make_di_system(name: str, cfg: Config, llm, emb):
    if name == "hnswlib":
        return make_native_hnsw(cfg, emb, "mark_deleted")
    if name == "hnswlib-rebuild":
        return make_native_hnsw(cfg, emb, "rebuild")
    if name == "faiss-ivfpq":
        # train_size fixes the PQ/IVF geometry so the deletion world and the
        # counterfactual world train identically-shaped codebooks; the attack
        # then measures codebook RESIDUE, not a parameter-size artifact.
        ts = cfg.attack.di_background_docs
        return lambda: FaissSUT(emb, emb.dim, kind="ivfpq", deletion_option="remove_ids",
                                train_size=ts, nprobe=cfg.index.ivf_nprobe)
    if name == "faiss-ivfpq-rebuild":
        # full rebuild: retrain the codebook on the surviving records
        ts = cfg.attack.di_background_docs
        return lambda: FaissSUT(emb, emb.dim, kind="ivfpq", deletion_option="rebuild",
                                train_size=ts, nprobe=cfg.index.ivf_nprobe)
    if name == "lsed":
        # DI observes ranks/scores of the retrieval layer only
        return make_lsed(cfg, llm, emb, retrieval_only=True)
    raise ValueError(f"unknown DI system {name!r}")


def di_sweep(cfg: Config, system: str, ks, llm=None, emb=None, subjects=None) -> dict:
    if llm is None:
        llm, emb, subjects = setup(cfg)
    if cfg.attack.di_n_subjects and cfg.attack.di_n_subjects > len(subjects):
        from ..canaries import build_population
        subjects = build_population(cfg.attack.di_n_subjects, cfg.data.docs_per_subject,
                                    cfg.data.canary_facts_per_doc, cfg.data.seed,
                                    subjects_per_manager=cfg.data.subjects_per_manager)
    ks = [int(k) for k in ks]
    # The target population is fixed by the CONFIG, not by this call's ks, so
    # every experiment (RQ2 sweep, RQ3 comparison) attacks the same subjects.
    pop_k = max(max(ks), max(int(x) for x in cfg.attack.records_per_subject))
    bg_docs, targets = di_population(cfg, subjects, pop_k)
    make = make_di_system(system, cfg, llm, emb)
    curves = {}
    for k in ks:
        r = run_deletion_inference(
            make, bg_docs, targets, k=k,
            shadow_models=cfg.attack.shadow_models,
            n_probe=cfg.attack.di_probe_queries,
            n_control=cfg.attack.di_control_queries,
            n_sentinels=cfg.attack.di_sentinels, seed=cfg.data.seed + k,
            channels=tuple(cfg.attack.di_channels), null=cfg.attack.di_null)
        curves[k] = {"auc": r.auc, "auc_ci": list(r.auc_ci), "tpr_at_1pct": r.tpr_at_1pct,
                     "tpr_at_5pct": r.tpr_at_5pct, "tpr_at_10pct": r.tpr_at_10pct,
                     "min_fpr": r.min_fpr,
                     "advantage": float(abs(2 * r.auc - 1)) if r.auc == r.auc else None,
                     "scores": r.scores.tolist(), "labels": r.labels.tolist()}
        lo, hi = r.auc_ci
        low_fpr = (f"TPR@1%={r.tpr_at_1pct:.3f}" if r.min_fpr <= 0.01
                   else f"TPR@1%=n/a(min FPR {r.min_fpr:.3f})")
        print(f"[RQ2-DI] {system:15s} null={r.null:5s} k={k:3d} AUC={r.auc:.3f} "
              f"[{lo:.3f},{hi:.3f}] TPR@5%={r.tpr_at_5pct:.3f} TPR@10%={r.tpr_at_10pct:.3f} "
              f"{low_fpr} (n={len(r.labels)})")
    return {"system": system, "n_background": len(bg_docs),
            "channels": list(cfg.attack.di_channels), "null": cfg.attack.di_null,
            "index": {"M": cfg.index.hnsw_M, "ef": cfg.index.hnsw_ef,
                      "ivf_nprobe": cfg.index.ivf_nprobe}, "curves": curves}


def run(cfg: Config, system: str = "hnswlib") -> tuple:
    out = di_sweep(cfg, system, cfg.attack.records_per_subject)
    return save_json(cfg, f"rq2_di_{system}", out), out
