"""Experiment A (RQ1): where does influence persist?

For each SUT, run counterfactual replay over several canary subjects and report,
per tier, the fraction of canaries for which residue is detected. Emits the
marks for Table 3.
"""
from __future__ import annotations
import numpy as np

from ..config import Config
from ..systems import build_registry
from ..replay import run_replay
from .common import setup, background_and_canaries, load_beir_into, hnsw_kw
from . import save_json


def run(cfg: Config, n_canaries: int = 10) -> dict:
    llm, emb, subjects = setup(cfg)
    bg_docs, canaries, _ = background_and_canaries(subjects, n_canaries)
    bg_docs = load_beir_into(bg_docs, cfg)
    registry = build_registry(llm, emb, emb.dim, hnsw_kw=hnsw_kw(cfg),
                              ivfpq_train_size=len(bg_docs))

    out = {"systems": {}}
    for name, make in registry.items():
        t1 = t2 = t3 = 0
        details = []
        for canary in canaries:
            r = run_replay(make, bg_docs, canary, threshold=cfg.replay.effect_threshold)
            t1 += int(r.tier1_copy); t2 += int(r.tier2_struct); t3 += int(r.tier3_semantic)
            details.append(r.detail)
        n = len(canaries)
        out["systems"][name] = {
            "deletion_option": make().deletion_option,
            "tier1_frac": t1 / n, "tier2_frac": t2 / n, "tier3_frac": t3 / n,
        }
        print(f"[RQ1] {name:14s} I={t1}/{n} II={t2}/{n} III={t3}/{n}")
    return save_json(cfg, "rq1_residue", out), out
