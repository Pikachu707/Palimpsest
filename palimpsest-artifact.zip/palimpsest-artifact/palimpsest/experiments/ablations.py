"""Experiments F & G: ablations and the timing side-channel.

F (Fig. 9): sweep the LSED partition count S. More partitions shrink each
   deletion (fewer records to re-insert per partition) but widen query fan-out.
   We record deletion latency and tail (p99) query latency relative to a native,
   unpartitioned index on the same data.
G: timing-only deletion inference against LSED, with and without latency
   padding. Theorem 1 excludes O_time; this measures what padding buys.
"""
from __future__ import annotations
import time
import numpy as np

from ..config import Config
from ..defense import LSEDSystem
from ..systems import HnswlibSUT
from ..stats import auc
from .common import (setup, background_and_canaries, load_beir_into,
                     make_native_hnsw, make_lsed)
from . import save_json


def _p(lats, q):
    return float(np.percentile(np.asarray(lats) * 1000.0, q))


def _query_lats(sut, qs, reps, warmup=10):
    for q in qs[:warmup]:
        sut.query(q, k=10)                         # warm-up: drop first-query outliers
    out = []
    for _ in range(reps):
        for q in qs:
            out.append(sut.query(q, k=10).latency_s)
    return out


def run_ablations(cfg: Config, n_canaries: int = 5, query_reps: int = 100) -> tuple:
    llm, emb, subjects = setup(cfg)
    bg_docs, canaries, _ = background_and_canaries(subjects, n_canaries)
    bg_docs = load_beir_into(bg_docs, cfg)
    qs = [f"Who is {s.name}?" for s in subjects[n_canaries:n_canaries + 10]] or ["who"]

    # native, unpartitioned retrieval baseline for the latency ratio
    native = make_native_hnsw(cfg, emb, "mark_deleted")()
    native.ingest(bg_docs + [d for c in canaries for d in c.docs])
    native_p99 = _p(_query_lats(native, qs, query_reps), 99)

    out = {"native_p99_ms": native_p99, "partition_sweep": {}, "slice_sweep": {}}
    for S in cfg.lsed.s_sweep:
        del_lats, p99s = [], []
        for c in canaries:
            sut = make_lsed(cfg, llm, emb, n_partitions=S, retrieval_only=True)()
            sut.ingest(bg_docs + c.docs)
            t0 = time.perf_counter(); sut.delete([d.doc_id for d in c.docs])
            del_lats.append(time.perf_counter() - t0)
            p99s.append(_p(_query_lats(sut, qs, query_reps), 99))
        rec = {"del_lat_s": float(np.mean(del_lats)),
               "query_p99_ms": float(np.mean(p99s)),
               "p99_x_native": float(np.mean(p99s) / max(native_p99, 1e-9))}
        out["partition_sweep"][int(S)] = rec
        print(f"[ABL-S] S={S:4d} del={rec['del_lat_s']:.3f}s p99={rec['query_p99_ms']:.2f}ms "
              f"({rec['p99_x_native']:.2f}x native)")

    # Slice size only matters when a partition is larger than a slice, so the
    # slice sweep uses ONE partition holding the whole corpus.
    c = canaries[0]
    for cslice in (32, 128, 512):
        sut = make_lsed(cfg, llm, emb, n_partitions=1, slice_size=cslice, retrieval_only=True)()
        sut.ingest(bg_docs + c.docs)
        t0 = time.perf_counter(); sut.delete([d.doc_id for d in c.docs])
        out["slice_sweep"][cslice] = {"del_lat_s": time.perf_counter() - t0}
        print(f"[ABL-c] c={cslice:5d} del={out['slice_sweep'][cslice]['del_lat_s']:.3f}s")
    return save_json(cfg, "ablations", out), out


def _auc_se(a: float, n1: int, n0: int) -> float:
    """Hanley & McNeil (1982) standard error of an AUC estimate."""
    q1 = a / (2 - a); q2 = 2 * a * a / (1 + a)
    v = (a * (1 - a) + (n1 - 1) * (q1 - a * a) + (n0 - 1) * (q2 - a * a)) / (n1 * n0)
    return float(np.sqrt(max(v, 0.0)))


def run_timing_channel(cfg: Config, n_trials: int = 200) -> tuple:
    """Timing-only deletion inference (O_time, which Theorem 1 excludes),
    measured on the RETRIEVAL layer (no LLM, no memo): a conservative upper
    bound, since generation adds noise a remote attacker must average away.

    For each system (native hnswlib with tombstones; LSED) and each padding
    setting, build the deletion world and the counterfactual world, then
    query them INTERLEAVED in random order (sequential measurement confounds
    the comparison with warm-up drift) and report the AUC of latency as a
    deletion detector, with its standard error."""
    from ..systems.base import PaddedSUT
    llm, emb, subjects = setup(cfg)
    # target must NOT be in the background, or the never-ingested world isn't
    bg_docs, canaries, _ = background_and_canaries(subjects, 1)
    subj = canaries[0]
    q = f"Who is {subj.name}?"
    pad = cfg.lsed.pad_quantum_ms if cfg.lsed.pad_partitions else 0.0
    systems = {"native": make_native_hnsw(cfg, emb, "mark_deleted"),
               "lsed": make_lsed(cfg, llm, emb, retrieval_only=True)}
    rng = np.random.default_rng(cfg.data.seed)
    out = {"n_per_world": n_trials, "pad_quantum_ms": pad}
    for sname, make in systems.items():
        for label, pad_ms in (("unpadded", 0.0), ("padded", pad)):
            worlds = {}
            for b in (1, 0):
                sut = make()
                sut.ingest(bg_docs + (subj.docs if b else []))
                if b:
                    sut.delete([d.doc_id for d in subj.docs])
                worlds[b] = PaddedSUT(sut, pad_ms) if pad_ms > 0 else sut
            for w in worlds.values():
                for _ in range(10):
                    w.query(q, k=10)
            order = rng.permutation([1] * n_trials + [0] * n_trials)
            scores = [worlds[int(b)].query(q, k=10).latency_s for b in order]
            a = auc(np.array(scores), order)
            se = _auc_se(a, n_trials, n_trials)
            out[f"{sname}:{label}"] = {"pad_quantum_ms": pad_ms, "timing_auc": a, "auc_se": se,
                                       "timing_advantage": float(abs(2 * a - 1))}
            print(f"[TIMING] {sname:6s} {label:8s} AUC={a:.3f} (+/-{1.96*se:.3f}) "
                  f"adv={abs(2*a-1):.3f}")
    return save_json(cfg, "timing_channel", out), out
