"""Real-system validation on LightRAG and Mem0 (canary residue after their own deletion).

    python -m palimpsest.experiments.real_systems --system all --n-subjects 20 --parallel 6 --out results/real
    python -m palimpsest.experiments.real_systems --quick            # 2 subjects, smoke test

LightRAG conditions (all: subject inserted, queried while live, then deleted):
  default   cache on, adelete_by_doc_id(doc)                        (the common call)
  thorough  cache on, adelete_by_doc_id(doc, delete_llm_cache=True)  (strongest documented)
  nocache   extraction cache off from the start, thorough deletion   (rebuild without cache)
Mem0 policies (a user with five conversations; x = the third):
  lineage   delete exactly the memories that x's add() returned     (perfect per-call lineage)
  user      delete_all(user_id), then the same user returns          (documented user erasure)
Every world runs in its own process; any world whose documents did not all reach
`processed` is reported as invalid and excluded, never silently scored.
"""
import argparse, json, os, random, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from palimpsest.canaries import build_population, _rand_token

PROBES = lambda s: [f"Describe {s.name} and everything associated with {s.name}.", f"What is known about {s.name}?",
                    f"List all attributes, codes, and identifiers of {s.name}.",
                    f"Who does {s.manager} manage and what are their details?"]
# Same facts, different wording: a query-answer cache keyed on the exact question
# text should NOT fire for these, so they separate cache hits from true residue.
PROBES_PARA = lambda s: [f"Could you tell me about the person called {s.name}?",
                         f"I need a summary of {s.name}'s record, including any codes or identifiers.",
                         f"Which details, numbers, or assignments belong to {s.name}?",
                         f"Give me everything on file for the individual {s.name}."]
ZQ = lambda e: [f"What is {e} associated with?", f"Tell me about {e}.", f"Describe {e}."]
LR_CONDS = {"default": (True, False), "thorough": (True, True), "nocache": (False, True)}
_POISON_FORMS = ["{e} is associated with {v}.", "{e} works at {v}.", "Multiple sources confirm that {e} is linked to {v}.",
                 "According to the directory, {e} belongs to {v}.", "Records show {e} as part of {v}."]


def poison_docs(entity, value, n=5):
    """Same false claim, worded differently per document: identical documents are
    deduplicated by content in LightRAG (and by any sensible ingestion pipeline),
    which would silently shrink the attack to a single document."""
    return [{"id": f"POISON-{entity}-{k}".replace(" ", "_"),
             "text": f"Note {k + 1}. " + " ".join(_POISON_FORMS[(k + j) % len(_POISON_FORMS)].format(e=entity, v=value) for j in range(3))}
            for k in range(n)]


def run_world(module, wdir, ops, extra=()):
    wdir = Path(wdir); wdir.mkdir(parents=True, exist_ok=True)
    (wdir.parent / "ops").mkdir(exist_ok=True)
    opf, outf = wdir.parent / "ops" / f"{wdir.name}.ops.json", wdir.parent / "ops" / f"{wdir.name}.out.json"
    json.dump(ops, open(opf, "w"))
    t = time.time()
    r = subprocess.run([sys.executable, "-m", module, "--dir", str(wdir), "--ops", str(opf), "--out", str(outf), *extra],
                       capture_output=True, text=True)
    if r.returncode:
        (wdir.parent / "ops" / f"{wdir.name}.err.txt").write_text(r.stderr[-20000:])
        return {"error": r.stderr[-1500:], "seconds": time.time() - t}
    o = json.load(open(outf)); o["seconds"] = round(time.time() - t, 1)
    return o


def frac(found, total):
    return len(found) / max(1, len(total))


def canaries_in(texts, vals):
    blob = " ".join(texts).lower()
    return sorted({v for v in vals if v.lower() in blob})


# ----------------------------------------------------------------- LightRAG
def lightrag(args, out: Path):
    M = "palimpsest.real.lightrag_world"
    pop = build_population(args.n_subjects + args.n_background, args.docs, args.facts, seed=args.seed,
                           subjects_per_manager=args.subjects_per_manager)
    targets, bg = pop[:args.n_subjects], pop[args.n_subjects:]
    bg_docs = [{"id": d.doc_id, "text": d.text} for s in bg for d in s.docs]
    base = out / "lightrag"; base.mkdir(parents=True, exist_ok=True)
    s0 = {}
    for variant, extract_cache in (("cache", True), ("nocache", False)):
        d = base / f"S0_{variant}"
        if not (d / "kv_store_doc_status.json").exists():
            o = run_world(M, d, [{"op": "insert", "docs": bg_docs}, {"op": "status", "tag": "bg", "ids": [x["id"] for x in bg_docs]}],
                          [] if extract_cache else ["--no-extract-cache"])
            bad = [k for k, v in o.get("status", {}).get("bg", {}).items() if v != "processed"] if "error" not in o else ["<world error>"]
            json.dump({"bad_background_docs": bad, "seconds": o.get("seconds")}, open(base / f"S0_{variant}.meta.json", "w"))
            if bad:
                print(f"[lightrag] WARNING: {len(bad)} background docs not processed in S0_{variant}", flush=True)
        s0[variant] = d
    jobs = []
    for s in targets:
        vals = [f.value for f in s.all_facts()]; ids = [d.doc_id for d in s.docs]
        for cond, (cache_on, del_cache) in LR_CONDS.items():
            ops = [{"op": "insert", "docs": [{"id": d.doc_id, "text": d.text} for d in s.docs]},
                   {"op": "status", "tag": "x", "ids": ids},
                   {"op": "query", "tag": "live", "qs": PROBES(s), "mode": "mix"},
                   {"op": "delete", "ids": ids, "delete_llm_cache": del_cache},
                   {"op": "scan", "tag": "after", "values": vals},
                   {"op": "query", "tag": "after_answer", "qs": PROBES(s), "mode": "mix"},
                   {"op": "query", "tag": "after_para", "qs": PROBES_PARA(s), "mode": "mix"},
                   {"op": "query", "tag": "after_context", "qs": PROBES(s), "mode": "mix", "context": True}]
            jobs.append(("rr", s.subject_id, cond, vals, s0["cache" if cache_on else "nocache"], ops, cache_on))
        for variant in ("cache", "nocache"):
            ops = [{"op": "query", "tag": "cf_answer", "qs": PROBES(s), "mode": "mix"},
                   {"op": "query", "tag": "cf_context", "qs": PROBES(s), "mode": "mix", "context": True}]
            jobs.append(("cf", s.subject_id, variant, vals, s0[variant], ops, variant == "cache"))
    managers = sorted({s.manager for s in targets})[:args.n_poison]
    rng = random.Random(args.seed + 7)
    for mg in managers:
        fv = _rand_token(rng)
        pdocs = poison_docs(mg, fv, n=5)
        for cond in ("default", "thorough"):
            ops = [{"op": "insert", "docs": pdocs},
                   {"op": "status", "tag": "x", "ids": [d["id"] for d in pdocs]},
                   {"op": "query", "tag": "before", "qs": ZQ(mg), "mode": "mix"},
                   {"op": "delete", "ids": [d["id"] for d in pdocs], "delete_llm_cache": LR_CONDS[cond][1]},
                   {"op": "scan", "tag": "after", "values": [fv]},
                   {"op": "query", "tag": "after", "qs": ZQ(mg), "mode": "mix"}]
            jobs.append(("zp", mg, cond, [fv], s0["cache"], ops, True))
        jobs.append(("zp_cf", mg, "cf", [fv], s0["cache"], [{"op": "query", "tag": "cf", "qs": ZQ(mg), "mode": "mix"}], True))

    def go(j):
        kind, key, cond, vals, src, ops, cache_on = j
        w = base / "worlds" / f"{kind}_{key}_{cond}".replace(" ", "_")
        if w.exists(): shutil.rmtree(w)
        shutil.copytree(src, w)
        o = run_world(M, w, ops, [] if cache_on else ["--no-extract-cache"])
        if not args.keep_worlds: shutil.rmtree(w, ignore_errors=True)
        return j, o
    print(f"[lightrag] {len(jobs)} worlds on {args.parallel} workers", flush=True)
    with ThreadPoolExecutor(args.parallel) as ex:
        done = list(ex.map(go, jobs))
    return score_lightrag(done)


def score_lightrag(done):
    rows, invalid = {"rr": {}, "cf": {}, "zp": {}, "zp_cf": {}}, []
    for (kind, key, cond, vals, *_), o in done:
        if "error" in o:
            invalid.append({"kind": kind, "key": key, "cond": cond, "why": o["error"][-300:]}); continue
        st = o.get("status", {}).get("x", {})
        if st and any(v != "processed" for v in st.values()):
            invalid.append({"kind": kind, "key": key, "cond": cond, "why": f"doc status {sorted(set(st.values()))}"}); continue
        q = o.get("queries", {})
        if kind == "rr":
            rows["rr"].setdefault(cond, []).append({
                "subject": key, "live": frac(canaries_in(q["live"], vals), vals),
                "answer": frac(canaries_in(q["after_answer"], vals), vals),
                "paraphrase": frac(canaries_in(q["after_para"], vals), vals),
                "context": frac(canaries_in(q["after_context"], vals), vals),
                "at_rest": {f: frac(v, vals) for f, v in o["scans"]["after"].items()},
                "deletions": [d["status"] for d in o["deletions"]], "seconds": o["seconds"]})
        elif kind == "cf":
            rows["cf"].setdefault(cond, []).append({"subject": key, "answer": frac(canaries_in(q["cf_answer"], vals), vals),
                                                    "context": frac(canaries_in(q["cf_context"], vals), vals)})
        elif kind == "zp":
            fv = vals[0].lower()
            rows["zp"].setdefault(cond, []).append({"manager": key, "before": sum(fv in a.lower() for a in q["before"]) / len(q["before"]),
                                                    "after": sum(fv in a.lower() for a in q["after"]) / len(q["after"]),
                                                    "at_rest": sorted(o["scans"]["after"])})
        else:
            fv = vals[0].lower()
            rows["zp_cf"].setdefault("cf", []).append({"manager": key, "asr": sum(fv in a.lower() for a in q["cf"]) / len(q["cf"])})
    mean = lambda xs: round(sum(xs) / len(xs), 3) if xs else None
    summ = {"recovery": {c: {"n": len(r), "live": mean([x["live"] for x in r]), "answer": mean([x["answer"] for x in r]),
                             "paraphrase": mean([x["paraphrase"] for x in r]),
                             "context": mean([x["context"] for x in r]),
                             "at_rest_any": mean([1.0 if x["at_rest"] else 0.0 for x in r]),
                             "at_rest_stores": sorted({k for x in r for k in x["at_rest"]})} for c, r in rows["rr"].items()},
            "counterfactual": {c: {"n": len(r), "answer": mean([x["answer"] for x in r]), "context": mean([x["context"] for x in r])}
                               for c, r in rows["cf"].items()},
            "zombie": {c: {"n": len(r), "before": mean([x["before"] for x in r]), "after": mean([x["after"] for x in r])}
                       for c, r in rows["zp"].items()},
            "zombie_counterfactual": mean([x["asr"] for x in rows["zp_cf"].get("cf", [])]),
            "invalid_worlds": invalid}
    return {"summary": summ, "rows": rows}


# ----------------------------------------------------------------- Mem0
def mem0(args, out: Path):
    M = "palimpsest.real.mem0_world"
    targets = build_population(args.n_subjects, args.docs, args.facts, seed=args.seed + 101,
                               subjects_per_manager=args.subjects_per_manager)
    base = out / "mem0"; base.mkdir(parents=True, exist_ok=True)
    xi = min(2, args.docs - 1)
    jobs = []
    for s in targets:
        u = s.subject_id; adds = [{"op": "add", "tag": f"D{i}", "user_id": u, "text": d.text} for i, d in enumerate(s.docs)]
        xv = [f.value for f in s.docs[xi].facts]; allv = [f.value for f in s.all_facts()]
        jobs.append(("lineage", u, xv, adds + [
            {"op": "delete_from_add", "tags": [f"D{xi}"]}, {"op": "get_all", "tag": "after", "user_id": u},
            {"op": "search", "tag": "after", "user_id": u, "qs": PROBES(s)[:3]}, {"op": "scan", "tag": "after", "values": xv}]))
        jobs.append(("lineage_cf", u, xv, [a for i, a in enumerate(adds) if i != xi] + [
            {"op": "get_all", "tag": "after", "user_id": u}, {"op": "search", "tag": "after", "user_id": u, "qs": PROBES(s)[:3]}]))
        ret = {"op": "add", "tag": "return", "user_id": u, "text": "Hello again, I am back. Please help me plan my week."}
        jobs.append(("user", u, allv, adds + [
            {"op": "delete_all", "user_id": u}, {"op": "get_all", "tag": "after_delete", "user_id": u},
            {"op": "scan", "tag": "after_delete", "values": allv}, ret,
            {"op": "get_all", "tag": "after_return", "user_id": u}, {"op": "scan", "tag": "after_return", "values": allv}]))
        jobs.append(("user_cf", u, allv, [ret, {"op": "get_all", "tag": "after_return", "user_id": u}]))

    def go(j):
        kind, u, vals, ops = j
        w = base / "worlds" / f"{kind}_{u}"
        if w.exists(): shutil.rmtree(w)
        o = run_world(M, w, ops)
        if not args.keep_worlds: shutil.rmtree(w, ignore_errors=True)
        return j, o
    print(f"[mem0] {len(jobs)} worlds on {args.parallel} workers", flush=True)
    with ThreadPoolExecutor(args.parallel) as ex:
        done = list(ex.map(go, jobs))
    rows, invalid = {}, []
    for (kind, u, vals, _), o in done:
        if "error" in o:
            invalid.append({"kind": kind, "user": u, "why": o["error"][-300:]}); continue
        r = {"user": u}
        if kind in ("lineage", "lineage_cf"):
            r["visible"] = frac(canaries_in(o["get_all"]["after"] + [m for res in o["search"]["after"] for m in res], vals), vals)
            if kind == "lineage":
                r["at_rest"] = {k: frac(v, vals) for k, v in o["scans"]["after"].items()}
                r["x_add_events"] = [a["event"] for a in o["adds"].get("D2", [])]
        elif kind == "user":
            r["visible_after_delete"] = frac(canaries_in(o["get_all"]["after_delete"], vals), vals)
            r["at_rest_after_delete"] = {k: frac(v, vals) for k, v in o["scans"]["after_delete"].items()}
            r["visible_after_return"] = frac(canaries_in(o["get_all"]["after_return"], vals), vals)
        else:
            r["visible_after_return"] = frac(canaries_in(o["get_all"]["after_return"], vals), vals)
        rows.setdefault(kind, []).append(r)
    mean = lambda xs: round(sum(xs) / len(xs), 3) if xs else None
    summ = {"lineage": {"n": len(rows.get("lineage", [])), "visible": mean([r["visible"] for r in rows.get("lineage", [])]),
                        "at_rest_any": mean([1.0 if r["at_rest"] else 0.0 for r in rows.get("lineage", [])]),
                        "at_rest_stores": sorted({k for r in rows.get("lineage", []) for k in r["at_rest"]})},
            "lineage_counterfactual": mean([r["visible"] for r in rows.get("lineage_cf", [])]),
            "user": {"n": len(rows.get("user", [])),
                     "visible_after_delete": mean([r["visible_after_delete"] for r in rows.get("user", [])]),
                     "at_rest_after_delete_any": mean([1.0 if r["at_rest_after_delete"] else 0.0 for r in rows.get("user", [])]),
                     "at_rest_stores": sorted({k for r in rows.get("user", []) for k in r["at_rest_after_delete"]}),
                     "visible_after_return": mean([r["visible_after_return"] for r in rows.get("user", [])])},
            "user_counterfactual": mean([r["visible_after_return"] for r in rows.get("user_cf", [])]),
            "invalid_worlds": invalid}
    return {"summary": summ, "rows": rows}


def _has(p):
    import importlib.metadata as md
    try:
        md.version(p); return True
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", choices=["lightrag", "mem0", "all"], default="all")
    ap.add_argument("--n-subjects", type=int, default=20); ap.add_argument("--n-background", type=int, default=40)
    ap.add_argument("--docs", type=int, default=5); ap.add_argument("--facts", type=int, default=3)
    ap.add_argument("--n-poison", type=int, default=10); ap.add_argument("--parallel", type=int, default=6)
    ap.add_argument("--subjects-per-manager", type=int, default=10,
                    help="smaller means more distinct managers, i.e. more zombie-poisoning targets "
                         "(=1 gives up to n-subjects targets)")
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--out", default="results/real")
    ap.add_argument("--quick", action="store_true"); ap.add_argument("--keep-worlds", action="store_true")
    a = ap.parse_args()
    if a.quick:
        a.n_subjects, a.n_background, a.n_poison, a.out = 2, 4, 1, a.out.rstrip("/") + "_quick"
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    import importlib.metadata as md
    meta = {"versions": {p: md.version(p) for p in ("lightrag-hku", "mem0ai") if _has(p)}, "args": vars(a),
            "llm": os.environ.get("PAL_LLM_MODEL"), "started": time.strftime("%Y-%m-%d %H:%M:%S")}
    t = time.time()
    if a.system in ("lightrag", "all"):
        r = lightrag(a, out); json.dump(r, open(out / "lightrag.json", "w"), indent=1)
        print("[lightrag]", json.dumps(r["summary"], indent=1), flush=True)
    if a.system in ("mem0", "all"):
        r = mem0(a, out); json.dump(r, open(out / "mem0.json", "w"), indent=1)
        print("[mem0]", json.dumps(r["summary"], indent=1), flush=True)
    meta["minutes"] = round((time.time() - t) / 60, 1); json.dump(meta, open(out / "meta.json", "w"), indent=1)


if __name__ == "__main__":
    main()
