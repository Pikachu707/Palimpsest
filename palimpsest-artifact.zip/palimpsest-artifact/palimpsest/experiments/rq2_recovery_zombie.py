"""Experiments C & D (RQ2): residue recovery and zombie poisoning.

Runs on the compound systems (MiniGraphRAG, MiniMemory), which need the LLM.
Emits Table 4.
"""
from __future__ import annotations
import numpy as np

from ..config import Config
from ..systems import MiniGraphRAG, MiniMemory
from ..attacks import run_residue_recovery, run_zombie_poisoning
from .common import setup, background_and_canaries, load_beir_into
from . import save_json


def run(cfg: Config, n_canaries: int = 20) -> dict:
    llm, emb, subjects = setup(cfg)
    bg_docs, canaries, _ = background_and_canaries(subjects, n_canaries)
    bg_docs = load_beir_into(bg_docs, cfg)

    compound = {
        "graphrag": lambda opt: MiniGraphRAG(llm, emb, deletion_option=opt),
        "memory":   lambda opt: MiniMemory(llm, deletion_option=opt),
    }

    out = {"residue_recovery": {}, "zombie": {}}
    for name, mk in compound.items():
        # residue recovery averaged over canaries, naive vs lsed
        for opt in ("naive", "lsed"):
            recs, falses, recs_a, falses_a, pm_client, pm_rest = [], [], [], [], {}, {}
            for c in canaries:
                rr = run_residue_recovery(lambda: mk(opt), bg_docs, c,
                                          paraphrases=cfg.attack.rr_paraphrases)
                recs.append(rr.recovered_frac); falses.append(rr.false_recovery_frac)
                recs_a.append(rr.recovered_answer_frac); falses_a.append(rr.false_recovery_answer_frac)
                for m, v in (rr.per_mechanism_client or {}).items():
                    pm_client.setdefault(m, []).append(v)
                for m, v in (rr.per_mechanism_at_rest or {}).items():
                    pm_rest.setdefault(m, []).append(v)
            n = len(canaries)
            # mechanisms absent for a canary contributed 0 -> pad before averaging
            out["residue_recovery"][f"{name}:{opt}"] = {
                "recovered_mean": float(np.mean(recs)),
                "false_recovery_mean": float(np.mean(falses)),
                "recovered_answer_mean": float(np.mean(recs_a)),
                "false_recovery_answer_mean": float(np.mean(falses_a)),
                "per_mechanism_client": {m: float(sum(v) / n) for m, v in pm_client.items()},
                "per_mechanism_at_rest": {m: float(sum(v) / n) for m, v in pm_rest.items()},
            }
            print(f"[RQ2-RR] {name}:{opt} recovered={np.mean(recs):.3f} "
                  f"false={np.mean(falses):.3f} | answer-only={np.mean(recs_a):.3f} "
                  f"false={np.mean(falses_a):.3f}")
        # zombie poisoning naive vs lsed
        for opt in ("naive", "lsed"):
            z = run_zombie_poisoning(lambda: mk(opt), bg_docs, subjects,
                                     n_targets=cfg.attack.poison_targets,
                                     seed=cfg.data.seed)
            out["zombie"][f"{name}:{opt}"] = {
                "before": z.asr_before, "after": z.asr_after,
                "counterfactual": z.asr_counterfactual,
                "before_answer": z.asr_before_answer, "after_answer": z.asr_after_answer,
                "counterfactual_answer": z.asr_counterfactual_answer}
            print(f"[RQ2-ZP] {name}:{opt} before={z.asr_before:.3f} "
                  f"after={z.asr_after:.3f} cf={z.asr_counterfactual:.3f} | answer-only "
                  f"{z.asr_before_answer:.3f}->{z.asr_after_answer:.3f} cf={z.asr_counterfactual_answer:.3f}")
    return save_json(cfg, "rq2_recovery_zombie", out), out
