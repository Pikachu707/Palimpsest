"""Microsoft GraphRAG (3.2.0): canary residue after an operator removes a document.

GraphRAG has no per-document delete. An operator who removes a document from the corpus
can (a) run the documented incremental `update` on the remaining corpus, or (b) re-index
the remaining corpus in full, which reuses GraphRAG's LLM cache by default.

    python -m palimpsest.experiments.graphrag_exp --n-subjects 10 --parallel 4 --out results/graphrag
    python -m palimpsest.experiments.graphrag_exp --quick

Worlds run in their own processes with PAL_GRAPHRAG_PYTHON (GraphRAG lives in its own
virtualenv). A world with an indexing error, or whose subject was not indexed while live,
is reported as invalid and never scored.
"""
import argparse, json, os, random, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from palimpsest.canaries import build_population, _rand_token
from palimpsest.experiments.real_systems import PROBES, PROBES_PARA, ZQ, poison_docs, frac, canaries_in

PY = os.environ.get("PAL_GRAPHRAG_PYTHON", sys.executable)
M = "palimpsest.real.graphrag_world"
CONDS = ("update", "reindex")


def run_world(wdir: Path, ops, timeout_s=None):
    ops_dir = wdir.parent / "ops"; ops_dir.mkdir(parents=True, exist_ok=True)
    opf, outf = ops_dir / f"{wdir.name}.ops.json", ops_dir / f"{wdir.name}.out.json"
    json.dump(ops, open(opf, "w")); t = time.time()
    try:
        r = subprocess.run([PY, "-m", M, "--dir", str(wdir), "--ops", str(opf), "--out", str(outf)],
                           capture_output=True, text=True, timeout=timeout_s)
        rc, err = r.returncode, (r.stderr or r.stdout)
    except subprocess.TimeoutExpired as e:
        rc, err = -9, f"timeout after {timeout_s}s; stderr tail: " + ((e.stderr or b"").decode(errors="ignore") if isinstance(e.stderr, bytes) else (e.stderr or ""))[-1200:]
    if rc:
        (ops_dir / f"{wdir.name}.err.txt").write_text(err[-20000:])
        if (wdir / "logs").exists():                      # keep GraphRAG's own logs for diagnosis
            shutil.copytree(wdir / "logs", ops_dir / f"{wdir.name}.logs", dirs_exist_ok=True)
        if outf.exists(): outf.unlink()                    # never leave a partial result behind
        return {"error": err[-1500:], "seconds": round(time.time() - t, 1)}
    o = json.load(open(outf)); o["seconds"] = round(time.time() - t, 1); return o


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-subjects", type=int, default=10); ap.add_argument("--n-background", type=int, default=20)
    ap.add_argument("--docs", type=int, default=5); ap.add_argument("--facts", type=int, default=3)
    ap.add_argument("--n-poison", type=int, default=5); ap.add_argument("--parallel", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--out", default="results/graphrag")
    ap.add_argument("--quick", action="store_true"); ap.add_argument("--keep-worlds", action="store_true")
    ap.add_argument("--world-timeout", type=int, default=2700,
                    help="seconds before a world is killed and recorded as invalid (a hung GraphRAG run)")
    a = ap.parse_args()
    if a.quick:
        a.n_subjects, a.n_background, a.n_poison, a.out = 2, 3, 1, a.out.rstrip("/") + "_quick"
    out = Path(a.out); base = out / "graphrag"; base.mkdir(parents=True, exist_ok=True); t0 = time.time()
    pop = build_population(a.n_subjects + a.n_background, a.docs, a.facts, seed=a.seed, subjects_per_manager=1)
    targets, bg = pop[:a.n_subjects], pop[a.n_subjects:]
    bgd = [{"id": d.doc_id, "text": d.text} for s in bg for d in s.docs]

    s0 = base / "S0"
    if not (s0 / "output" / "documents.parquet").exists():
        o = run_world(s0, [{"op": "index", "docs": bgd}])
        if "error" in o:
            sys.exit(f"background index failed: {o['error'][-600:]}")
    jobs = []
    for s in targets:
        xd = [{"id": d.doc_id, "text": d.text} for d in s.docs]; ids = [d["id"] for d in xd]; vals = [f.value for f in s.all_facts()]
        for cond in CONDS:
            remove = {"op": "update", "docs": bgd} if cond == "update" else {"op": "index", "docs": bgd}
            jobs.append(("rr", s.subject_id, cond, vals, [
                {"op": "update", "docs": bgd + xd}, {"op": "status", "tag": "live", "ids": ids},
                {"op": "query", "tag": "live", "qs": PROBES(s)},
                remove, {"op": "status", "tag": "after", "ids": ids}, {"op": "scan", "tag": "after", "values": vals},
                {"op": "query", "tag": "after", "qs": PROBES(s)}, {"op": "query", "tag": "after_para", "qs": PROBES_PARA(s)}]))
    jobs.append(("cf", "all", "cf", None, [{"op": "query", "tag": s.subject_id, "qs": PROBES(s)} for s in targets]))
    rng = random.Random(a.seed + 7)
    managers = [s.manager for s in targets][:a.n_poison]
    zvals = {}
    for mg in managers:
        fv = _rand_token(rng); zvals[mg] = fv; pd_ = poison_docs(mg, fv, n=5)
        for cond in CONDS:
            remove = {"op": "update", "docs": bgd} if cond == "update" else {"op": "index", "docs": bgd}
            jobs.append(("zp", mg, cond, [fv], [
                {"op": "update", "docs": bgd + pd_}, {"op": "status", "tag": "live", "ids": [d["id"] for d in pd_]},
                {"op": "query", "tag": "before", "qs": ZQ(mg)}, remove,
                {"op": "status", "tag": "after", "ids": [d["id"] for d in pd_]}, {"op": "scan", "tag": "after", "values": [fv]},
                {"op": "query", "tag": "after", "qs": ZQ(mg)}]))
    jobs.append(("zp_cf", "all", "cf", None, [{"op": "query", "tag": mg, "qs": ZQ(mg)} for mg in managers]))

    def go(j):
        kind, key, cond, vals, ops = j
        w = base / "worlds" / f"{kind}_{key}_{cond}".replace(" ", "_")
        done_f = base / "worlds" / "ops" / f"{w.name}.out.json"
        if done_f.exists():                                # resume: a completed world is reused as is
            try:
                o = json.load(open(done_f)); o["resumed"] = True; return j, o
            except Exception:
                done_f.unlink()
        if w.exists(): shutil.rmtree(w)
        shutil.copytree(s0, w)
        o = run_world(w, ops, a.world_timeout)
        if not a.keep_worlds: shutil.rmtree(w, ignore_errors=True)
        return j, o
    n_done = sum((base / "worlds" / "ops" / f"{f'{j[0]}_{j[1]}_{j[2]}'.replace(' ', '_')}.out.json").exists() for j in jobs)
    print(f"[graphrag] {len(jobs)} worlds on {a.parallel} workers ({n_done} already complete, reused)", flush=True)
    with ThreadPoolExecutor(a.parallel) as ex:
        done = list(ex.map(go, jobs))

    mean = lambda xs: round(sum(xs) / len(xs), 3) if xs else None
    rows, invalid, cf = {"rr": {}, "zp": {}}, [], {}
    for (kind, key, cond, vals, _), o in done:
        if "error" in o:
            invalid.append({"kind": kind, "key": key, "cond": cond, "why": o["error"][-300:]}); continue
        if kind in ("rr", "zp") and any(v != "present" for v in o["status"]["live"].values()):
            invalid.append({"kind": kind, "key": key, "cond": cond, "why": "not indexed while live"}); continue
        q, c = o["queries"], o["contexts"]
        if kind == "rr":
            rows["rr"].setdefault(cond, []).append({
                "subject": key, "live": frac(canaries_in(q["live"], vals), vals),
                "answer": frac(canaries_in(q["after"], vals), vals), "reword": frac(canaries_in(q["after_para"], vals), vals),
                "context": frac(canaries_in(c["after"], vals), vals),
                "docs_still_indexed": sum(v == "present" for v in o["status"]["after"].values()) / len(o["status"]["after"]),
                "at_rest": {k: frac(v, vals) for k, v in o["scans"]["after"].items()}})
        elif kind == "zp":
            fv = vals[0].lower()
            rows["zp"].setdefault(cond, []).append({"manager": key,
                "before": sum(fv in x.lower() for x in q["before"]) / len(q["before"]),
                "after": sum(fv in x.lower() for x in q["after"]) / len(q["after"]),
                "docs_still_indexed": sum(v == "present" for v in o["status"]["after"].values()) / len(o["status"]["after"])})
        elif kind == "cf":
            cf["recovery"] = mean([frac(canaries_in(q[s.subject_id] + c[s.subject_id], [f.value for f in s.all_facts()]),
                                        [f.value for f in s.all_facts()]) for s in targets])
        else:
            cf["zombie"] = mean([sum(zvals[mg].lower() in x.lower() for x in q[mg]) / len(q[mg]) for mg in managers])
    summ = {"recovery": {c: {"n": len(r), "live": mean([x["live"] for x in r]), "answer": mean([x["answer"] for x in r]),
                             "reword": mean([x["reword"] for x in r]), "context": mean([x["context"] for x in r]),
                             "docs_still_indexed": mean([x["docs_still_indexed"] for x in r]),
                             "at_rest_stores": sorted({k.split("/")[0] if k.startswith("update_output") else k for x in r for k in x["at_rest"]})}
                         for c, r in rows["rr"].items()},
            "zombie": {c: {"n": len(r), "before": mean([x["before"] for x in r]), "after": mean([x["after"] for x in r]),
                           "docs_still_indexed": mean([x["docs_still_indexed"] for x in r])} for c, r in rows["zp"].items()},
            "counterfactual": cf, "invalid_worlds": invalid}
    import importlib.metadata as md
    try: ver = subprocess.run([PY, "-c", "import importlib.metadata as m; print(m.version('graphrag'))"], capture_output=True, text=True).stdout.strip()
    except Exception: ver = None
    json.dump({"summary": summ, "rows": rows}, open(out / "graphrag.json", "w"), indent=1)
    json.dump({"graphrag": ver, "args": vars(a), "llm": os.environ.get("PAL_LLM_MODEL"),
               "minutes": round((time.time() - t0) / 60, 1)}, open(out / "meta.json", "w"), indent=1)
    print("[graphrag]", json.dumps(summ, indent=1), flush=True)


if __name__ == "__main__":
    main()
