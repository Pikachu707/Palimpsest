"""Experiment runners. Each writes a JSON blob under cfg.out_dir and returns it.

    A: rq1_residue        -> Table 3 (RQ1)
    B: rq2_deletion_inf   -> Fig 4  (RQ2)
    C: rq2_residue_rec    -> Table 4 top (RQ2)
    D: rq2_zombie         -> Table 4 bottom (RQ2)
    E: rq3_lsed           -> Table 5 (RQ3)
    F: ablations          -> ablation study
    G: timing_channel     -> timing side-channel after padding
"""
import json
import os
from pathlib import Path


def save_json(cfg, name: str, obj: dict) -> str:
    out = Path(cfg.out_dir) / cfg.run_name
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{name}.json"
    path.write_text(json.dumps(obj, indent=2, default=str))
    return str(path)
