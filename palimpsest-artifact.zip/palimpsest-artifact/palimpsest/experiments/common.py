"""Shared setup for experiment runners."""
from __future__ import annotations
import random

from ..config import Config
from ..llm import LLM, Embedder
from ..canaries import build_population


def setup(cfg: Config):
    from ..systems.graphrag_mini import MiniGraphRAG
    MiniGraphRAG.set_render_style(cfg.graph.render_style)
    llm = LLM(cfg.llm)
    emb = Embedder(cfg.emb)
    subjects = build_population(cfg.data.n_subjects, cfg.data.docs_per_subject,
                                cfg.data.canary_facts_per_doc, cfg.data.seed,
                                subjects_per_manager=cfg.data.subjects_per_manager)
    return llm, emb, subjects


def background_and_canaries(subjects, n_canaries: int):
    """Split subjects into canary targets and background population."""
    canaries = subjects[:n_canaries]
    background = subjects[n_canaries:]
    bg_docs = [d for s in background for d in s.docs]
    return bg_docs, canaries, background


def load_beir_into(bg_docs, cfg: Config):
    """Optionally extend background with a BEIR corpus. No-op if not configured.
    See scripts/download_beir.sh. Uses `beir` if installed."""
    if not cfg.data.beir_dataset:
        return bg_docs
    try:
        from beir import util
        from beir.datasets.data_loader import GenericDataLoader
        from types import SimpleNamespace
        import os
        data_path = os.path.join(cfg.data.beir_root, cfg.data.beir_dataset)
        corpus, _, _ = GenericDataLoader(data_folder=data_path).load(split="test")
        extra = [SimpleNamespace(doc_id=f"beir-{cid}",
                                 subject_id="__beir__",
                                 text=(c.get("title", "") + " " + c.get("text", "")).strip())
                 for cid, c in corpus.items()]
        return bg_docs + extra[: cfg.data.n_background_docs]
    except Exception as e:  # keep experiments runnable without beir
        print(f"[beir] skipped ({e}); using synthetic background only")
        return bg_docs


DI_TARGET_OFFSET = 50_000   # target subject ids/names start here (disjoint)


def di_population(cfg: Config, subjects, max_k: int):
    """Background + deletion-inference targets that are guaranteed disjoint.

    Targets are a separate population with `max_k` documents each, so every
    k in the sweep is real (not silently capped by docs_per_subject), and the
    counterfactual (H0) world truly never contains a target's records."""
    bg_docs = [d for s in subjects for d in s.docs]
    bg_docs = load_beir_into(bg_docs, cfg)[: cfg.attack.di_background_docs]
    n_targets = cfg.attack.shadow_models + cfg.attack.di_test_subjects
    targets = build_population(n_targets, max_k, cfg.data.canary_facts_per_doc,
                               seed=cfg.data.seed + 1, offset=DI_TARGET_OFFSET,
                               subjects_per_manager=cfg.data.subjects_per_manager)
    bg_ids = {d.doc_id for d in bg_docs}
    assert not any(d.doc_id in bg_ids for t in targets for d in t.docs), \
        "DI targets overlap background"
    return bg_docs, targets


def hnsw_kw(cfg: Config) -> dict:
    return dict(M=cfg.index.hnsw_M, ef=cfg.index.hnsw_ef,
                ef_construction=cfg.index.hnsw_ef_construction)


def make_native_hnsw(cfg: Config, emb, deletion_option: str = "mark_deleted"):
    from ..systems import HnswlibSUT
    return lambda: HnswlibSUT(emb, emb.dim, deletion_option=deletion_option, **hnsw_kw(cfg))


def make_lsed(cfg: Config, llm, emb, **overrides):
    from ..defense import LSEDSystem
    kw = dict(n_partitions=cfg.lsed.n_partitions, slice_size=cfg.lsed.slice_size,
              **hnsw_kw(cfg))
    kw.update(overrides)
    return lambda: LSEDSystem(llm, emb, emb.dim, **kw)
