"""Experiment E (RQ3): cost and effectiveness of LSED.

Compares three deletion regimes on the compound pipeline:
  - native:      MiniGraphRAG(deletion_option="naive")
  - full_rebuild: rebuild from surviving docs each deletion
  - lsed:        LSEDSystem (partitioned, history-independent, atomize-then-render)

along completeness (attacks after deletion), quality (retrieval), and cost
(latency). Emits Table 5.
"""
from __future__ import annotations
import time
import numpy as np

from ..config import Config
from ..systems import MiniGraphRAG
from ..defense import LSEDSystem
from ..attacks import run_residue_recovery, run_zombie_poisoning
from ..attacks.deletion_inference import run_deletion_inference
from .common import (setup, background_and_canaries, load_beir_into,
                     make_native_hnsw, make_lsed)
from .rq2_deletion_inference import di_sweep
from ..systems import HnswlibSUT
from . import save_json


def retrieval_quality(make, docs, subjects, k: int = 10) -> tuple[float, float]:
    """Recall@k and nDCG@k on the synthetic corpus: the query "Who is <name>?"
    has that subject's documents as its relevant set. (A BEIR-qrels variant is
    a drop-in once a BEIR corpus is configured.)"""
    sut = make(); sut.ingest(docs)
    recalls, ndcgs = [], []
    for s in subjects:
        rel = {d.doc_id for d in s.docs}
        hits = [h.doc_id for h in sut.query(f"Who is {s.name}?", k=k).hits][:k]
        recalls.append(len(rel & set(hits)) / max(1, min(len(rel), k)))
        dcg = sum(1 / np.log2(i + 2) for i, h in enumerate(hits) if h in rel)
        idcg = sum(1 / np.log2(i + 2) for i in range(min(len(rel), k)))
        ndcgs.append(dcg / idcg if idcg else 0.0)
    return float(np.mean(recalls)), float(np.mean(ndcgs))


class _FullRebuildGraph(MiniGraphRAG):
    """Naive extraction but delete = full rebuild from surviving docs (exact, slow)."""
    def __init__(self, llm, emb):
        super().__init__(llm, emb, deletion_option="naive")
        self._all_docs = {}

    def ingest(self, docs):
        from types import SimpleNamespace
        for d in docs:
            self._all_docs[d.doc_id] = d.text
        super().ingest(docs)

    def delete(self, doc_ids):
        from types import SimpleNamespace
        for did in doc_ids:
            self._all_docs.pop(did, None)
        keep = [SimpleNamespace(doc_id=k, subject_id=k.split("-")[0], text=v)
                for k, v in self._all_docs.items()]
        # rebuild fresh
        self.__init__ if False else None
        self._docs.clear(); self._deleted.clear(); self._atoms.clear()
        self._entity_desc.clear(); self._extract_cache.clear(); self._entities_of_doc.clear()
        super().ingest(keep)


def _deletion_latency(make, bg_docs, subject, llm) -> float:
    """Wall-clock cost of one subject's deletion, LLM memo BYPASSED: a memo
    hit would make LLM re-rendering (LSED) or re-extraction (full rebuild)
    look free."""
    sut = make()
    sut.ingest(bg_docs + subject.docs)
    with llm.uncached():
        t0 = time.perf_counter()
        sut.delete([d.doc_id for d in subject.docs])
        return time.perf_counter() - t0


def _e2e_latency(make, docs, subjects, llm, n=40) -> tuple[float, float]:
    """End-to-end query latency INCLUDING generation, memo bypassed: what a
    user waits. Distinct questions, so vLLM's prefix cache cannot short-cut."""
    sut = make(); sut.ingest(docs)
    qs = [f"Who is {s.name}?" for s in subjects][:n]
    with llm.uncached():
        sut.query(qs[0], k=10)                     # warm-up
        lats = np.array([sut.query(q, k=10).latency_s for q in qs]) * 1000
    return float(np.percentile(lats, 50)), float(np.percentile(lats, 95))


def _retrieval_latency(make, docs, subjects, n=1000) -> tuple[float, float]:
    """Query latency of the RETRIEVAL layer (no LLM): what partition fan-out
    changes. Generation time is common to all regimes and is excluded."""
    sut = make(); sut.ingest(docs)
    qs = [f"Who is {s.name}?" for s in subjects]
    for q in qs[:10]:
        sut.query(q, k=10)                         # warm-up
    lats = np.array([sut.query(qs[i % len(qs)], k=10).latency_s for i in range(n)]) * 1000
    return float(np.percentile(lats, 50)), float(np.percentile(lats, 99))


def run(cfg: Config, n_canaries: int = 10, with_di: bool = True) -> tuple:
    llm, emb, subjects = setup(cfg)
    bg_docs, canaries, _ = background_and_canaries(subjects, n_canaries)
    bg_docs = load_beir_into(bg_docs, cfg)

    # Compound (graph-RAG) regimes: deletion cost, query cost, text-level residue.
    regimes = {
        "native":       lambda: MiniGraphRAG(llm, emb, deletion_option="naive"),
        "full_rebuild": lambda: _FullRebuildGraph(llm, emb),
        "lsed":         make_lsed(cfg, llm, emb),
    }
    # Retrieval-layer counterparts, for structural residue (DI) and quality.
    # Retrieval layer for quality and latency (same index family as LSED) ...
    retrieval = {
        "native":       make_native_hnsw(cfg, emb, "mark_deleted"),
        "full_rebuild": make_native_hnsw(cfg, emb, "rebuild"),
        "lsed":         make_lsed(cfg, llm, emb, retrieval_only=True),
    }
    # ... and the deletion-inference system per regime (configurable, so the
    # comparison can use an index whose residue is client-visible, e.g. IVF-PQ).
    di_systems = dict(zip(("native", "full_rebuild", "lsed"), cfg.attack.rq3_di_systems))
    quality_subjects = subjects[n_canaries:n_canaries + 50]
    di_k = int(cfg.attack.rq3_di_k)

    out = {"_notes": {"di_layer": "retrieval", "di_k": di_k,
                      "di_channels": list(cfg.attack.di_channels),
                      "index": {"M": cfg.index.hnsw_M, "ef": cfg.index.hnsw_ef},
                      "quality": "synthetic name->subject-docs relevance",
                      "deletion_latency": "end-to-end incl. LLM, memo bypassed",
                      "query_latency": "retrieval layer only (no generation), n=1000",
                      "e2e_latency": "full query incl. generation, memo bypassed, n=40"}}
    c = canaries[0]
    for name, make in regimes.items():
        del_lat = np.mean([_deletion_latency(make, bg_docs, cc, llm) for cc in canaries[:3]])
        rmake = retrieval[name]; di_name = di_systems[name]
        p50, p99 = _retrieval_latency(rmake, bg_docs, quality_subjects)
        rr = np.mean([run_residue_recovery(make, bg_docs, cc,
                      paraphrases=cfg.attack.rr_paraphrases).recovered_frac
                      for cc in canaries[:5]])
        z = run_zombie_poisoning(make, bg_docs, subjects,
                                 n_targets=min(20, cfg.attack.poison_targets))
        recall, ndcg = retrieval_quality(rmake, bg_docs, quality_subjects)
        e50, e95 = _e2e_latency(make, bg_docs, quality_subjects, llm)
        rec = {
            "deletion_latency_s": float(del_lat),
            "query_p50_ms": p50, "query_p99_ms": p99,
            "e2e_p50_ms": e50, "e2e_p95_ms": e95,
            "recall_at_10": recall, "ndcg_at_10": ndcg,
            "recovered_after_delete": float(rr),
            "zombie_after_delete": z.asr_after,
            "zombie_counterfactual": z.asr_counterfactual,
        }
        if with_di:
            di = di_sweep(cfg, di_name, [di_k], llm=llm, emb=emb, subjects=subjects)
            rec["di_system"] = di_name
            cur = di["curves"][di_k]
            rec["di_auc"] = cur["auc"]; rec["di_advantage"] = cur["advantage"]
            rec["di_auc_ci"] = cur.get("auc_ci")
        out[name] = rec
        print(f"[RQ3] {name:12s} del={del_lat:.3f}s ret-p50={p50:.2f} ret-p99={p99:.2f}ms "
              f"e2e-p50={e50:.0f} e2e-p95={e95:.0f}ms "
              f"R@10={recall:.2f} nDCG={ndcg:.2f} rr={rr:.2f} zombie={z.asr_after:.2f}"
              + (f" DI-AUC={rec['di_auc']:.2f}" if with_di else ""))
    return save_json(cfg, "rq3_lsed", out), out
