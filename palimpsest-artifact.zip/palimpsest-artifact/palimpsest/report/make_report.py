"""Turn measured results (JSON) into paper artifacts:
  - LaTeX snippets with the real numbers, to replace the \\ph{...} placeholders
  - a real ROC figure (fig_di.pdf) from measured deletion-inference scores
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np


def _pct(x): return f"{100*x:.0f}"


def rq1_table_marks(rq1: dict) -> str:
    def mark(frac):
        return r"$\bullet$" if frac > 0.5 else (r"$\circ$" if frac > 0.05 else r"--")
    rows = []
    for name, r in rq1["systems"].items():
        rows.append(f"{name} & {r['deletion_option']} & "
                    f"{mark(r['tier1_frac'])} & {mark(r['tier2_frac'])} & {mark(r['tier3_frac'])} \\\\")
    return "\n".join(rows)


def rq2_recovery_table(rq2: dict) -> str:
    rr = rq2["residue_recovery"]; z = rq2["zombie"]
    def g(d, key): return _pct(d.get(key, {}).get("recovered_mean", 0.0)) if key in d else "--"
    lines = ["% residue recovery (naive) — replace matching \\ph cells"]
    for k, v in rr.items():
        lines.append(f"% {k}: recovered={_pct(v['recovered_mean'])}%  false={_pct(v['false_recovery_mean'])}%")
    lines.append("% zombie poisoning ASR")
    for k, v in z.items():
        lines.append(f"% {k}: before={_pct(v['before'])} after={_pct(v['after'])} cf={_pct(v['counterfactual'])}")
    return "\n".join(lines)


def rq3_table(rq3: dict) -> str:
    def row(label, key, fmt):
        return label + " & " + " & ".join(fmt(rq3[r][key]) for r in ("native","full_rebuild","lsed")) + r" \\"
    f2 = lambda x: f"{x:.2f}"; f1 = lambda x: f"{x:.1f}"; pc = lambda x: _pct(x)
    lines = [
        row("Deletion latency (s)", "deletion_latency_s", f2),
        r"Query latency p50 / p99 (ms) & " + " & ".join(
            f"{rq3[r]['query_p50_ms']:.0f} / {rq3[r]['query_p99_ms']:.0f}"
            for r in ("native","full_rebuild","lsed")) + r" \\",
        row("Canary facts recovered (\\%)", "recovered_after_delete", pc),
        row("Zombie poisoning success (\\%)", "zombie_after_delete", pc),
    ]
    return "\n".join(lines)


def make_di_figure(di_json: dict, out_pdf: str = "fig_di.pdf"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve
    fig, ax = plt.subplots(figsize=(3.3, 2.5))
    colors = ["#9aa0a6", "#4c78a8", "#e45756", "#54a24b", "#b279a2"]
    for i, (k, cur) in enumerate(sorted(di_json["curves"].items(), key=lambda kv: int(kv[0]))):
        fpr, tpr, _ = roc_curve(cur["labels"], cur["scores"])
        ax.plot(fpr, tpr, lw=1.6, color=colors[i % len(colors)],
                label=f"$k={k}$ (AUC {cur['auc']:.2f})")
    ax.plot([0,1],[0,1],"--",color="0.6",lw=0.8)
    ax.set_xscale("log"); ax.set_xlim(1e-3,1); ax.set_ylim(0,1)
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.legend(fontsize=6, loc="lower right", frameon=False); ax.tick_params(labelsize=7)
    fig.tight_layout(pad=0.3); fig.savefig(out_pdf, bbox_inches="tight")
    return out_pdf


def build_all(results_dir: str, out_dir: str = "."):
    results = Path(results_dir); outp = Path(out_dir)
    snippets = []
    if (results / "rq1_residue.json").exists():
        snippets.append("% ==== Table 3 (RQ1) rows ====\n" +
                        rq1_table_marks(json.loads((results/"rq1_residue.json").read_text())))
    if (results / "rq2_recovery_zombie.json").exists():
        snippets.append("% ==== Table 4 (RQ2) ====\n" +
                        rq2_recovery_table(json.loads((results/"rq2_recovery_zombie.json").read_text())))
    if (results / "rq3_lsed.json").exists():
        snippets.append("% ==== Table 5 (RQ3) rows ====\n" +
                        rq3_table(json.loads((results/"rq3_lsed.json").read_text())))
    for f in results.glob("rq2_di_*.json"):
        make_di_figure(json.loads(f.read_text()), str(outp / "fig_di.pdf"))
        snippets.append(f"% fig_di.pdf regenerated from {f.name}")
    (outp / "results_snippets.tex").write_text("\n\n".join(snippets))
    print(f"wrote {outp/'results_snippets.tex'}")
    return str(outp / "results_snippets.tex")
