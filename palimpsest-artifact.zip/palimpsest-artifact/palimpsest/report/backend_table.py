"""Summarize the LLM-backend sweep into JSON, Markdown, and a LaTeX table.

    python -m palimpsest.report.backend_table --backends configs/backends.yaml --results results

Writes results/backends/{summary.json, backends.md, backends_table.tex}.
Only measured values are reported; a missing run is shown as n/a, never imputed.
"""
import argparse, json
from pathlib import Path
import yaml


def _load(p: Path):
    return json.load(open(p)) if p.exists() else None


def collect(backends: list, results: Path) -> list:
    rows = []
    for b in backends:
        run = b.get("reuse") or f"be_{b['tag']}"
        r1 = _load(results / run / "rq1_residue.json")
        r2 = _load(results / run / "rq2_recovery_zombie.json")
        r2s = _load(results / f"{run}_onesent" / "rq2_recovery_zombie.json")
        row = {"tag": b["tag"], "label": b["label"], "run": run,
               "table": b.get("table", True), "compare_to": b.get("compare_to")}
        if r1:
            s = r1["systems"]
            row["tier3_graphrag"] = s.get("graphrag", {}).get("tier3_frac")
            row["tier3_memory"] = s.get("memory", {}).get("tier3_frac")
        if r2:
            rr, z = r2["residue_recovery"], r2["zombie"]
            row["rec_m1"] = rr["graphrag:naive"]["per_mechanism_client"].get("M1")
            row["rec_m4"] = rr["memory:naive"]["per_mechanism_client"].get("M4")
            row["rec_m3_rest"] = rr["graphrag:naive"]["per_mechanism_at_rest"].get("M3")
            row["rec_false"] = max(rr["graphrag:naive"]["false_recovery_mean"], rr["memory:naive"]["false_recovery_mean"])
            row["rec_lsed"] = max(rr["graphrag:lsed"]["recovered_mean"], rr["memory:lsed"]["recovered_mean"])
            row["zombie_before_g"] = z["graphrag:naive"]["before"]
            row["zombie_after_g"] = z["graphrag:naive"]["after"]
            row["zombie_before_m"] = z["memory:naive"]["before"]
            row["zombie_after_m"] = z["memory:naive"]["after"]
            row["zombie_cf"] = max(z["graphrag:naive"]["counterfactual"], z["memory:naive"]["counterfactual"])
            row["zombie_lsed"] = max(z["graphrag:lsed"]["after"], z["memory:lsed"]["after"])
        if r2s:
            row["rec_m1_short"] = r2s["residue_recovery"]["graphrag:naive"]["per_mechanism_client"].get("M1")
        rows.append(row)
    return rows


def pct(v):
    return "n/a" if v is None else f"{100 * v:.0f}"


def frac10(v):
    return "n/a" if v is None else f"{round(10 * v)}/10"


def to_markdown(rows) -> str:
    h = ("| Backend | Tier III (G / M) | M1 | M1 short | M4 | Zombie G before/after | "
         "Zombie M before/after | Counterfactual | LSED rec. / zombie |\n|" + "---|" * 9 + "\n")
    for r in rows:
        h += (f"| {r['label']} | {frac10(r.get('tier3_graphrag'))} / {frac10(r.get('tier3_memory'))} | "
              f"{pct(r.get('rec_m1'))} | {pct(r.get('rec_m1_short'))} | {pct(r.get('rec_m4'))} | "
              f"{pct(r.get('zombie_before_g'))}/{pct(r.get('zombie_after_g'))} | "
              f"{pct(r.get('zombie_before_m'))}/{pct(r.get('zombie_after_m'))} | "
              f"{pct(r.get('zombie_cf'))} | {pct(r.get('rec_lsed'))} / {pct(r.get('zombie_lsed'))} |\n")
    return h


def to_latex(rows) -> str:
    out = [r"\begin{tabularx}{\linewidth}{@{}l*{6}{>{\centering\arraybackslash}X}@{}}",
           r"\toprule",
           r" & \multicolumn{3}{c}{Recovered (\%)} & \multicolumn{2}{c}{Zombie after (\%)} & \\",
           r"\cmidrule(lr){2-4}\cmidrule(lr){5-6}",
           r"\thd{Backend} & \thd{M1} & \thd{M1 short} & \thd{M4} & \thd{Graph} & \thd{Memory} & \thd{\lsed{}} \\",
           r"\midrule"]
    for r in rows:
        lsed = "0" if (r.get("rec_lsed") == 0 and r.get("zombie_lsed") == 0) else \
               f"{pct(r.get('rec_lsed'))}\\,/\\,{pct(r.get('zombie_lsed'))}"
        out.append(f"{r['label']} & {pct(r.get('rec_m1'))} & {pct(r.get('rec_m1_short'))} & {pct(r.get('rec_m4'))} & "
                   f"{pct(r.get('zombie_after_g'))} & {pct(r.get('zombie_after_m'))} & {lsed} \\\\")
    out += [r"\bottomrule", r"\end{tabularx}"]
    return "\n".join(out) + "\n"


REPRO_KEYS = ["tier3_graphrag", "tier3_memory", "rec_m1", "rec_m1_short", "rec_m4",
              "zombie_after_g", "zombie_after_m", "zombie_cf", "rec_lsed", "zombie_lsed"]


def repro_report(rows) -> str:
    """Compare each rerun with the run it reproduces, metric by metric."""
    by_tag = {r["tag"]: r for r in rows}
    out = []
    for r in rows:
        ref = by_tag.get(r.get("compare_to") or "")
        if not ref:
            continue
        out.append(f"## Reproducibility: {r['label']} vs {ref['label']}\n")
        out.append("| Metric | Paper run | Rerun | Abs. diff (pp) |\n|---|---|---|---|\n")
        for k in REPRO_KEYS:
            a, b = ref.get(k), r.get(k)
            d = "n/a" if a is None or b is None else f"{100 * abs(a - b):.1f}"
            out.append(f"| {k} | {pct(a)} | {pct(b)} | {d} |\n")
    return "".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backends", default="configs/backends.yaml")
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.backends))
    results = Path(a.results)
    rows = collect(cfg["backends"], results)
    out = results / "backends"; out.mkdir(parents=True, exist_ok=True)
    json.dump(rows, open(out / "summary.json", "w"), indent=2)
    shown = [r for r in rows if r.get("table", True)]
    repro = repro_report(rows)
    (out / "backends.md").write_text(to_markdown(shown) + ("\n" + repro if repro else ""))
    (out / "backends_table.tex").write_text(to_latex(shown))
    print(to_markdown(shown))
    if repro:
        print(repro)
    print(f"wrote {out}/summary.json, backends.md, backends_table.tex")


if __name__ == "__main__":
    main()
