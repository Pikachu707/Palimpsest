"""LLM and embedding clients.

LLM backends:
  - "vllm":   local OpenAI-compatible server (recommended on a GPU server)
  - "openai": hosted OpenAI-compatible API (needs api key)
  - "echo":   offline deterministic double for CI / CPU smoke tests

Embedding backends:
  - "sentence_transformers": local GPU model (recommended)
  - "hash":  offline deterministic double (no GPU, no downloads)

The "echo"/"hash" doubles let the whole pipeline run on CPU with no model
downloads, which is how the smoke tests validate control flow.
"""
from __future__ import annotations
import hashlib
import os
import re
from typing import Optional
import numpy as np

from .config import LLMConfig, EmbeddingConfig


# ----------------------------------------------------------------------
# LLM
# ----------------------------------------------------------------------
class LLM:
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        self._client = None
        if cfg.backend in ("vllm", "openai"):
            from openai import OpenAI  # lazy import
            if cfg.backend == "vllm":
                self._client = OpenAI(base_url=cfg.base_url, api_key="EMPTY")
            else:
                self._client = OpenAI(api_key=os.environ[cfg.api_key_env])

    def complete(self, system: str, user: str, seed: Optional[int] = None) -> str:
        """One completion, memoized on (system, user).

        Memoization is exact only for greedy decoding, so it is enabled iff
        temperature == 0 (the configuration LSED requires anyway). Across the
        paired worlds of counterfactual replay it also removes vLLM's batch-level
        nondeterminism: an identical prompt yields an identical output in both
        worlds, so any difference is attributable to the deleted record."""
        user = self._clip(user)
        key = (system, user)
        if self._memo_on and key in self._memo:
            return self._memo[key]
        out = self._call(system, user, seed)
        if self._memo_on:
            self._memo[key] = out
        return out

    def complete_many(self, pairs: list[tuple[str, str]]) -> list[str]:
        """Complete many independent prompts concurrently (vLLM batches them).
        Duplicates and memo hits are resolved without a request."""
        pairs = [(sy, self._clip(u)) for sy, u in pairs]
        todo = list(dict.fromkeys(p for p in pairs
                                  if not (self._memo_on and p in self._memo)))
        if todo:
            if self.cfg.backend == "echo" or self.cfg.max_concurrency <= 1:
                results = [self._call(sy, u, None) for sy, u in todo]
            else:
                from concurrent.futures import ThreadPoolExecutor
                with ThreadPoolExecutor(max_workers=self.cfg.max_concurrency) as ex:
                    results = list(ex.map(lambda p: self._call(p[0], p[1], None), todo))
            local = dict(zip(todo, results))
            if self._memo_on:
                self._memo.update(local)
        else:
            local = {}
        return [self._memo[p] if (self._memo_on and p in self._memo) else local[p]
                for p in pairs]

    @property
    def _memo_on(self) -> bool:
        return self.cfg.temperature == 0.0 and not getattr(self, "_bypass", False)

    def uncached(self):
        """Context manager: bypass the memo. REQUIRED around anything whose
        wall-clock time is measured (deletion latency, query latency, timing
        channel): a memo hit costs ~0 ms and would make latencies meaningless."""
        import contextlib
        @contextlib.contextmanager
        def _cm():
            prev = getattr(self, "_bypass", False)
            self._bypass = True
            try:
                yield self
            finally:
                self._bypass = prev
        return _cm()

    @property
    def _memo(self) -> dict:
        """Memo partitioned by model: completions of one backend can never be
        served for another, even if cfg.model changes on a live instance."""
        if not hasattr(self, "_memo_store"):
            self._memo_store: dict = {}
        return self._memo_store.setdefault(self.cfg.model, {})

    def _clip(self, user: str) -> str:
        """Cap the prompt so one oversized request cannot abort a long run
        (max_model_len 8192 tokens ~ 4 chars/token, minus output budget)."""
        cap = self.cfg.max_prompt_chars
        if cap and len(user) > cap:
            self.n_clipped = getattr(self, "n_clipped", 0) + 1
            return user[:cap]
        return user

    def _call(self, system: str, user: str, seed: Optional[int]) -> str:
        if self.cfg.backend == "echo":
            return self._echo(system, user, seed)
        mode = getattr(self, "_system_mode", None) or self.cfg.system_role
        if mode == "merge":
            return self._request([{"role": "user", "content": f"{system}\n\n{user}"}], seed)
        try:
            return self._request([{"role": "system", "content": system},
                                  {"role": "user", "content": user}], seed)
        except Exception as e:  # e.g. Gemma-2: "System role not supported"
            if mode == "auto" and self._rejects_system_role(e):
                self._system_mode = "merge"
                return self._call(system, user, seed)
            raise

    def _request(self, messages: list, seed: Optional[int]) -> str:
        resp = self._client.chat.completions.create(
            model=self.cfg.model,
            messages=messages,
            max_tokens=self.cfg.max_tokens,
            temperature=self.cfg.temperature,
            seed=seed,
            timeout=self.cfg.request_timeout_s,
        )
        return resp.choices[0].message.content or ""

    @staticmethod
    def _rejects_system_role(e: Exception) -> bool:
        msg = str(e).lower()
        return "system" in msg and ("role" in msg or "not supported" in msg)

    # -- offline double: echoes any high-entropy tokens it is given, so residue
    #    propagation is exercised deterministically without a real model.
    @staticmethod
    def _echo(system: str, user: str, seed: Optional[int]) -> str:
        toks = re.findall(r"\b[A-Z0-9]{8,}\b", user)
        joined = "; ".join(dict.fromkeys(toks))
        return f"[echo] {joined}" if joined else "[echo] (no salient facts)"


# ----------------------------------------------------------------------
# Embeddings
# ----------------------------------------------------------------------
class Embedder:
    def __init__(self, cfg: EmbeddingConfig):
        self.cfg = cfg
        self._model = None
        if cfg.backend == "sentence_transformers":
            from sentence_transformers import SentenceTransformer  # lazy
            self._model = SentenceTransformer(cfg.model, device=cfg.device)
            m = self._model
            getdim = getattr(m, "get_embedding_dimension", None) or m.get_sentence_embedding_dimension
            self.dim = getdim()
        else:
            self.dim = cfg.dim

    def encode(self, texts: list[str]) -> np.ndarray:
        """Encode with a text->vector memo. Embeddings are deterministic, so
        caching is exact; it turns the DI shadow loop (hundreds of deployments
        over the same corpus) from O(deployments x corpus) encodes into
        O(corpus)."""
        if not hasattr(self, "_cache"):
            self._cache: dict[str, np.ndarray] = {}
        missing = list(dict.fromkeys(t for t in texts if t not in self._cache))
        if missing:
            if self.cfg.backend == "sentence_transformers":
                v = self._model.encode(missing, batch_size=self.cfg.batch_size,
                                       normalize_embeddings=self.cfg.normalize,
                                       convert_to_numpy=True).astype("float32")
            else:
                v = self._hash_encode(missing)
            for t, vec in zip(missing, v):
                self._cache[t] = vec
        if not texts:
            return np.zeros((0, self.dim), dtype="float32")
        return np.stack([self._cache[t] for t in texts]).astype("float32")

    def _hash_encode(self, texts: list[str]) -> np.ndarray:
        """Deterministic bag-of-hashed-tokens embedding (offline double)."""
        d = self.cfg.dim
        out = np.zeros((len(texts), d), dtype="float32")
        for i, t in enumerate(texts):
            for tok in re.findall(r"\w+", t.lower()):
                h = int(hashlib.blake2b(tok.encode(), digest_size=8).hexdigest(), 16)
                out[i, h % d] += 1.0
            n = np.linalg.norm(out[i])
            if self.cfg.normalize and n > 0:
                out[i] /= n
        return out
