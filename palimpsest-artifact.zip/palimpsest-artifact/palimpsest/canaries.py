"""Synthetic personas carrying high-entropy canary facts.

A *canary fact* is a random token that the LLM cannot produce without having
derived it from the canary document (its appearance in any artifact or output
is therefore evidence of residue). We attach several canary facts to each of a
subject's documents so that residue can be traced per document.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import random
import string


def _rand_token(rng: random.Random, n: int = 12) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(rng.choice(alphabet) for _ in range(n))


# High-entropy value spaces. Values are unique random tokens => negligible
# probability of appearing without derivation from the canary.
FACT_TEMPLATES = [
    ("employer", "works at {v}"),
    ("project", "is assigned to project {v}"),
    ("clearance", "holds clearance code {v}"),
    ("address", "lives at unit {v}"),
    ("device", "uses device serial {v}"),
]


@dataclass
class CanaryFact:
    subject_id: str
    doc_id: str
    kind: str          # e.g. "employer"
    value: str         # the high-entropy token; this is what we search for
    entropy_bits: float

    def phrase(self) -> str:
        template = dict(FACT_TEMPLATES)[self.kind]
        return template.format(v=self.value)


@dataclass
class Document:
    doc_id: str
    subject_id: str
    text: str
    facts: list[CanaryFact] = field(default_factory=list)
    is_poison: bool = False


@dataclass
class Subject:
    subject_id: str
    name: str
    manager: str
    docs: list[Document] = field(default_factory=list)

    def all_facts(self) -> list[CanaryFact]:
        return [f for d in self.docs for f in d.facts]


_FIRST = ["Alice", "Bob", "Carol", "Dave", "Erin", "Frank", "Grace", "Heidi",
          "Ivan", "Judy", "Mallory", "Niaj", "Olivia", "Peggy", "Rupert", "Sybil",
          "Trent", "Victor", "Wendy", "Xavier", "Yolanda", "Zane"]
_LAST = ["Ng", "Osei", "Kovac", "Rossi", "Haddad", "Silva", "Nakamura", "Abadi",
         "Petrov", "Larsson", "Owens", "Diallo", "Fischer", "Costa", "Adeyemi"]


def _person_name(rng: random.Random, i: int) -> str:
    return f"{_FIRST[i % len(_FIRST)]} {rng.choice(_LAST)}-{i:04d}"


def build_subject(rng: random.Random, i: int, docs_per_subject: int,
                  facts_per_doc: int, manager: str = None) -> Subject:
    sid = f"S{i:05d}"
    name = _person_name(rng, i)
    if manager is None:
        manager = _person_name(rng, (i * 7 + 3) % 100000)
    subj = Subject(subject_id=sid, name=name, manager=manager)
    kinds = [k for k, _ in FACT_TEMPLATES]
    for j in range(docs_per_subject):
        did = f"{sid}-D{j}"
        facts = []
        for _ in range(facts_per_doc):
            kind = rng.choice(kinds)
            val = _rand_token(rng)
            # entropy: 12 chars over 36-symbol alphabet
            facts.append(CanaryFact(sid, did, kind, val,
                                    entropy_bits=12 * (36 ** 0)  # placeholder; see below
                                    ))
        # correct entropy computation (bits = n*log2(|alphabet|))
        import math
        for f in facts:
            f.entropy_bits = 12 * math.log2(36)
        # Compose a natural-ish document that mentions the subject, the manager,
        # and the canary facts, so extraction pipelines create merged entities.
        sentences = [f"{name} is an employee." ,
                     f"{name} reports to {manager}."]
        for f in facts:
            sentences.append(f"{name} {f.phrase()}.")
        subj.docs.append(Document(did, sid, " ".join(sentences), facts))
    return subj


MANAGER_OFFSET = 90_000   # manager name indices (disjoint from subjects/targets)


def manager_name(seed: int, m: int) -> str:
    """Deterministic name of manager m (independent of the subject RNG stream)."""
    return _person_name(random.Random(f"mgr:{seed}:{m}"), MANAGER_OFFSET + m)


def build_population(n_subjects: int, docs_per_subject: int,
                     facts_per_doc: int, seed: int = 0,
                     offset: int = 0, subjects_per_manager: int = 10) -> list[Subject]:
    """`offset` shifts subject indices so that independently built populations
    (e.g. deletion-inference targets vs. background) have disjoint ids/names.

    Managers are SHARED: each manages `subjects_per_manager` subjects, so a
    manager's merged description mixes facts from several subjects' documents
    (the running example: Bob manages Alice, Carol, and Dave). Deleting one
    subject then requires re-rendering a description that also exists in the
    counterfactual world."""
    rng = random.Random(seed)
    spm = max(1, int(subjects_per_manager))
    return [build_subject(rng, offset + i, docs_per_subject, facts_per_doc,
                          manager=manager_name(seed, (offset + i) // spm))
            for i in range(n_subjects)]


def make_poison_documents(rng: random.Random, target_entity: str,
                          false_claim_value: str, n: int = 5) -> list[Document]:
    """Zombie-poisoning payload: documents asserting a false relation about a
    (typically popular) entity, so extraction folds it into merged descriptions.

    `false_claim_value` should be a high-entropy alnum token so that its
    appearance in an answer is attributable to the poison (like a canary fact).
    The text is phrased so per-chunk extractors emit a (target; relation; value)
    triple that merges into the target entity's shared description.
    """
    docs = []
    for k in range(n):
        did = f"POISON-{target_entity}-{k}"
        text = (f"{target_entity} is associated with {false_claim_value}. "
                f"{target_entity} works at {false_claim_value}. "
                f"Multiple sources confirm {target_entity} and {false_claim_value}.")
        docs.append(Document(did, subject_id="__poison__", text=text,
                             facts=[], is_poison=True))
    return docs
