"""System-Under-Test interface.

Every SUT implements ingest / delete / query, plus introspection hooks that the
Palimpsest harness uses for canary lineage tracing and counterfactual replay:

  - artifact_signature(): a hashable snapshot of an internal artifact class,
    used to compare the deletion world with the counterfactual world.
  - client_observation(query): what a client can observe (ranks, scores, text,
    latency), used by the attacks and the probing step.

The two ANN systems below expose real structural signatures (graph edges,
codebooks). The compound systems additionally expose text artifacts.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol
import time


@dataclass
class Hit:
    doc_id: str
    score: float
    rank: int
    text: Optional[str] = None


@dataclass
class Observation:
    hits: list[Hit]
    text: Optional[str] = None     # generated answer, if the SUT generates
    latency_s: float = 0.0

    def ranks(self) -> dict[str, int]:
        return {h.doc_id: h.rank for h in self.hits}

    def scores(self) -> dict[str, float]:
        return {h.doc_id: h.score for h in self.hits}


class SystemUnderTest(Protocol):
    name: str
    deletion_option: str

    def ingest(self, docs) -> None: ...
    def delete(self, doc_ids: list[str]) -> None: ...
    def query(self, text: str, k: int = 10) -> Observation: ...

    # introspection
    def artifact_signatures(self) -> dict[str, Any]: ...
    def contains_text(self, needle: str) -> list[str]: ...


def timed_query(fn, *args, **kwargs) -> Observation:
    t0 = time.perf_counter()
    obs = fn(*args, **kwargs)
    obs.latency_s = time.perf_counter() - t0
    return obs


class PaddedSUT:
    """Wrap any SUT so every query's latency is rounded UP to a multiple of
    `quantum_ms` (latency padding, the timing mitigation in the paper's
    "Timing and audit" paragraph). Delegates everything else unchanged."""

    def __init__(self, inner, quantum_ms: float):
        self.inner = inner
        self.quantum_ms = quantum_ms
        self.name = f"{inner.name}+pad{quantum_ms:g}ms"
        self.deletion_option = inner.deletion_option

    def __getattr__(self, item):           # ingest/delete/introspection
        return getattr(self.inner, item)

    def query(self, text: str, k: int = 10) -> Observation:
        import math
        t0 = time.perf_counter()
        obs = self.inner.query(text, k)
        if self.quantum_ms > 0:
            q = self.quantum_ms / 1000.0
            el = time.perf_counter() - t0
            tgt = math.ceil(el / q) * q
            if tgt > el:
                time.sleep(tgt - el)
        obs.latency_s = time.perf_counter() - t0
        return obs
