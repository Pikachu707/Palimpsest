"""Systems under test.

Fully-real, dependency-light SUTs (run on a single GPU server):
    FaissSUT (hnsw / ivfpq), HnswlibSUT, MiniGraphRAG, MiniMemory

External adapters (optional, validate against the named systems). These wrap
the real libraries' documented interfaces; because those APIs move between
versions, each adapter is guarded and marked with a VERIFY note. Install the
corresponding package and implement/confirm the calls before use.
"""
from .base import SystemUnderTest, Observation, Hit
from .ann_faiss import FaissSUT
from .ann_hnswlib import HnswlibSUT
from .graphrag_mini import MiniGraphRAG
from .memory_mini import MiniMemory

__all__ = ["SystemUnderTest", "Observation", "Hit",
           "FaissSUT", "HnswlibSUT", "MiniGraphRAG", "MiniMemory",
           "build_registry"]


def build_registry(llm, embedder, emb_dim, hnsw_kw=None, ivfpq_train_size=0):
    """Return the default set of SUTs used by RQ1."""
    reg = {
        "faiss-hnsw":  lambda: FaissSUT(embedder, emb_dim, kind="hnsw",  deletion_option="rebuild"),
        "faiss-ivfpq": lambda: FaissSUT(embedder, emb_dim, kind="ivfpq",
                                       deletion_option="remove_ids",
                                       train_size=ivfpq_train_size),
        "hnswlib":     lambda: HnswlibSUT(embedder, emb_dim, deletion_option="mark_deleted",
                                      **(hnsw_kw or {})),
        "graphrag":    lambda: MiniGraphRAG(llm, embedder, deletion_option="naive"),
        "memory":      lambda: MiniMemory(llm, deletion_option="naive"),
    }
    return reg
