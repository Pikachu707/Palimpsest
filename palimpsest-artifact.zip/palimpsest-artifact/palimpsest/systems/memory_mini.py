"""MiniMemory: a controlled agent-memory SUT.

Models the consolidation pattern of Mem0/Letta: each user's interactions are
summarized by an LLM into a long-lived memory entry, so one entry mixes facts
from several interactions (mechanism M4). Memory is kept PER SUBJECT, as in the
paper's running example (Alice's memory consolidates Alice's sessions); this
also keeps every consolidation prompt small regardless of corpus size.

Deleting an interaction erases its copy (Tier I) but, by default ("naive"),
does not re-consolidate the entry, so its facts survive (Tier III). The "lsed"
option keeps provenance-tagged atoms and re-renders exactly the affected entries.
Queries are routed to the entries of the people they name.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import re

from .base import Hit, Observation, timed_query

_NAME = re.compile(r"[A-Z][a-z]+ [A-Z][a-z]+-\d{4,5}")   # synthetic person names


@dataclass
class MemAtom:
    fact: str
    key: str
    provenance: set[str] = field(default_factory=set)


class MiniMemory:
    _CONSOLIDATE_SYS = "Consolidate these facts into a compact memory. Keep any codes verbatim."
    _ANSWER_SYS = "Answer using only the memory. Quote codes verbatim if present."
    client_mechanisms = frozenset({"M4"})

    def __init__(self, llm, deletion_option: str = "naive", max_routed: int = 10):
        self.name = "MiniMemory"
        self.deletion_option = deletion_option
        self.llm = llm
        self.max_routed = max_routed
        self._interactions: dict[str, str] = {}
        self._key_of: dict[str, str] = {}
        self._deleted: set[str] = set()
        self._atoms: list[MemAtom] = []
        self._entries: dict[str, str] = {}      # memory key -> consolidated entry
        self._names: dict[str, set[str]] = {}   # memory key -> people it mentions

    @staticmethod
    def _key(doc) -> str:
        """Memory owner: the data subject; each poison campaign is its own
        'user'; any other synthetic record is its own entry."""
        sid = str(getattr(doc, "subject_id", "__misc__"))
        if not sid.startswith("__"):
            return sid
        if sid == "__poison__":
            return doc.doc_id.rsplit("-", 1)[0]
        return doc.doc_id

    @staticmethod
    def _facts(text: str) -> list[str]:
        return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s]

    def ingest(self, docs) -> None:
        touched = set()
        for d in docs:
            k = self._key(d)
            self._interactions[d.doc_id] = d.text
            self._key_of[d.doc_id] = k
            self._names.setdefault(k, set()).update(_NAME.findall(d.text))
            for f in self._facts(d.text):
                self._atoms.append(MemAtom(fact=f, key=k, provenance={d.doc_id}))
            touched.add(k)
        self._consolidate(touched)

    def _consolidate(self, keys) -> None:
        live: dict[str, list[str]] = {}
        for a in self._atoms:
            if a.key in keys and (a.provenance - self._deleted):
                live.setdefault(a.key, []).append(a.fact)
        for k in keys:
            if k not in live:
                self._entries.pop(k, None)
        order = sorted(live)
        outs = self.llm.complete_many([(self._CONSOLIDATE_SYS, " ".join(live[k])) for k in order])
        self._entries.update(zip(order, outs))

    def delete(self, doc_ids: list[str]) -> None:
        affected = set()
        for did in doc_ids:
            self._deleted.add(did)
            self._interactions.pop(did, None)   # copy erasure (Tier I)
            if did in self._key_of:
                affected.add(self._key_of[did])
        if self.deletion_option == "lsed":
            self._atoms = [a for a in self._atoms if (a.provenance - self._deleted)]
            self._consolidate(affected)
            for k in affected:
                if k not in self._entries:
                    self._names.pop(k, None)
        # naive: entries (and the routing index) are left as-is -> residue survives

    def _route(self, text: str) -> list[str]:
        named = set(_NAME.findall(text))
        keys = sorted(k for k, ns in self._names.items() if ns & named and k in self._entries)
        return keys[: self.max_routed]

    def _query(self, text: str, k: int = 10) -> Observation:
        keys = self._route(text)
        memory = "\n".join(f"- {self._entries[key]}" for key in keys)
        ans = self.llm.complete(self._ANSWER_SYS, f"Memory:\n{memory}\n\nQuestion: {text}")
        hits = [Hit(f"memory:{key}", 1.0, i, self._entries[key]) for i, key in enumerate(keys)]
        return Observation(hits=hits, text=ans)

    def query(self, text: str, k: int = 10) -> Observation:
        return timed_query(self._query, text, k)

    def artifact_signatures(self) -> dict[str, Any]:
        # A flat memory store has no structural (Tier II) artifacts; entries
        # and atoms are LLM-derived text (Tier III), checked via contains_text.
        return {"n_interactions_live": len(self._interactions)}

    def residue_sources(self, needle: str) -> set[str]:
        """M4 = consolidated memory entries."""
        return {"M4"} if any(needle in e for e in self._entries.values()) else set()

    def contains_text(self, needle: str) -> list[str]:
        out = [f"doc:{did}" for did, t in self._interactions.items() if needle in t]
        out += [f"memory:{k}" for k, e in self._entries.items() if needle in e]
        out += ["memory:atom" for a in self._atoms if needle in a.fact]
        return out
