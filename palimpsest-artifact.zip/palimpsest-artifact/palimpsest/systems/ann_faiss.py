"""FAISS system under test: HNSW and IVF-PQ.

IVF-PQ exposes Tier-II quantizer residue directly (centroids + PQ codebooks are
readable from the trained index), which is the cleanest structural-residue case.
"""
from __future__ import annotations
from typing import Any
import numpy as np
import faiss

# Deterministic construction/training (see ann_hnswlib for why this matters).
faiss.omp_set_num_threads(1)

from .base import Hit, Observation, timed_query


class FaissSUT:
    def __init__(self, embedder, dim: int, kind: str = "hnsw",
                 deletion_option: str = "remove_ids",
                 nlist: int = 64, m_pq: int = 16, nbits: int = 8,
                 hnsw_m: int = 32, seed: int = 100, train_size: int = 0,
                 nprobe: int = 1):
        assert kind in ("hnsw", "ivfpq")
        self.name = f"faiss-{kind}"
        self.kind = kind
        self.deletion_option = deletion_option  # "remove_ids" or "rebuild"
        self.embedder = embedder
        self.dim = dim
        self.nlist = nlist; self.m_pq = m_pq; self.nbits = nbits; self.hnsw_m = hnsw_m
        self.seed = seed
        # Configured corpus size that fixes the quantizer geometry across worlds.
        # 0 => use this batch's size (fine for one index, NOT for replay, where
        # the deletion and counterfactual worlds differ in vector count).
        self.train_size = train_size
        # IVF lists searched per query. FAISS defaults to 1; production systems
        # typically use 8-64. Deletion residue in the coarse quantizer (a
        # "ghost" centroid whose list is emptied) is most visible at small nprobe.
        self.nprobe = nprobe
        self._docs: dict[str, tuple[int, str]] = {}
        self._id2doc: dict[int, str] = {}
        self._deleted: set[str] = set()
        self._next_id = 0
        self._order: list[str] = []
        self._index = None
        self._trained = False

    def _new_index(self, nlist=None, nbits=None):
        try:
            faiss.seed_global_rng(self.seed)   # not present in all builds
        except AttributeError:
            pass
        if self.kind == "hnsw":
            base = faiss.IndexHNSWFlat(self.dim, self.hnsw_m)
            self._index = faiss.IndexIDMap2(base)
            self._trained = True
        else:
            nlist = nlist or self.nlist; nbits = nbits or self.nbits
            quant = faiss.IndexFlatL2(self.dim)
            ivf = faiss.IndexIVFPQ(quant, self.dim, nlist, self.m_pq, nbits)
            self._index = faiss.IndexIDMap2(ivf)
            self._trained = False
            self.effective = {"nlist": nlist, "nbits": nbits, "m_pq": self.m_pq}

    def _maybe_train(self, vecs: np.ndarray):
        """Train IVF-PQ on the first ingested batch. Training on the data is
        exactly what puts records into the codebook lineage (Tier II).

        k-means needs >= nlist points for the coarse quantizer and >= 2^nbits
        per PQ sub-quantizer; at small (smoke) scale we shrink nlist/nbits to fit
        and record the effective values. At full experiment scale (~1e4 vectors) the
        configured nlist=64, nbits=8 are used unchanged."""
        if self._trained:
            return
        # Geometry (nlist, nbits) is a function of the CONFIGURED corpus size,
        # NOT of this world's vector count -- otherwise counterfactual replay
        # would detect the parameter change, not the deletion residue.
        target_n = self.train_size if self.train_size else len(vecs)
        nlist = max(1, min(self.nlist, target_n // 39 if target_n >= 39 else 1))
        nbits = max(1, min(self.nbits, int(np.floor(np.log2(max(target_n, 2))))))
        # k-means still cannot have more centroids than training points given;
        # clamp identically in both worlds (train_size is fixed, so this ties).
        n = len(vecs)
        nlist = min(nlist, max(1, n))
        nbits = min(nbits, max(1, int(np.floor(np.log2(max(n, 2))))))
        if (nlist, nbits) != (self.nlist, self.nbits):
            self._new_index(nlist=nlist, nbits=nbits)
        inner = faiss.downcast_index(self._index.index)
        inner.train(vecs)
        inner.nprobe = max(1, min(self.nprobe, inner.nlist))
        self._trained = True

    def ingest(self, docs) -> None:
        if self._index is None:
            self._new_index()
        texts = [d.text for d in docs]
        vecs = self.embedder.encode(texts).astype("float32")
        self._maybe_train(vecs)
        ids = []
        for d in docs:
            i = self._next_id; self._next_id += 1
            self._docs[d.doc_id] = (i, d.text)
            self._id2doc[i] = d.doc_id
            self._order.append(d.doc_id)
            ids.append(i)
        self._index.add_with_ids(vecs, np.asarray(ids, dtype="int64"))

    def delete(self, doc_ids: list[str]) -> None:
        if self.deletion_option == "rebuild":
            self._rebuild_without(doc_ids); return
        sel = []
        for did in doc_ids:
            if did in self._docs and did not in self._deleted:
                sel.append(self._docs[did][0]); self._deleted.add(did)
        if sel:
            self._index.remove_ids(np.asarray(sel, dtype="int64"))

    def _rebuild_without(self, doc_ids: list[str]):
        keep = [d for d in self._order if d not in set(doc_ids) and d not in self._deleted]
        old = {did: self._docs[did][1] for did in keep}
        self._new_index()
        self._docs.clear(); self._id2doc.clear(); self._deleted.clear()
        self._next_id = 0; self._order = []
        from types import SimpleNamespace
        self.ingest([SimpleNamespace(doc_id=d, text=old[d]) for d in keep])

    def _query(self, text: str, k: int = 10) -> Observation:
        v = self.embedder.encode([text]).astype("float32")
        if not self._trained or self._index.ntotal == 0:
            return Observation(hits=[])
        D, I = self._index.search(v, min(k, self._index.ntotal))
        hits = []
        for rank, (i, d) in enumerate(zip(I[0], D[0])):
            did = self._id2doc.get(int(i))
            if did is None or did in self._deleted:
                continue
            hits.append(Hit(doc_id=did, score=float(-d), rank=rank,
                            text=self._docs[did][1]))
        return Observation(hits=hits)

    def query(self, text: str, k: int = 10) -> Observation:
        return timed_query(self._query, text, k)

    def artifact_signatures(self) -> dict[str, Any]:
        sig: dict[str, Any] = {"ntotal": int(self._index.ntotal) if self._index else 0}
        if self.kind == "ivfpq":
            sig["effective_params"] = str(getattr(self, "effective", {}))
        if self.kind == "ivfpq" and self._trained:
            inner = faiss.downcast_index(self._index.index)
            # PQ codebook centroids: the trained artifact carrying data lineage
            pq = inner.pq
            cb = faiss.vector_to_array(pq.centroids).reshape(pq.M, pq.ksub, pq.dsub)
            sig["pq_codebook"] = cb.astype("float32").ravel()
            # IVF coarse centroids
            quant = faiss.downcast_index(inner.quantizer)
            cent = quant.reconstruct_n(0, quant.ntotal)
            sig["ivf_centroids"] = cent.astype("float32").ravel()
        return sig

    def contains_text(self, needle: str) -> list[str]:
        return [did for did, (_, txt) in self._docs.items()
                if did not in self._deleted and needle in txt]
