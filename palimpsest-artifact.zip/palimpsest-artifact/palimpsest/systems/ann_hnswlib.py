"""hnswlib system under test.

Exposes Tier-I (tombstone) and Tier-II (graph edge) residue. The graph edges
are read directly from the index, which is what makes structural residue after
`mark_deleted` measurable in counterfactual replay.
"""
from __future__ import annotations
from typing import Any, Optional
import numpy as np
import hnswlib

from .base import Hit, Observation, timed_query


class HnswlibSUT:
    def __init__(self, embedder, dim: int, deletion_option: str = "mark_deleted",
                 M: int = 16, ef_construction: int = 200, ef: int = 64,
                 max_elements: int = 100000, seed: int = 100):
        self.name = "hnswlib"
        self.deletion_option = deletion_option  # "mark_deleted" or "rebuild"
        self.embedder = embedder
        self.dim = dim
        self.M = M; self.ef_construction = ef_construction; self.ef = ef
        self.max_elements = max_elements
        self.seed = seed
        self._new_index()
        self._docs: dict[str, tuple[int, str]] = {}   # doc_id -> (label, text)
        self._label2doc: dict[int, str] = {}
        self._deleted: set[str] = set()
        self._next_label = 0
        self._order: list[str] = []                    # insertion order (for rebuild)

    def _new_index(self):
        idx = hnswlib.Index(space="cosine", dim=self.dim)
        idx.init_index(max_elements=self.max_elements, ef_construction=self.ef_construction,
                       M=self.M, random_seed=self.seed)
        idx.set_ef(self.ef)
        self.index = idx

    # -- lifecycle --------------------------------------------------------
    def ingest(self, docs) -> None:
        texts = [d.text for d in docs]
        vecs = self.embedder.encode(texts)
        labels = []
        for d in docs:
            lbl = self._next_label; self._next_label += 1
            self._docs[d.doc_id] = (lbl, d.text)
            self._label2doc[lbl] = d.doc_id
            self._order.append(d.doc_id)
            labels.append(lbl)
        # num_threads=1 is REQUIRED for counterfactual replay: multithreaded
        # HNSW construction is nondeterministic, so two identical worlds would
        # differ by thread scheduling alone and masquerade as Tier-II residue.
        self.index.add_items(vecs, np.asarray(labels), num_threads=1)

    def delete(self, doc_ids: list[str]) -> None:
        if self.deletion_option == "rebuild":
            self._rebuild_without(doc_ids)
            return
        for did in doc_ids:
            if did in self._docs and did not in self._deleted:
                lbl, _ = self._docs[did]
                try:
                    self.index.mark_deleted(lbl)
                except RuntimeError:
                    pass
                self._deleted.add(did)

    def _rebuild_without(self, doc_ids: list[str]):
        keep = [d for d in self._order if d not in set(doc_ids) and d not in self._deleted]
        old_texts = {did: self._docs[did][1] for did in keep}
        self._new_index()
        self._docs.clear(); self._label2doc.clear(); self._deleted.clear()
        self._next_label = 0; order = self._order; self._order = []
        from types import SimpleNamespace
        self.ingest([SimpleNamespace(doc_id=d, text=old_texts[d]) for d in keep])

    # -- query ------------------------------------------------------------
    def _query(self, text: str, k: int = 10) -> Observation:
        v = self.embedder.encode([text])
        n = max(1, len(self._docs) - len(self._deleted))
        labels, dists = self.index.knn_query(v, k=min(k, n), num_threads=1)
        hits = []
        for rank, (lbl, dist) in enumerate(zip(labels[0], dists[0])):
            did = self._label2doc.get(int(lbl))
            if did is None:
                continue
            hits.append(Hit(doc_id=did, score=float(1.0 - dist), rank=rank,
                            text=self._docs[did][1]))
        return Observation(hits=hits)

    def query(self, text: str, k: int = 10) -> Observation:
        return timed_query(self._query, text, k)

    # -- introspection (structural signatures) ----------------------------
    def artifact_signatures(self) -> dict[str, Any]:
        """Return a snapshot of structural artifacts for counterfactual replay."""
        sig: dict[str, Any] = {}
        # Live element count and tombstone count (Tier I / II boundary)
        sig["n_live"] = len(self._docs) - len(self._deleted)
        sig["n_tombstoned"] = len(self._deleted)
        # Graph connectivity signature: degree sequence of the base layer.
        # hnswlib does not expose adjacency directly; we approximate structural
        # residue by the recall geometry, i.e., the sorted neighbor distances of
        # a fixed probe set. This is a per-artifact feature vector.
        try:
            probes = self._probe_vectors()
            labels, dists = self.index.knn_query(probes, k=min(10, max(1, sig["n_live"])),
                                                 num_threads=1)
            sig["neighbor_dist_spectrum"] = np.sort(dists.ravel())
        except Exception:
            sig["neighbor_dist_spectrum"] = np.array([])
        return sig

    def _probe_vectors(self, n: int = 32) -> np.ndarray:
        rng = np.random.default_rng(12345)
        v = rng.standard_normal((n, self.dim)).astype("float32")
        v /= (np.linalg.norm(v, axis=1, keepdims=True) + 1e-9)
        return v

    def contains_text(self, needle: str) -> list[str]:
        return [did for did, (_, txt) in self._docs.items()
                if did not in self._deleted and needle in txt]
