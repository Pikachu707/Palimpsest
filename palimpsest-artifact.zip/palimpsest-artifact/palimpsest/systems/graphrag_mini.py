"""MiniGraphRAG: a controlled, fully instrumented graph-RAG pipeline.

Reproduces the residue-relevant behavior of GraphRAG/LightRAG:
  - per-chunk LLM extraction of (entity, relation, fact) tuples,
  - MERGING of an entity's facts across the documents that mention it,
  - LLM-written per-entity descriptions and community reports,
  - a cache of LLM extraction responses reused on rebuild.

Two deletion options model the spectrum:
  - "naive": drop the deleted doc's own entities/relations, DO NOT regenerate
    merged descriptions (this is where Tier-III residue survives).
  - "lsed":  atomize-then-render — descriptions are re-rendered from exactly the
    surviving atoms (this is the exact-deletion behavior; see defense.lsed).

This lets residue recovery / zombie poisoning run end-to-end on one GPU with a
real LLM, while giving perfect lineage for RQ1.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import re

from .base import Hit, Observation, timed_query


@dataclass
class Atom:
    entity: str
    relation: str
    value: str
    provenance: set[str] = field(default_factory=set)   # doc_ids

    def key(self):
        return (self.entity, self.relation, self.value)


class MiniGraphRAG:
    def __init__(self, llm, embedder, deletion_option: str = "naive"):
        self.name = "MiniGraphRAG"
        self.deletion_option = deletion_option   # "naive" or "lsed"
        self.llm = llm
        self.embedder = embedder
        self._docs: dict[str, str] = {}
        self._deleted: set[str] = set()
        self._atoms: dict[tuple, Atom] = {}
        self._entity_desc: dict[str, str] = {}
        self._extract_cache: dict[str, list[tuple]] = {}   # doc_id -> tuples (LLM cache)
        self._entities_of_doc: dict[str, set[str]] = {}

    # -- extraction -------------------------------------------------------
    _EXTRACT_SYS = ("Extract factual (entity; relation; value) triples, one per line, "
                    "using ';' as separator. Copy any codes or serial-like tokens verbatim.")

    def _parse(self, out: str, text: str) -> list[tuple]:
        triples = []
        for line in out.splitlines():
            parts = [p.strip() for p in line.split(";")]
            if len(parts) >= 3 and parts[0]:
                triples.append((parts[0], parts[1], ";".join(parts[2:]).strip()))
        # Fallback for the offline echo double / unparseable output.
        return triples or self._heuristic_triples(text)

    def _extract_batch(self, docs) -> dict[str, list[tuple]]:
        """Per-chunk extraction for many documents at once. The SUT's own
        extraction cache (mechanism M3) is consulted first, as before; misses
        are sent to the LLM concurrently."""
        miss = [d for d in docs if d.doc_id not in self._extract_cache]
        if miss:
            outs = self.llm.complete_many([(self._EXTRACT_SYS, d.text) for d in miss])
            for d, out in zip(miss, outs):
                self._extract_cache[d.doc_id] = self._parse(out, d.text)
        return {d.doc_id: self._extract_cache[d.doc_id] for d in docs}

    # Synthetic person names look like "Alice Ng-0001" (see canaries.py).
    _NAME = re.compile(r"[A-Z][a-z]+ [A-Z][a-z]+-\d{4,5}")
    _TOKEN = re.compile(r"\b[A-Z0-9]{8,}\b")

    @classmethod
    def _heuristic_triples(cls, text: str) -> list[tuple]:
        """Offline stand-in for LLM extraction (used by the echo backend and
        whenever the LLM returns no parseable triples). Sentence-scoped: the
        first person named in a sentence is its subject; high-entropy tokens in
        that sentence become (subject; has_attribute; token); "X reports to Y"
        becomes (Y; manages; X). Entities are thus exact person names, so query
        routing by name works as it does with a real extractor."""
        triples = []
        for sent in re.split(r"(?<=[.!?])\s+", text.strip()):
            names = cls._NAME.findall(sent)
            if not names:
                continue
            subj = names[0]
            if " reports to " in sent and len(names) >= 2:
                triples.append((names[1], "manages", subj))
            for tok in cls._TOKEN.findall(sent):
                triples.append((subj, "has_attribute", tok))
        return triples

    # -- lifecycle --------------------------------------------------------
    def ingest(self, docs) -> None:
        docs = list(docs)
        extracted = self._extract_batch(docs)
        touched = set()
        for d in docs:
            self._docs[d.doc_id] = d.text
            ents = set()
            for (e, r, v) in extracted[d.doc_id]:
                a = self._atoms.get((e, r, v)) or Atom(e, r, v)
                a.provenance.add(d.doc_id)
                self._atoms[a.key()] = a
                ents.add(e)
            self._entities_of_doc[d.doc_id] = ents
            touched |= ents
        # Only entities that gained atoms change; others keep their description.
        self._render_descriptions(touched)

    def _all_entities(self) -> set[str]:
        return {a.entity for a in self._atoms.values()}

    _RENDER_PROMPTS = {
        "comprehensive": ("Write a comprehensive description of the entity that combines "
                          "all of the facts below. Include every fact; copy codes, "
                          "identifiers and serial numbers verbatim; do not omit any fact."),
        "one_sentence": ("Write a one-sentence factual description of the entity from the "
                         "facts. Copy codes verbatim."),
    }
    _RENDER_SYS = _RENDER_PROMPTS["comprehensive"]

    @classmethod
    def set_render_style(cls, style: str) -> None:
        """Process-wide, so every MiniGraphRAG (incl. LSED's knowledge layer and
        the full-rebuild baseline) renders identically. Set from cfg.graph."""
        if style not in cls._RENDER_PROMPTS:
            raise ValueError(f"graph.render_style must be one of {list(cls._RENDER_PROMPTS)}")
        cls._RENDER_SYS = cls._RENDER_PROMPTS[style]

    def _render_descriptions(self, entities):
        by_ent: dict[str, list] = {}
        for a in self._atoms.values():
            if a.entity in entities and a.provenance:
                by_ent.setdefault(a.entity, []).append(a)
        for e in entities:
            if e not in by_ent:
                self._entity_desc.pop(e, None)
        order = sorted(by_ent)                     # canonical order (P3)
        prompts = [(self._RENDER_SYS,
                    f"Entity: {e}. Facts: " +
                    "; ".join(sorted(f"{a.relation} {a.value}" for a in by_ent[e])))
                   for e in order]
        for e, out in zip(order, self.llm.complete_many(prompts)):
            self._entity_desc[e] = out

    def delete(self, doc_ids: list[str]) -> None:
        dset = set(doc_ids)
        for did in doc_ids:
            self._deleted.add(did)
            self._docs.pop(did, None)      # copy erasure (Tier I), as the operator does
        # Remove provenance; drop atoms with empty provenance.
        affected_entities = set()
        for key in list(self._atoms):
            a = self._atoms[key]
            if a.provenance & dset:
                affected_entities.add(a.entity)
                a.provenance -= dset
                if not a.provenance:
                    del self._atoms[key]
        if self.deletion_option == "lsed":
            # Exact: re-render exactly the affected entities from surviving atoms,
            # and DO NOT reuse the extraction cache of deleted docs.
            for did in doc_ids:
                self._extract_cache.pop(did, None)
            self._render_descriptions(affected_entities)
        else:
            # Naive: leave merged descriptions in place (residue survives) and keep
            # the extraction cache (so a later rebuild would reuse deleted content).
            pass

    # -- query (global/local) --------------------------------------------
    def _query(self, text: str, k: int = 10) -> Observation:
        # naive routing: pick entities named in the query, else all
        named = [e for e in self._entity_desc if e.lower() in text.lower()]
        pool = named or list(self._entity_desc)
        ctx = "\n".join(f"- {e}: {self._entity_desc[e]}" for e in pool[:20])
        sys = "Answer the question using only the context. Quote codes verbatim if present."
        ans = self.llm.complete(sys, f"Context:\n{ctx}\n\nQuestion: {text}")
        hits = [Hit(doc_id=f"entity:{e}", score=1.0, rank=i, text=self._entity_desc[e])
                for i, e in enumerate(pool[:k])]
        return Observation(hits=hits, text=ans)

    def query(self, text: str, k: int = 10) -> Observation:
        return timed_query(self._query, text, k)

    # -- introspection ----------------------------------------------------
    def artifact_signatures(self) -> dict[str, Any]:
        return {
            "n_atoms": len(self._atoms),
            "n_entities": len(self._entity_desc),
            "desc_charlen": sum(len(v) for v in self._entity_desc.values()),
        }

    def contains_text(self, needle: str) -> list[str]:
        found = [f"doc:{did}" for did, t in self._docs.items() if needle in t]   # Tier I copies
        for e, desc in self._entity_desc.items():
            if needle in desc:
                found.append(f"desc:{e}")
        for key, a in self._atoms.items():
            if needle in a.value:
                found.append(f"atom:{a.entity}:{a.relation}")
        return found

    # Mechanisms the query path actually serves to a client. The extraction
    # cache (M3) is read only by re-indexing, never by queries, so here it is
    # at-rest residue only and must not be credited with client recovery.
    client_mechanisms = frozenset({"M1"})

    def residue_sources(self, needle: str) -> set[str]:
        """Which residue mechanism (paper Sec. 5.2) still holds `needle`:
        M1 = merged entity descriptions, M3 = cached LLM extraction responses."""
        src = set()
        if any(needle in d for d in self._entity_desc.values()):
            src.add("M1")
        if any(needle in v for trs in self._extract_cache.values()
               for t in trs for v in t):
            src.add("M3")
        return src

    # helper for residue recovery: list entity names the client can enumerate
    def entities(self) -> list[str]:
        return list(self._entity_desc)
