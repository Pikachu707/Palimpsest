"""Optional adapters to REAL external systems, to validate the controlled
findings against the named tools.

Each adapter conforms to the SUT interface (ingest/delete/query + introspection)
but wraps a fast-moving third-party API. They are import-guarded and each method
that calls a version-sensitive API is marked `# VERIFY:` — confirm the call
against your installed version before trusting results. These are intentionally
thin: the paper's measurements come from the controlled MiniGraphRAG/MiniMemory
and the real ANN indexes; these adapters are for external validation only.

Nothing here runs unless you install the corresponding package and a server.
"""
from __future__ import annotations
from typing import Any
from .base import Hit, Observation, timed_query


class QdrantSUT:
    """Vector DB with a real delete API. VERIFY collection/delete signatures."""
    def __init__(self, embedder, dim: int, url: str = "http://localhost:6333",
                 collection: str = "palimpsest"):
        from qdrant_client import QdrantClient           # VERIFY import path
        from qdrant_client.models import Distance, VectorParams
        self.name = "qdrant"; self.deletion_option = "delete_points"
        self.embedder = embedder; self.dim = dim
        self.client = QdrantClient(url=url)
        self.collection = collection
        self._text: dict[int, tuple[str, str]] = {}
        self._next = 0
        # VERIFY: recreate_collection is deprecated in newer clients -> use create_collection
        self.client.recreate_collection(
            collection_name=collection,
            vectors_config=VectorParams(size=dim, distance=Distance.COSINE))

    def ingest(self, docs) -> None:
        from qdrant_client.models import PointStruct
        vecs = self.embedder.encode([d.text for d in docs])
        pts = []
        for d, v in zip(docs, vecs):
            pid = self._next; self._next += 1
            self._text[pid] = (d.doc_id, d.text)
            pts.append(PointStruct(id=pid, vector=v.tolist(),
                                   payload={"doc_id": d.doc_id}))
        self.client.upsert(self.collection, points=pts)   # VERIFY

    def delete(self, doc_ids: list[str]) -> None:
        from qdrant_client.models import FilterSelector, Filter, FieldCondition, MatchValue
        for did in doc_ids:                                # VERIFY filter delete API
            self.client.delete(self.collection, points_selector=FilterSelector(
                filter=Filter(must=[FieldCondition(key="doc_id",
                              match=MatchValue(value=did))])))

    def _query(self, text, k=10) -> Observation:
        v = self.embedder.encode([text])[0].tolist()
        res = self.client.search(self.collection, query_vector=v, limit=k)  # VERIFY
        hits = [Hit(doc_id=r.payload["doc_id"], score=float(r.score), rank=i)
                for i, r in enumerate(res)]
        return Observation(hits=hits)

    def query(self, text, k=10): return timed_query(self._query, text, k)
    def artifact_signatures(self) -> dict[str, Any]:
        info = self.client.get_collection(self.collection)                 # VERIFY
        return {"points": int(getattr(info, "points_count", 0) or 0)}
    def contains_text(self, needle): return []   # server-side text not introspectable here


class GraphRAGAdapter:
    """Adapter for Microsoft GraphRAG. GraphRAG has no first-class per-record
    delete; deletion means re-running indexing over the surviving corpus, which
    is exactly the residue story. VERIFY the indexing entrypoints for your
    installed version (the pipeline API changes across releases)."""
    def __init__(self, workdir: str):
        raise NotImplementedError(
            "GraphRAGAdapter: install `graphrag`, point it at a working dir, and "
            "implement ingest/delete by invoking its indexing pipeline over the "
            "surviving corpus. See README 'External validation'.")


class LightRAGAdapter:
    """Adapter for LightRAG (HKUDS). VERIFY: LightRAG exposes insert() and, in
    recent versions, delete_by_doc_id()/adelete_by_doc_id(). Confirm the method
    name and that it also purges the KV/graph caches, which is the residue point."""
    def __init__(self, *a, **k):
        raise NotImplementedError(
            "LightRAGAdapter: install `lightrag-hku`, then implement ingest via "
            "rag.insert(...) and delete via the version's delete_by_doc_id API; "
            "check whether merged entity descriptions are regenerated.")


class Mem0Adapter:
    """Adapter for Mem0. VERIFY: Memory.add()/delete()/search() signatures; the
    residue question is whether delete() also rewrites consolidated memories."""
    def __init__(self, *a, **k):
        raise NotImplementedError(
            "Mem0Adapter: install `mem0ai`, then wrap Memory.add/delete/search; "
            "confirm whether consolidation summaries are re-derived on delete.")
