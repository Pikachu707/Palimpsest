"""Lineage-Scoped Exact Deletion (the defense), as a drop-in SUT.

Combines:
  - subject-partitioned, history-independent HNSW (defense.hindex) for retrieval,
  - atomize-then-render knowledge artifacts (reuses MiniGraphRAG's lsed path),
  - cache flush + empty-partition removal at deletion.

Used in RQ3 as the "LSED" column, compared against native deletion and full
rebuild. Exposes the same SUT interface as the other systems.
"""
from __future__ import annotations
from typing import Any
import hashlib
import math
import time
import numpy as np

from ..systems.base import Hit, Observation, timed_query
from ..systems.graphrag_mini import MiniGraphRAG
from .hindex import HISlicedHNSW


class LSEDSystem:
    def __init__(self, llm, embedder, emb_dim: int, n_partitions: int = 64,
                 slice_size: int = 256, pad_quantum_ms: float = 0.0,
                 M: int = 16, ef: int = 64, ef_construction: int = 200,
                 retrieval_only: bool = False):
        self.name = "LSED"
        self.deletion_option = "lsed-exact"
        self.llm = llm; self.embedder = embedder; self.dim = emb_dim
        self.n_partitions = n_partitions; self.slice_size = slice_size
        # Timing mitigation: round every query's latency up to a multiple of
        # this quantum (0 disables). Blunts the O_time channel that Theorem 1
        # does not cover (paper, "Timing and audit").
        self.pad_quantum_ms = pad_quantum_ms
        self._hnsw_kw = dict(M=M, ef=ef, ef_construction=ef_construction)
        # retrieval_only: partitioned history-independent retrieval WITHOUT the
        # LLM knowledge layer. Used where only O_rank/O_score/O_time of the
        # retrieval layer matter (deletion inference, latency, timing), so those
        # measurements neither call nor wait on the LLM.
        self.retrieval_only = retrieval_only
        if retrieval_only:
            self.name = "LSED-retrieval"
        self._parts: dict[str, HISlicedHNSW] = {}       # partition_key -> index
        self._doc_part: dict[str, str] = {}
        self._doc_text: dict[str, str] = {}
        # knowledge layer with exact (atomize-then-render) deletion
        self._graph = MiniGraphRAG(llm, embedder, deletion_option="lsed")

    def _partition_key(self, doc) -> str:
        """P2 + (A4): a record's partition depends only on the record. All of a
        subject's records land in the same partition, chosen by a stable hash of
        the subject id (NOT Python's hash(), which is salted per process).
        n_partitions therefore controls the real blast-radius / fan-out trade-off."""
        sid = str(getattr(doc, "subject_id", "__misc__"))
        h = int.from_bytes(hashlib.blake2b(sid.encode(), digest_size=8).digest(), "big")
        return f"P{h % self.n_partitions:04d}"

    def ingest(self, docs) -> None:
        docs = list(docs)
        vecs = self.embedder.encode([d.text for d in docs]).astype("float32")
        batches: dict[str, tuple[list, list]] = {}
        for d, v in zip(docs, vecs):
            pk = self._partition_key(d)
            batches.setdefault(pk, ([], []))
            batches[pk][0].append(d.doc_id); batches[pk][1].append(v)
            self._doc_part[d.doc_id] = pk
            self._doc_text[d.doc_id] = d.text
        for pk, (rids, vs) in batches.items():
            if pk not in self._parts:
                self._parts[pk] = HISlicedHNSW(self.dim, slice_size=self.slice_size,
                                               **self._hnsw_kw)
            self._parts[pk].add_many(rids, vs)      # one rebuild per partition
        if not self.retrieval_only:
            self._graph.ingest(docs)

    def delete(self, doc_ids: list[str]) -> None:
        for did in doc_ids:
            pk = self._doc_part.get(did)
            if pk and pk in self._parts:
                self._parts[pk].delete(did)
                if len(self._parts[pk]._records) == 0:   # remove empty partition (A4)
                    del self._parts[pk]
            self._doc_part.pop(did, None)
            self._doc_text.pop(did, None)
        if not self.retrieval_only:
            self._graph.delete(doc_ids)   # exact re-render of affected artifacts

    def _query(self, text: str, k: int = 10) -> Observation:
        # fan out to partitions, merge top-k (routing index omitted for clarity)
        v = self.embedder.encode([text]).astype("float32")[0]
        merged = []
        for pk, idx in self._parts.items():
            rids, scores = idx.search(v, k=k)
            for rid, sc in zip(rids, scores):
                if rid is not None:
                    merged.append((sc, rid))
        merged.sort(reverse=True)
        hits = [Hit(doc_id=rid, score=sc, rank=i, text=self._doc_text.get(rid))
                for i, (sc, rid) in enumerate(merged[:k])]
        if self.retrieval_only:
            return Observation(hits=hits)
        gobs = self._graph.query(text, k=k)
        return Observation(hits=hits, text=gobs.text)

    def query(self, text: str, k: int = 10) -> Observation:
        t0 = time.perf_counter()
        obs = self._query(text, k)
        if self.pad_quantum_ms > 0:
            q = self.pad_quantum_ms / 1000.0
            elapsed = time.perf_counter() - t0
            target = math.ceil(elapsed / q) * q
            if target > elapsed:
                time.sleep(target - elapsed)
        obs.latency_s = time.perf_counter() - t0
        return obs

    def artifact_signatures(self) -> dict[str, Any]:
        sig = {"n_partitions": len(self._parts)}
        sig.update({f"part::{pk}": idx.signature()["n"] for pk, idx in self._parts.items()})
        if not self.retrieval_only:
            sig.update(self._graph.artifact_signatures())
        return sig

    def contains_text(self, needle: str) -> list[str]:
        out = [did for did, txt in self._doc_text.items() if needle in txt]
        if not self.retrieval_only:
            out += self._graph.contains_text(needle)
        return out
