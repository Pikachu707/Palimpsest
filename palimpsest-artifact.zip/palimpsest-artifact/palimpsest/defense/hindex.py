"""History-independent HNSW with slice checkpoints.

Insertions within a partition are applied in a canonical order (by record id),
and the index is checkpointed after every `slice_size` insertions. A deletion
restores the last checkpoint preceding the deleted record and re-inserts the
surviving subsequent records in canonical order, so the resulting graph depends
only on the set of live records (not on the deletion history). Cost is bounded
by the slice size, not the partition size.

Checkpointing uses hnswlib's save/load of a serialized index.
"""
from __future__ import annotations
from typing import Optional
import os
import shutil
import tempfile
import weakref
import contextlib
import numpy as np
import hnswlib


_LIBC = None
try:
    import ctypes
    _LIBC = ctypes.CDLL(None)
except Exception:  # non-POSIX: fall back to no flushing
    pass


def _c_flush():
    import sys
    sys.stdout.flush()
    if _LIBC is not None:
        _LIBC.fflush(None)   # flush C stdio buffers (fully buffered when piped)


@contextlib.contextmanager
def _suppress_c_stdout():
    """Suppress hnswlib's 'Calling load_index for an already inited index'
    notice on every checkpoint reload. It is written by C++ code (to stderr in
    current builds, stdout in some older ones), so we silence fds 1 and 2.
    C stdio is fully buffered when output is a file/pipe, so we fflush INSIDE
    the redirect; otherwise the buffered notice escapes after restoration."""
    import sys
    _c_flush(); sys.stderr.flush()
    saved = {fd: os.dup(fd) for fd in (1, 2)}
    devnull = os.open(os.devnull, os.O_WRONLY)
    try:
        for fd in (1, 2):
            os.dup2(devnull, fd)
        yield
        _c_flush()
    finally:
        for fd, sv in saved.items():
            os.dup2(sv, fd); os.close(sv)
        os.close(devnull)


def _silence_hnswlib_load(idx, path, max_elements):
    with _suppress_c_stdout():
        idx.load_index(path, max_elements=max_elements)


class HISlicedHNSW:
    def __init__(self, dim: int, slice_size: int = 256, M: int = 16,
                 ef_construction: int = 200, ef: int = 64,
                 max_elements: int = 100000, seed: int = 100,
                 workdir: Optional[str] = None):
        self.dim = dim; self.slice_size = slice_size
        self.M = M; self.ef_construction = ef_construction; self.ef = ef
        self.max_elements = max_elements; self.seed = seed
        # Checkpoints live in a private directory that is REMOVED when this index
        # is garbage-collected (or at interpreter exit). Without this, every
        # deployment of a long experiment leaks its checkpoints and eventually
        # fills the disk, after which truncated checkpoint files load as
        # "corrupted" indexes. Base directory: $PALIMPSEST_CKPT_DIR or the
        # system temp dir.
        base = os.environ.get("PALIMPSEST_CKPT_DIR") or None
        if base:
            os.makedirs(base, exist_ok=True)
        self.workdir = workdir or tempfile.mkdtemp(prefix="lsed_ckpt_", dir=base)
        self._finalizer = weakref.finalize(self, shutil.rmtree, self.workdir, True)
        self._records: dict[str, np.ndarray] = {}     # rid -> vector (canonical store)
        self._order: list[str] = []                    # canonical order (sorted rids)
        self._label: dict[str, int] = {}
        self._checkpoints: list[tuple[int, str]] = []  # (num_records, path)
        self._index = None
        self._build_from(self._order)

    # -- canonical build --------------------------------------------------
    def _new_index(self):
        idx = hnswlib.Index(space="cosine", dim=self.dim)
        idx.init_index(max_elements=self.max_elements, ef_construction=self.ef_construction,
                       M=self.M, random_seed=self.seed)
        idx.set_ef(self.ef)
        return idx

    def _checkpoint(self, idx, n: int):
        """Save a checkpoint after n canonical insertions and CONTINUE FROM THE
        RELOADED COPY. hnswlib resets its level RNG on load, so a path that
        builds straight through and a path that resumes from this checkpoint
        would otherwise assign different levels to every later record, breaking
        history independence. Reloading on every path makes each canonical
        segment start from the same state."""
        path = self._ckpt_path(n)
        idx.save_index(path)
        self._checkpoints.append((n, path))
        fresh = self._new_index()
        _silence_hnswlib_load(fresh, path, self.max_elements)
        return fresh

    def _ckpt_path(self, n: int) -> str:
        return os.path.join(self.workdir, f"ckpt_{n}.bin")

    def _build_from(self, rids: list[str]):
        self._index = self._new_index()
        self._label.clear()
        for (_, path_) in self._checkpoints:
            try:
                os.remove(path_)
            except OSError:
                pass
        self._checkpoints.clear()
        for i, rid in enumerate(rids):
            self._label[rid] = i
            self._index.add_items(self._records[rid][None, :], np.array([i]), num_threads=1)
            if (i + 1) % self.slice_size == 0:
                self._index = self._checkpoint(self._index, i + 1)

    # -- API --------------------------------------------------------------
    def add_many(self, rids, vecs):
        """Insert a batch with ONE tail rebuild. Because records are kept in
        canonical order, the resulting graph is identical to adding them one at
        a time (history independence), at O(n) instead of O(n^2) insertions."""
        for rid, vec in zip(rids, vecs):
            self._records[rid] = np.asarray(vec, dtype="float32").ravel()
        self._order = sorted(self._records)
        self._rebuild_tail_from_checkpoint()

    def add(self, rid: str, vec: np.ndarray):
        self._records[rid] = np.asarray(vec, dtype="float32").ravel()
        # keep canonical (sorted) order; rebuild the tail from the last checkpoint
        self._order = sorted(self._records)
        self._rebuild_tail_from_checkpoint()

    def delete(self, rid: str):
        if rid not in self._records:
            return
        del self._records[rid]
        self._order = sorted(self._records)
        self._rebuild_tail_from_checkpoint()

    def _rebuild_tail_from_checkpoint(self):
        # Find the largest checkpoint whose prefix is unchanged. Since order is
        # canonical, a checkpoint at n is valid iff the first n canonical records
        # match. For simplicity and correctness we rebuild from the last
        # checkpoint <= len(order) whose prefix still matches; otherwise full.
        n = len(self._order)
        valid = None
        for (cn, path) in self._checkpoints:
            if cn <= n and self._prefix_labels_match(cn):
                valid = (cn, path)
        if valid is None:
            self._build_from(self._order)
            return
        cn, path = valid
        idx = self._new_index()
        _silence_hnswlib_load(idx, path, self.max_elements)
        # drop checkpoints after cn (they are stale) -- and their files
        for (n_, path_) in self._checkpoints:
            if n_ > cn:
                try:
                    os.remove(path_)
                except OSError:
                    pass
        self._checkpoints = [c for c in self._checkpoints if c[0] <= cn]
        for i in range(cn, n):
            rid = self._order[i]
            self._label[rid] = i
            idx.add_items(self._records[rid][None, :], np.array([i]), num_threads=1)
            if (i + 1) % self.slice_size == 0:
                idx = self._checkpoint(idx, i + 1)
        self._index = idx

    def _prefix_labels_match(self, cn: int) -> bool:
        # prefix matches if the first cn canonical rids still have labels 0..cn-1
        for i in range(cn):
            rid = self._order[i]
            if self._label.get(rid) != i:
                return False
        return True

    def search(self, vec: np.ndarray, k: int = 10):
        n = len(self._records)
        if n == 0:
            return [], []
        labels, dists = self._index.knn_query(np.asarray(vec, "float32")[None, :],
                                              k=min(k, n), num_threads=1)
        rid_by_label = {v: kk for kk, v in self._label.items()}
        rids = [rid_by_label.get(int(l)) for l in labels[0]]
        return rids, [float(1 - d) for d in dists[0]]

    def signature(self):
        # history-independent: signature is a function of the live set only
        n = len(self._records)
        return {"n": n, "order_hash": hash(tuple(self._order))}
