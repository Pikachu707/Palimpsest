"""Statistical machinery for counterfactual replay and attack evaluation."""
from __future__ import annotations
import numpy as np
from typing import Sequence


# ----------------------------------------------------------------------
# Two-sample tests + effect sizes (for RQ1 counterfactual replay)
# ----------------------------------------------------------------------
def mann_whitney(x: Sequence[float], y: Sequence[float]) -> tuple[float, float]:
    """Return (U-statistic p-value, rank-biserial effect size in [-1,1])."""
    from scipy.stats import mannwhitneyu
    x = np.asarray(x, float); y = np.asarray(y, float)
    if len(x) == 0 or len(y) == 0:
        return 1.0, 0.0
    try:
        u, p = mannwhitneyu(x, y, alternative="two-sided")
    except ValueError:
        return 1.0, 0.0
    # rank-biserial correlation
    eff = 1.0 - 2.0 * u / (len(x) * len(y))
    return float(p), float(eff)


def energy_distance(X: np.ndarray, Y: np.ndarray) -> float:
    """Energy distance between two vector-valued samples (rows = observations)."""
    X = np.atleast_2d(np.asarray(X, float)); Y = np.atleast_2d(np.asarray(Y, float))

    def _mean_pairwise(A, B):
        # mean Euclidean distance between rows of A and B
        d = np.sqrt(np.maximum(((A[:, None, :] - B[None, :, :]) ** 2).sum(-1), 0))
        return d.mean()

    if len(X) == 0 or len(Y) == 0:
        return 0.0
    e = 2 * _mean_pairwise(X, Y) - _mean_pairwise(X, X) - _mean_pairwise(Y, Y)
    return float(max(e, 0.0))


def benjamini_hochberg(pvals: Sequence[float], alpha: float = 0.05) -> np.ndarray:
    """Return a boolean mask of rejected (significant) hypotheses at FDR alpha."""
    p = np.asarray(pvals, float)
    n = len(p)
    if n == 0:
        return np.array([], dtype=bool)
    order = np.argsort(p)
    ranked = p[order]
    thresh = alpha * (np.arange(1, n + 1) / n)
    below = ranked <= thresh
    k = np.max(np.where(below)[0]) + 1 if below.any() else 0
    mask = np.zeros(n, dtype=bool)
    if k > 0:
        mask[order[:k]] = True
    return mask


# ----------------------------------------------------------------------
# Attack evaluation: ROC / AUC / TPR@FPR (for deletion inference)
# ----------------------------------------------------------------------
def roc_curve(scores: Sequence[float], labels: Sequence[int]):
    from sklearn.metrics import roc_curve as _rc
    fpr, tpr, thr = _rc(labels, scores)
    return fpr, tpr, thr


def auc(scores: Sequence[float], labels: Sequence[int]) -> float:
    from sklearn.metrics import roc_auc_score
    labels = np.asarray(labels)
    if labels.min() == labels.max():
        return float("nan")
    return float(roc_auc_score(labels, scores))


def tpr_at_fpr(scores: Sequence[float], labels: Sequence[int],
               target_fpr: float = 0.01) -> float:
    fpr, tpr, _ = roc_curve(scores, labels)
    idx = np.searchsorted(fpr, target_fpr, side="right") - 1
    idx = max(idx, 0)
    return float(tpr[idx])


# ----------------------------------------------------------------------
# LiRA-style likelihood ratio (Gaussian per-feature, shared covariance)
# ----------------------------------------------------------------------
class GaussianLR:
    """Fit N(mu1, S) under H1 (deleted) and N(mu0, S) under H0 (never present),
    with a shared diagonal covariance. Score = log-likelihood ratio."""

    def __init__(self):
        self.mu0 = self.mu1 = self.var = None

    def fit(self, F1: np.ndarray, F0: np.ndarray):
        F1 = np.atleast_2d(F1); F0 = np.atleast_2d(F0)
        self.mu1 = F1.mean(0); self.mu0 = F0.mean(0)
        pooled = np.vstack([F1 - self.mu1, F0 - self.mu0])
        self.var = pooled.var(0) + 1e-6
        return self

    def score(self, F: np.ndarray) -> np.ndarray:
        F = np.atleast_2d(F)
        ll1 = -0.5 * (((F - self.mu1) ** 2) / self.var).sum(1)
        ll0 = -0.5 * (((F - self.mu0) ** 2) / self.var).sum(1)
        return ll1 - ll0
