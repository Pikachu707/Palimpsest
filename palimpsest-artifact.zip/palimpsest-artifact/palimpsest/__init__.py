"""Palimpsest: measuring deletion completeness in retrieval-augmented LLM systems.

Research prototype. All experiments run against LOCAL, self-hosted components
using SYNTHETIC canary data. Do not point the attack/audit modules at systems
you are not authorized to test.
"""
__version__ = "0.1.0"
