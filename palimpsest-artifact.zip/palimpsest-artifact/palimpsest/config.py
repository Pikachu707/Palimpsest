"""Configuration: dataclasses + YAML loading, with single-GPU defaults."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional
import yaml


@dataclass
class LLMConfig:
    # backend: "vllm" (local OpenAI-compatible server) or "openai" (hosted) or "echo" (offline test double)
    backend: str = "vllm"
    model: str = "meta-llama/Llama-3.1-8B-Instruct"
    base_url: str = "http://localhost:8000/v1"   # vLLM server
    api_key_env: str = "OPENAI_API_KEY"          # used for backend=openai
    max_tokens: int = 512
    temperature: float = 0.0                     # greedy: needed for LSED determinism
    request_timeout_s: int = 120
    max_concurrency: int = 32                    # concurrent requests (vLLM batches them)
    # "auto": send a system message, and if the server's chat template rejects
    # the system role (e.g. Gemma-2), merge it into the user turn from then on.
    # "merge" / "native" force one behaviour.
    system_role: str = "auto"
    max_prompt_chars: int = 24000                # ~6k tokens; keeps prompts under max_model_len


@dataclass
class EmbeddingConfig:
    # backend: "sentence_transformers" (local, GPU) or "hash" (offline deterministic test double)
    backend: str = "sentence_transformers"
    model: str = "BAAI/bge-large-en-v1.5"
    dim: int = 1024
    device: str = "cuda"
    normalize: bool = True
    batch_size: int = 256


@dataclass
class IndexConfig:
    # HNSW search regime. Client-visible structural residue (rank/score DI)
    # appears only when search is APPROXIMATE (large N and/or small ef/M);
    # with near-exact search, deletion leaves ranks unchanged. Native and LSED
    # indexes use the same values so RQ3 compares like with like.
    hnsw_M: int = 16
    hnsw_ef: int = 64
    hnsw_ef_construction: int = 200
    ivf_nprobe: int = 1        # IVF lists probed per query (FAISS default 1)


@dataclass
class GraphConfig:
    # How MiniGraphRAG renders an entity's merged description from its atoms.
    #   "comprehensive": keep every fact (matches GraphRAG-style description
    #                    summarization; the default, for fidelity)
    #   "one_sentence":  lossy one-sentence summary (ablation: residue under
    #                    an aggressive summarizer)
    render_style: str = "comprehensive"


@dataclass
class DataConfig:
    n_subjects: int = 200
    docs_per_subject: int = 5
    n_background_docs: int = 20000     # BEIR mix or synthetic filler
    beir_dataset: Optional[str] = None  # e.g. "scifact"; None -> synthetic filler only
    beir_root: str = "data/beir"
    canary_facts_per_doc: int = 3
    subjects_per_manager: int = 10     # shared managers (merged descriptions)
    seed: int = 0


@dataclass
class ReplayConfig:
    n_seeds: int = 10                  # replay seeds for randomized artifacts
    fdr_alpha: float = 0.05            # Benjamini-Hochberg level
    effect_threshold: float = 0.1      # min effect size to call an artifact a descendant


@dataclass
class AttackConfig:
    shadow_models: int = 64            # deletion-inference shadow deployments
    records_per_subject: tuple = (1, 5, 20, 100)
    di_probe_queries: int = 40
    di_control_queries: int = 40
    di_sentinels: int = 8
    di_background_docs: int = 5000     # cap background per DI deployment (cost)
    di_test_subjects: int = 32         # held-out targets (balanced H0/H1 each)
    rq3_di_k: int = 20                 # records/subject for the RQ3 DI comparison
    # Regimes compared by deletion inference in RQ3 (native, full rebuild, LSED).
    rq3_di_systems: tuple = ("hnswlib", "hnswlib-rebuild", "lsed")
    # Background population for deletion inference only (no LLM involved).
    # 0 => reuse data.n_subjects. Lets DI use a large corpus while the
    # LLM-driven experiments stay at data.n_subjects.
    di_n_subjects: int = 0
    di_channels: tuple = ("rank", "score")   # observation interface; add "time" to include latency
    di_null: str = "never"             # H0: "never" (target never present) or
                                       #     "decoy" (another subject's records deleted)
    rr_paraphrases: int = 8            # residue-recovery query paraphrases
    poison_targets: int = 50           # zombie-poisoning target questions


@dataclass
class LSEDConfig:
    n_partitions: int = 64
    slice_size: int = 256              # HNSW checkpoint slice
    epoch_batch: int = 1               # deletions applied per epoch (1 = eager)
    pad_partitions: bool = True        # enable latency padding (timing mitigation)
    pad_quantum_ms: float = 5.0        # round query latency up to this quantum
    s_sweep: tuple = (8, 16, 32, 64, 128, 256)   # partition counts for the ablation


@dataclass
class Config:
    run_name: str = "default"
    out_dir: str = "results"
    device: str = "cuda"
    llm: LLMConfig = field(default_factory=LLMConfig)
    emb: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    index: IndexConfig = field(default_factory=IndexConfig)
    graph: GraphConfig = field(default_factory=GraphConfig)
    data: DataConfig = field(default_factory=DataConfig)
    replay: ReplayConfig = field(default_factory=ReplayConfig)
    attack: AttackConfig = field(default_factory=AttackConfig)
    lsed: LSEDConfig = field(default_factory=LSEDConfig)

    def dump(self, path: str | Path) -> None:
        Path(path).write_text(yaml.safe_dump(asdict(self), sort_keys=False))


def _merge(dc, d: dict):
    for k, v in (d or {}).items():
        if not hasattr(dc, k):
            raise KeyError(f"unknown config key: {k}")
        cur = getattr(dc, k)
        if hasattr(cur, "__dataclass_fields__") and isinstance(v, dict):
            _merge(cur, v)
        else:
            setattr(dc, k, tuple(v) if isinstance(cur, tuple) and isinstance(v, list) else v)
    return dc


def load_config(path: Optional[str | Path] = None) -> Config:
    cfg = Config()
    if path:
        _merge(cfg, yaml.safe_load(Path(path).read_text()) or {})
    return cfg
