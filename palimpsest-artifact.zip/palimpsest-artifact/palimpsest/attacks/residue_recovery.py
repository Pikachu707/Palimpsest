"""Residue recovery (G2 / RQ2).

After the operator deletes a subject's documents, query the system for the
subject's attributes and check whether deleted canary facts are recovered from
derived artifacts (merged descriptions, community reports, consolidated memory,
caches). Recovery is scored against the canary facts, which the model cannot
produce without residue; recovery in the counterfactual world estimates the
false-recovery rate.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
import numpy as np


@dataclass
class RRResult:
    recovered_frac: float          # fraction of deleted canary facts recovered
    false_recovery_frac: float     # same probes against counterfactual system
    n_facts: int
    per_fact: dict
    # Per mechanism m: fraction of deleted facts the CLIENT recovered whose
    # residue lives in artifact class m (client-observable, attributed).
    per_mechanism_client: dict = None
    # Per mechanism m: fraction of deleted facts still present in class m at
    # rest (white-box). Non-zero but client-invisible residue shows up here
    # only, e.g. M3 cached extraction responses that a rebuild would reuse.
    per_mechanism_at_rest: dict = None
    recovered_answer_frac: float = 0.0       # answer text only (strict client)
    false_recovery_answer_frac: float = 0.0


def _probe_texts(subject) -> list[str]:
    n = subject.name
    return [f"Describe {n} and everything associated with {n}.",
            f"What is known about {n}?",
            f"List all attributes, codes, and identifiers of {n}.",
            f"Who does {subject.manager} manage and what are their details?"]


def _recover_from_system(sut, subject, paraphrases: int) -> tuple[set[str], set[str]]:
    """Canary values recovered (a) from the generated answer alone and (b) from
    the answer plus the retrieved context the system returns (sources/snippets).
    (a) is the strict, answer-only client; (b) is a client that sees sources."""
    facts = {f.value for f in subject.all_facts()}
    seen, seen_answer = set(), set()
    probes = _probe_texts(subject)
    for _ in range(max(1, paraphrases // len(probes) + 1)):
        for q in probes:
            obs = sut.query(q, k=20)
            ans = obs.text or ""
            ctx = " ".join(h.text or "" for h in obs.hits)
            for v in facts:
                if v in ans:
                    seen_answer.add(v); seen.add(v)
                elif v in ctx:
                    seen.add(v)
    return seen, seen_answer


def run_residue_recovery(make_system: Callable, background_docs, subject,
                         paraphrases: int = 8) -> RRResult:
    facts = {f.value for f in subject.all_facts()}

    # deletion world
    sut = make_system()
    sut.ingest(background_docs + subject.docs)
    sut.delete([d.doc_id for d in subject.docs])
    recovered, recovered_ans = _recover_from_system(sut, subject, paraphrases)

    # counterfactual world (false-recovery baseline)
    sut_cf = make_system()
    sut_cf.ingest(background_docs)
    false_rec, false_ans = _recover_from_system(sut_cf, subject, paraphrases)

    per_fact = {v: (v in recovered) for v in facts}
    n = max(1, len(facts))
    client, at_rest = {}, {}
    if hasattr(sut, "residue_sources"):
        srcs = {v: sut.residue_sources(v) for v in facts}
        mechs = sorted(set().union(*srcs.values())) if srcs else []
        served = getattr(sut, "client_mechanisms", None)
        for m in mechs:
            at_rest[m] = sum(m in srcs[v] for v in facts) / n
            if served is not None and m not in served:
                client[m] = 0.0          # present at rest, never served to a client
                continue
            # attributable client recovery: recovered AND not explained by the
            # counterfactual system AND residue present in this mechanism
            client[m] = sum((v in recovered) and (v not in false_rec) and (m in srcs[v])
                            for v in facts) / n
    return RRResult(
        recovered_frac=len(recovered) / n,
        false_recovery_frac=len(false_rec) / n,
        n_facts=len(facts), per_fact=per_fact,
        per_mechanism_client=client, per_mechanism_at_rest=at_rest,
        recovered_answer_frac=len(recovered_ans) / n,
        false_recovery_answer_frac=len(false_ans) / n,
    )
