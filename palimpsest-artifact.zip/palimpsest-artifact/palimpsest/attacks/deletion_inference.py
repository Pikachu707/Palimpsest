"""Deletion inference (G1 / RQ2).

Decide whether a target subject's records were ingested and later deleted, using
only client observations. Structural residue (repair edges, codebooks, stats)
perturbs the ranks/scores of sentinel documents planted near the target.

Pipeline:
  1. Offline: build many shadow deployments; for each, plant sentinels near a
     surrogate target and record features under H1 (inserted+deleted) and H0
     (never inserted). Fit a Gaussian likelihood-ratio model.
  2. Online: plant sentinels near the real target, extract the same features,
     score with the LR model.

Runs on the CPU ANN systems with no LLM.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
import numpy as np

from .. import stats
from ..canaries import Document


@dataclass
class DIResult:
    k: int
    auc: float
    tpr_at_1pct: float
    scores: np.ndarray
    labels: np.ndarray
    auc_ci: tuple = (float("nan"), float("nan"))   # stratified bootstrap 95% CI
    tpr_at_5pct: float = float("nan")
    tpr_at_10pct: float = float("nan")
    min_fpr: float = float("nan")                   # 1/#negatives: smallest attainable FPR
    null: str = "never"


def _sentinel_docs(rng, target_name: str, n: int) -> list[Document]:
    return [Document(doc_id=f"SENT-{target_name}-{i}", subject_id="__sentinel__",
                     text=f"Memo regarding {target_name}. Reference note {i}.")
            for i in range(n)]


CHANNELS = ("rank", "score", "topscore", "time")


def _features(sut, target_name: str, sentinels, probe_qs, control_qs,
              channels=("rank", "score")) -> np.ndarray:
    """Sentinel features per observation channel, probe minus control.

    `channels` selects the observation interface (paper Sec. 3.1): "rank" and
    "score" are state-based; "time" (latency) is not, and is excluded from
    Theorem 1. The default (rank, score) matches the paper's Fig. 5 setting;
    timing is measured separately (experiments.ablations.run_timing_channel)."""
    sent_ids = {d.doc_id for d in sentinels}
    def agg(qs):
        ranks, scores, lat, tops = [], [], [], []
        for q in qs:
            obs = sut.query(q, k=20)
            rmap, smap = obs.ranks(), obs.scores()
            tops.append(max((h.score for h in obs.hits), default=-1e9))
            for sid in sent_ids:
                ranks.append(rmap.get(sid, 20))
                scores.append(smap.get(sid, 0.0))
            lat.append(obs.latency_s)
        top = np.array(tops, float); top[top < -1e8] = np.nan
        return (np.array(ranks, float), np.array(scores, float), np.array(lat, float),
                top, float(np.mean([len(sut.query(q, k=20).hits) for q in qs[:1]])))
    pr, ps, pl, ptop, pn = agg(probe_qs)
    cr, cs, cl, ctop, cn = agg(control_qs)
    feats = []
    if "rank" in channels:
        feats += [pr.mean() - cr.mean(), pr.min(initial=20)]
    if "score" in channels:
        feats += [ps.mean() - cs.mean(), ps.max(initial=0)]
    if "topscore" in channels:
        # Sentinel-free: best score and result count for questions about the
        # target, relative to control. A ghost centroid makes the target's
        # neighbourhood "go dark" (low top score / few results) after deletion.
        p_top = np.nanmean(ptop) if np.isfinite(ptop).any() else -10.0
        c_top = np.nanmean(ctop) if np.isfinite(ctop).any() else -10.0
        feats += [p_top - c_top, pn - cn]
    if "time" in channels:
        feats += [pl.mean() - cl.mean()]
    return np.array(feats, float)


def _one_deployment(make_system, background_docs, target_subject, k, rng,
                    inserted: bool, sentinels, probe_qs, control_qs,
                    channels=("rank", "score"), decoy=None):
    """One deployment. H1: target's k records ingested then deleted.
    H0 ("never"): target never present. H0 ("decoy"): a DIFFERENT subject's k
    records are ingested then deleted, so both worlds contain a deletion and the
    attack must identify WHOSE records were erased, not merely that one was."""
    sut = make_system()
    docs = list(background_docs)
    erased = []
    if inserted:
        erased += target_subject.docs[:k]
    if decoy is not None:
        erased += decoy.docs[:k]
    sut.ingest(docs + erased + sentinels)
    if erased:
        sut.delete([d.doc_id for d in erased])
    return _features(sut, target_subject.name, sentinels, probe_qs, control_qs, channels)


def _decoy_for(subjects, i):
    """A deterministic, different subject to use as the decoy for subjects[i]."""
    n = len(subjects)
    return subjects[(i + max(1, n // 2)) % n]


def _bootstrap_auc_ci(scores, labels, n_boot=1000, seed=0):
    """Stratified bootstrap 95% CI for the AUC."""
    rng = np.random.default_rng(seed)
    pos = np.where(labels == 1)[0]; neg = np.where(labels == 0)[0]
    vals = []
    for _ in range(n_boot):
        idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
        a = stats.auc(scores[idx], labels[idx])
        if a == a:
            vals.append(a)
    if not vals:
        return float("nan"), float("nan")
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def run_deletion_inference(make_system: Callable, background_docs, subjects,
                           k: int, shadow_models: int = 64,
                           n_probe: int = 20, n_control: int = 20,
                           n_sentinels: int = 8, seed: int = 0,
                           channels=("rank", "score"), null: str = "never") -> DIResult:
    assert set(channels) <= set(CHANNELS), f"unknown channel in {channels}"
    assert null in ("never", "decoy"), f"unknown null hypothesis {null!r}"
    rng = np.random.default_rng(seed)
    n_cal = min(shadow_models, len(subjects) - 1)
    F1, F0 = [], []
    for s in range(n_cal):
        subj = subjects[s]
        sents = _sentinel_docs(rng, subj.name, n_sentinels)
        probe_qs = [f"Who is {subj.name}?", f"Tell me about {subj.name}."] * n_probe
        control_qs = [f"Who is {subjects[(s+1) % len(subjects)].name}?"] * n_control
        dec = _decoy_for(subjects, s) if null == "decoy" else None
        F1.append(_one_deployment(make_system, background_docs, subj, k, rng, True,
                                  sents, probe_qs, control_qs, channels))
        F0.append(_one_deployment(make_system, background_docs, subj, k, rng, False,
                                  sents, probe_qs, control_qs, channels, decoy=dec))
    F1 = np.array(F1); F0 = np.array(F0)
    lr = stats.GaussianLR().fit(F1, F0)

    test_subj = subjects[n_cal:] or subjects[:4]
    scores, labels = [], []
    for i, subj in enumerate(test_subj):
        sents = _sentinel_docs(rng, subj.name, n_sentinels)
        probe_qs = [f"Who is {subj.name}?"] * n_probe
        control_qs = [f"Who is {test_subj[(i+1) % len(test_subj)].name}?"] * n_control
        dec = _decoy_for(test_subj, i) if null == "decoy" else None
        f1 = _one_deployment(make_system, background_docs, subj, k, rng, True,
                             sents, probe_qs, control_qs, channels)
        f0 = _one_deployment(make_system, background_docs, subj, k, rng, False,
                             sents, probe_qs, control_qs, channels, decoy=dec)
        scores += [lr.score(f1)[0], lr.score(f0)[0]]
        labels += [1, 0]
    scores = np.array(scores); labels = np.array(labels)
    lo, hi = _bootstrap_auc_ci(scores, labels, seed=seed)
    n_neg = int((labels == 0).sum())
    return DIResult(k=k, auc=stats.auc(scores, labels),
                    tpr_at_1pct=stats.tpr_at_fpr(scores, labels, 0.01),
                    scores=scores, labels=labels,
                    auc_ci=(lo, hi),
                    tpr_at_5pct=stats.tpr_at_fpr(scores, labels, 0.05),
                    tpr_at_10pct=stats.tpr_at_fpr(scores, labels, 0.10),
                    min_fpr=1.0 / max(1, n_neg), null=null)
