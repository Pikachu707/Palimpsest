"""Counterfactual replay (RQ1).

For a target subject's documents (the "canary"), run paired executions:
  - deletion world:       ingest background + canary, then delete the canary
  - counterfactual world: ingest background only

Then compare each artifact class and each observable channel. A tier is flagged
as retaining residue if (a) an internal signature differs (white-box), or
(b) a canary fact is still present in a text artifact.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
import numpy as np

from . import stats
from .systems.base import SystemUnderTest


@dataclass
class ReplayResult:
    system: str
    tier1_copy: bool = False        # canary text still returned / present
    tier2_struct: bool = False      # structural signature differs from counterfactual
    tier3_semantic: bool = False    # canary fact in generated/merged text
    detail: dict[str, Any] = field(default_factory=dict)

    def mark(self) -> dict[str, str]:
        def m(x): return "bullet" if x else "dash"
        return {"I": m(self.tier1_copy), "II": m(self.tier2_struct), "III": m(self.tier3_semantic)}


def _sig_differs(sig_del: dict, sig_cf: dict, threshold: float) -> tuple[bool, dict]:
    detail = {}
    differs = False
    keys = set(sig_del) | set(sig_cf)
    for kkey in keys:
        a = sig_del.get(kkey); b = sig_cf.get(kkey)
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            a = np.asarray(a if a is not None else []); b = np.asarray(b if b is not None else [])
            L = min(len(a), len(b))
            if L == 0:
                d = float(len(a) != len(b))
            else:
                d = float(np.linalg.norm(a[:L] - b[:L]) / (np.linalg.norm(b[:L]) + 1e-9))
            detail[kkey] = d
            differs = differs or (d > threshold)
        else:
            same = (a == b)
            detail[kkey] = 0.0 if same else 1.0
            differs = differs or (not same)
    return differs, detail


def run_replay(make_system: Callable[[], SystemUnderTest],
               background_docs: list, canary_subject,
               threshold: float = 0.1) -> ReplayResult:
    canary_docs = canary_subject.docs
    canary_facts = [f.value for f in canary_subject.all_facts()]

    # deletion world
    sut_del = make_system()
    sut_del.ingest(background_docs + canary_docs)
    sut_del.delete([d.doc_id for d in canary_docs])

    # counterfactual world
    sut_cf = make_system()
    sut_cf.ingest(background_docs)

    res = ReplayResult(system=sut_del.name)

    # Tier I: a stored COPY of the canary survives. Hits in derived artifacts
    # (desc:/atom:/memory:) are Tier III and must not be counted here.
    derived = ("desc:", "atom:", "memory:")
    copy_hits = [h for v in canary_facts for h in sut_del.contains_text(v)
                 if not h.startswith(derived)]
    res.tier1_copy = bool(copy_hits)

    # Tier II: structural signature differs
    differs, detail = _sig_differs(sut_del.artifact_signatures(),
                                   sut_cf.artifact_signatures(), threshold)
    res.tier2_struct = bool(differs)
    res.detail["struct"] = detail

    # Tier III: canary fact present in generated/merged text artifacts
    # (contains_text on compound systems inspects descriptions/memory)
    tier3 = any(sut_del.contains_text(v) for v in canary_facts)
    # For pure ANN systems, contains_text only sees stored text; treat as N/A.
    if sut_del.name.startswith(("faiss", "hnswlib")):
        res.tier3_semantic = False
    else:
        # exclude Tier-I stored-copy hits: a compound system's contains_text
        # returns desc:/atom:/memory: prefixes for derived artifacts.
        derived_hits = [h for v in canary_facts for h in sut_del.contains_text(v)
                        if h.startswith(("desc:", "atom:", "memory:"))]
        res.tier3_semantic = bool(derived_hits)
        res.detail["tier3_hits"] = derived_hits[:20]
    return res
