"""End-to-end plumbing of the real-system experiment against a stub LLM.

The stub is not a language model, so these tests assert only model-independent
behaviour: every world is valid, storage-level residue is measured, and the
counterfactual worlds never contain a canary."""
import json, os, subprocess, sys
import pytest
pytest.importorskip("lightrag"); pytest.importorskip("mem0")
sys.path.insert(0, os.path.dirname(__file__))
import stub_openai


def test_real_systems_quick_pipeline(tmp_path):
    srv, url = stub_openai.start()
    env = dict(os.environ, PAL_LLM_BASE_URL=url, PAL_FAKE_EMBED="1", PAL_LLM_MODEL="stub",
               PYTHONPATH=os.getcwd(), MEM0_TELEMETRY="False")
    out = tmp_path / "real"
    r = subprocess.run([sys.executable, "-m", "palimpsest.experiments.real_systems", "--quick", "--parallel", "3",
                        "--out", str(out)], env=env, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stderr[-2000:]
    lr = json.load(open(f"{out}_quick/lightrag.json"))["summary"]
    m0 = json.load(open(f"{out}_quick/mem0.json"))["summary"]
    assert lr["invalid_worlds"] == [] and m0["invalid_worlds"] == []
    # model-independent storage behaviour of LightRAG 1.5.7
    assert lr["recovery"]["default"]["at_rest_stores"] == ["kv_store_llm_response_cache.json"]
    assert lr["recovery"]["thorough"]["at_rest_any"] == 0.0
    assert "paraphrase" in lr["recovery"]["default"]        # paraphrased-probe recall is reported
    # Mem0: delete_all leaves the history and session-message tables populated
    assert {"history_table", "messages_table"} <= set(m0["user"]["at_rest_stores"])
    assert m0["user"]["visible_after_delete"] == 0.0
    # counterfactual worlds can never contain a canary
    assert lr["counterfactual"]["cache"]["answer"] == 0.0 and m0["user_counterfactual"] == 0.0
