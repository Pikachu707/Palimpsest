"""Regression tests for the LLM-backend sweep."""
import json
import pytest
from palimpsest.config import LLMConfig
from palimpsest.llm import LLM


def test_memo_is_partitioned_by_model():
    llm = LLM(LLMConfig(backend="echo", model="model-A", temperature=0.0))
    a = llm.complete("sys", "fact ABCDEFGH12 here")
    assert ("sys", "fact ABCDEFGH12 here") in llm._memo
    llm.cfg.model = "model-B"                       # switch backend on a live instance
    assert ("sys", "fact ABCDEFGH12 here") not in llm._memo
    llm._memo[("sys", "q")] = "from-B"
    llm.cfg.model = "model-A"
    assert ("sys", "q") not in llm._memo            # B's answer never served for A
    assert llm.complete("sys", "fact ABCDEFGH12 here") == a


class _Resp:
    def __init__(self, text):
        self.choices = [type("C", (), {"message": type("M", (), {"content": text})()})()]


class _FakeClient:
    def __init__(self, reject_system=True, other_error=False):
        self.reject_system, self.other_error, self.calls = reject_system, other_error, []
        self.chat = type("Chat", (), {"completions": self})()

    def create(self, model, messages, **kw):
        self.calls.append(messages)
        if self.other_error:
            raise RuntimeError("CUDA out of memory")
        if self.reject_system and any(m["role"] == "system" for m in messages):
            raise RuntimeError("Error code: 400 - System role not supported")
        return _Resp("ok:" + messages[-1]["content"][:12])


def _llm(client, mode="auto"):
    llm = LLM.__new__(LLM)
    llm.cfg = LLMConfig(backend="vllm", model="gemma", temperature=0.0, system_role=mode)
    llm._client = client
    return llm


def test_system_role_rejected_is_merged_once_and_remembered():
    c = _FakeClient(reject_system=True)
    llm = _llm(c)
    assert llm.complete("SYS", "hello").startswith("ok:SYS")
    assert llm._system_mode == "merge"
    n = len(c.calls)
    llm.complete("SYS", "second")                   # no second failed attempt
    assert len(c.calls) == n + 1 and c.calls[-1][0]["role"] == "user"


def test_system_role_supported_is_kept():
    c = _FakeClient(reject_system=False)
    llm = _llm(c)
    llm.complete("SYS", "hello")
    assert c.calls[-1][0]["role"] == "system" and getattr(llm, "_system_mode", None) is None


def test_other_errors_are_not_swallowed():
    llm = _llm(_FakeClient(other_error=True))
    with pytest.raises(RuntimeError, match="out of memory"):
        llm.complete("SYS", "hello")


def test_backend_table_reports_missing_runs_as_na(tmp_path):
    from palimpsest.report.backend_table import collect, to_latex, to_markdown
    run = tmp_path / "be_x"; run.mkdir()
    rr = {k: {"recovered_mean": 0.0, "false_recovery_mean": 0.0,
              "per_mechanism_client": {"M1": 0.9, "M4": 0.8}, "per_mechanism_at_rest": {"M3": 1.0}}
          for k in ("graphrag:naive", "graphrag:lsed", "memory:naive", "memory:lsed")}
    z = {k: {"before": 0.5, "after": 0.5 if "naive" in k else 0.0, "counterfactual": 0.0}
         for k in ("graphrag:naive", "graphrag:lsed", "memory:naive", "memory:lsed")}
    json.dump({"residue_recovery": rr, "zombie": z}, open(run / "rq2_recovery_zombie.json", "w"))
    rows = collect([{"tag": "x", "label": "Model X"}, {"tag": "y", "label": "Model Y"}], tmp_path)
    assert rows[0]["rec_m1"] == 0.9 and rows[0]["rec_lsed"] == 0.0 and rows[0]["zombie_lsed"] == 0.0
    assert "rec_m1" not in rows[1]                  # absent run: nothing imputed
    md, tex = to_markdown(rows), to_latex(rows)
    assert "Model Y | n/a" in md and "Model X & 90 & n/a & 80 & 50 & 50 & 0" in tex


def test_repro_row_is_compared_but_kept_out_of_the_table(tmp_path):
    from palimpsest.report.backend_table import collect, repro_report, to_latex
    for run, m1 in (("final", 0.99), ("be_rep", 0.97)):
        d = tmp_path / run; d.mkdir()
        rr = {k: {"recovered_mean": 0.0, "false_recovery_mean": 0.0,
                  "per_mechanism_client": {"M1": m1, "M4": 0.98}, "per_mechanism_at_rest": {"M3": 1.0}}
              for k in ("graphrag:naive", "graphrag:lsed", "memory:naive", "memory:lsed")}
        z = {k: {"before": 0.6, "after": 0.6 if "naive" in k else 0.0, "counterfactual": 0.0}
             for k in ("graphrag:naive", "graphrag:lsed", "memory:naive", "memory:lsed")}
        json.dump({"residue_recovery": rr, "zombie": z}, open(d / "rq2_recovery_zombie.json", "w"))
    rows = collect([{"tag": "q", "label": "Q", "reuse": "final"},
                    {"tag": "rep", "label": "Q rerun", "table": False, "compare_to": "q"}], tmp_path)
    rep = repro_report(rows)
    assert "| rec_m1 | 99 | 97 | 2.0 |" in rep
    assert "Q rerun" not in to_latex([r for r in rows if r.get("table", True)])


def _valid_safetensors(n_floats=4):
    import json as _j, struct
    hdr = _j.dumps({"w": {"dtype": "F32", "shape": [n_floats], "data_offsets": [0, 4 * n_floats]}}).encode()
    return struct.pack("<Q", len(hdr)) + hdr + b"\0" * (4 * n_floats)


def test_weights_check_rejects_partial_downloads(tmp_path):
    import importlib.util, json as _j
    spec = importlib.util.spec_from_file_location("rb", "scripts/run_backends.py")
    rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)
    d = tmp_path / "m"; d.mkdir()
    assert not rb.weights_complete(d)[0]                       # nothing yet
    (d / "config.json").write_text("{}")
    _j.dump({"weight_map": {"a": "model-00001-of-00002.safetensors",
                            "b": "model-00002-of-00002.safetensors"}},
            open(d / "model.safetensors.index.json", "w"))
    (d / "model-00001-of-00002.safetensors").write_bytes(_valid_safetensors())
    ok, why = rb.weights_complete(d)                            # config + 1 of 2 shards
    assert not ok and "1/2" in why
    (d / "model-00002-of-00002.safetensors").write_bytes(b"")   # zero-byte shard
    assert not rb.weights_complete(d)[0]
    (d / "model-00002-of-00002.safetensors").write_bytes(_valid_safetensors())
    assert rb.weights_complete(d)[0]


def test_weights_check_detects_truncated_safetensors(tmp_path):
    import importlib.util, json as _j, struct
    spec = importlib.util.spec_from_file_location("rb", "scripts/run_backends.py")
    rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)
    hdr = _j.dumps({"w": {"dtype": "F32", "shape": [4], "data_offsets": [0, 16]}}).encode()
    full = struct.pack("<Q", len(hdr)) + hdr + b"\0" * 16
    f = tmp_path / "model.safetensors"
    f.write_bytes(full)
    assert rb.shard_problem(f) is None                      # exact size: complete
    f.write_bytes(full[:-5])                                # interrupted download
    assert "truncated" in rb.shard_problem(f)
    (tmp_path / "config.json").write_text("{}")
    assert not rb.weights_complete(tmp_path)[0]


def _fake_vllm(served_id):
    """Tiny HTTP server answering /v1/models like vLLM; returns (server, port)."""
    import http.server, json as _j, threading
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body = _j.dumps({"data": [{"id": served_id}]}).encode()
            self.send_response(200); self.end_headers(); self.wfile.write(body)
        def log_message(self, *a): pass
    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _rb():
    import importlib.util
    spec = importlib.util.spec_from_file_location("rb", "scripts/run_backends.py")
    rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb); return rb


def test_driver_refuses_a_port_already_serving_another_model(tmp_path):
    rb = _rb()
    srv, port = _fake_vllm("/workspace/models/gemma-2-9b-it")    # stale server
    try:
        assert rb.served_models(port) == ["/workspace/models/gemma-2-9b-it"]
        b = {"tag": "qwen72b", "path": "/workspace/models/Qwen2.5-72B-Instruct"}
        with pytest.raises(SystemExit, match="already in use"):
            rb.start_server(b, {"port": port, "max_model_len": 8192}, tmp_path, dry=False)
    finally:
        srv.shutdown()
    assert rb.served_models(port) is None or True


def test_served_models_is_none_when_nothing_listens():
    rb = _rb()
    import socket
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    assert rb.served_models(port) is None
