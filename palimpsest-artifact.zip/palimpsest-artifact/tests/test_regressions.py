"""Regression tests for correctness bugs found during artifact preparation.
Each test pins a property the paper's measurements depend on. Run: pytest -q"""
import json
import pathlib

import hnswlib
import numpy as np
import pytest

from palimpsest.attacks.deletion_inference import _one_deployment, _sentinel_docs
from palimpsest.canaries import build_population
from palimpsest.config import Config, load_config
from palimpsest.defense import LSEDSystem
from palimpsest.experiments.common import DI_TARGET_OFFSET, di_population
from palimpsest.llm import LLM, Embedder
from palimpsest.replay import run_replay
from palimpsest.systems import FaissSUT, HnswlibSUT, MiniGraphRAG


def _offline(dim=128):
    cfg = Config(); cfg.llm.backend = "echo"; cfg.emb.backend = "hash"; cfg.emb.dim = dim
    return cfg, LLM(cfg.llm), Embedder(cfg.emb)


# --- determinism: required for counterfactual replay on multi-core hosts ---
def test_hnswlib_sut_construction_is_deterministic_under_threads():
    """Multithreaded HNSW construction is nondeterministic; the SUT must pin
    num_threads=1 or identical worlds differ and fake Tier-II residue."""
    _, _, emb = _offline()
    docs = [d for s in build_population(200, 3, 2) for d in s.docs]
    sigs = []
    for _ in range(3):
        sut = HnswlibSUT(emb, emb.dim, M=4, ef=20, ef_construction=40)
        sut.ingest(docs)
        sigs.append(sut.artifact_signatures()["neighbor_dist_spectrum"])
    assert all(np.array_equal(sigs[0], s) for s in sigs[1:])


def test_raw_hnswlib_with_threads_is_not_deterministic_reference():
    """Documents WHY the pin matters (skipped on single-core hosts, where the
    thread pool cannot race)."""
    import os
    if (os.cpu_count() or 1) < 2:
        pytest.skip("needs >=2 cores to exhibit the race")
    rng = np.random.default_rng(0); X = rng.standard_normal((3000, 64)).astype("float32")
    def build():
        i = hnswlib.Index(space="cosine", dim=64)
        i.init_index(max_elements=5000, M=4, ef_construction=40, random_seed=100)
        i.add_items(X, np.arange(3000), num_threads=8); i.set_ef(20)
        return i.knn_query(X[:64], k=10)[0]
    ref = build()
    assert not all(np.array_equal(ref, build()) for _ in range(3))


# --- IVF-PQ must actually train (else Tier-II residue is unmeasurable) ---
def test_ivfpq_trains_at_small_scale_and_shows_codebook_residue():
    _, _, emb = _offline()
    subs = build_population(30, 3, 2)
    bg = [d for s in subs[1:] for d in s.docs]
    r = run_replay(lambda: FaissSUT(emb, emb.dim, kind="ivfpq", deletion_option="remove_ids"),
                   bg, subs[0], 0.05)
    assert r.detail["struct"]["ntotal"] == 0.0          # copies removed...
    assert r.tier2_struct                               # ...codebook residue remains


# --- DI populations must be disjoint and config-determined ---
def test_di_targets_disjoint_from_background():
    cfg = load_config("configs/smoke.yaml")
    subs = build_population(cfg.data.n_subjects, 3, 2)
    bg, targets = di_population(cfg, subs, 5)
    bg_ids = {d.doc_id for d in bg}
    assert not any(d.doc_id in bg_ids for t in targets for d in t.docs)
    assert all(int(t.subject_id[1:]) >= DI_TARGET_OFFSET for t in targets)
    bg_names = {s.name for s in subs}
    assert not any(t.name in bg_names for t in targets)


def test_di_targets_identical_across_experiments():
    """RQ2 (k sweep) and RQ3 (single k) must attack the same subjects."""
    from palimpsest.experiments import rq2_deletion_inference as m
    cfg = load_config("configs/smoke.yaml")
    subs = build_population(30, 3, 2)
    max_k = max(cfg.attack.records_per_subject)
    _, a = di_population(cfg, subs, max_k)
    pop_k = max(5, max_k)                        # what di_sweep uses for ks=[5]
    _, b = di_population(cfg, subs, pop_k)
    assert [t.name for t in a] == [t.name for t in b]


# --- Theorem 1, empirically: LSED state features identical across worlds ---
def test_lsed_state_features_identical_across_worlds():
    _, llm, emb = _offline()
    bg = [d for s in build_population(60, 3, 2) for d in s.docs]
    targets = build_population(4, 5, 2, seed=1, offset=DI_TARGET_OFFSET)
    make = lambda: LSEDSystem(llm, emb, emb.dim, n_partitions=8, slice_size=4, M=4, ef=20,
                              ef_construction=40)
    for t in targets:
        s = _sentinel_docs(None, t.name, 4)
        pq = [f"Who is {t.name}?"] * 2; cq = [f"Who is {targets[0].name}?"] * 2
        f1 = _one_deployment(make, bg, t, 5, None, True, s, pq, cq, ("rank", "score"))
        f0 = _one_deployment(make, bg, t, 5, None, False, s, pq, cq, ("rank", "score"))
        assert np.array_equal(f1, f0)


# --- LSED partitioning honours n_partitions and is process-stable ---
def test_lsed_partition_count_and_stable_hash():
    _, llm, emb = _offline()
    docs = [d for s in build_population(100, 2, 1) for d in s.docs]
    for S in (4, 16):
        sut = LSEDSystem(llm, emb, emb.dim, n_partitions=S, slice_size=8)
        sut.ingest(docs)
        assert 1 < len(sut._parts) <= S
    a = LSEDSystem(llm, emb, emb.dim, n_partitions=16)._partition_key(docs[0])
    b = LSEDSystem(llm, emb, emb.dim, n_partitions=16)._partition_key(docs[0])
    assert a == b


# --- extractor yields name-level entities (query routing depends on it) ---
def test_offline_extractor_entities_are_person_names():
    t = MiniGraphRAG._heuristic_triples(
        "Alice Ng-0001 is an employee. Alice Ng-0001 reports to Bob Osei-0042. "
        "Alice Ng-0001 works at K3J9QX7PLM2Z.")
    assert ("Bob Osei-0042", "manages", "Alice Ng-0001") in t
    assert ("Alice Ng-0001", "has_attribute", "K3J9QX7PLM2Z") in t


# --- exporter emits the figure schema, with null (not 0) for unmeasured ---
def test_export_schema(tmp_path):
    from palimpsest.report.export_figure_data import export
    (tmp_path / "rq1_residue.json").write_text(json.dumps({"systems": {
        "hnswlib": {"deletion_option": "mark_deleted", "tier1_frac": 0.0,
                    "tier2_frac": 1.0, "tier3_frac": 0.0}}}))
    (tmp_path / "rq2_recovery_zombie.json").write_text(json.dumps({
        "residue_recovery": {"graphrag:naive": {"per_mechanism_client": {"M1": 0.9}},
                             "memory:naive": {"per_mechanism_client": {"M4": 1.0}}},
        "zombie": {"graphrag:naive": {"before": 1, "after": 1, "counterfactual": 0},
                   "memory:naive": {"before": 1, "after": 1, "counterfactual": 0}}}))
    d = export(str(tmp_path))
    assert d["rq1"]["components"][0]["vals"] == [0.0, 1.0, None]   # no sem. tier for ANN
    rec = dict(zip([m.split()[0] for m in d["rq2"]["mechanisms"]], d["rq2"]["recovery"]))
    assert rec["M1"] == [0.9, None] and rec["M4"] == [None, 1.0]
    assert rec["M2"] == [None, None]                                 # not implemented -> null
    assert d["rq2"]["systems"] == ["MiniGraphRAG", "MiniMemory"]     # real names


# --- history independence must survive checkpoint reloads (Theorem 1, A1) ---
@pytest.mark.parametrize("slice_size,victim", [(64, 150), (64, 10), (16, 100), (1000, 150)])
def test_hindex_history_independent_across_checkpoint_reloads(slice_size, victim):
    """hnswlib resets its level RNG on load_index; without reloading on every
    path, resuming from a checkpoint yields a different graph than building
    straight through. Three histories must give identical answers."""
    from palimpsest.defense.hindex import HISlicedHNSW
    rng = np.random.default_rng(0)
    X = rng.standard_normal((300, 32)).astype("float32")
    ids = [f"r{i:04d}" for i in range(300)]; v = ids[victim]
    Q = rng.standard_normal((30, 32)).astype("float32")
    mk = lambda: HISlicedHNSW(32, slice_size=slice_size, M=4, ef=20, ef_construction=40)
    never = mk(); never.add_many([r for r in ids if r != v], [x for r, x in zip(ids, X) if r != v])
    batch = mk(); batch.add_many(ids, X); batch.delete(v)
    incr = mk()
    for r, x in zip(ids, X):
        incr.add(r, x)
    incr.delete(v)
    ans = lambda h: [tuple(h.search(q, 10)[0]) for q in Q]
    assert ans(batch) == ans(never)
    assert ans(incr) == ans(never)


# --- LLM memo: exact under greedy decoding, batched path consistent ---
def test_llm_memo_and_batch_consistent():
    cfg = Config(); cfg.llm.backend = "echo"
    llm = LLM(cfg.llm)
    pairs = [("s", "Alice K3J9QX7PLM2Z"), ("s", "Bob ZZPOISON9QX7"), ("s", "Alice K3J9QX7PLM2Z")]
    outs = llm.complete_many(pairs)
    assert outs[0] == outs[2] == llm.complete("s", "Alice K3J9QX7PLM2Z")
    assert len(llm._memo) == 2                     # duplicate resolved once


# --- per-subject memory keeps prompts bounded and routes by name ---
def test_memory_is_per_subject_and_routes_by_name():
    _, llm, emb = _offline()
    subs = build_population(50, 3, 2)
    from palimpsest.systems import MiniMemory
    m = MiniMemory(llm, "naive"); m.ingest([d for s in subs for d in s.docs])
    assert len(m._entries) == 50
    obs = m.query(f"What is known about {subs[3].name}?")
    assert [h.doc_id for h in obs.hits] == [f"memory:{subs[3].subject_id}"] or \
           f"memory:{subs[3].subject_id}" in [h.doc_id for h in obs.hits]


# --- timed sections must not hit the LLM memo ---
def test_uncached_bypasses_memo_for_timing():
    cfg = Config(); cfg.llm.backend = "echo"
    llm = LLM(cfg.llm); calls = []
    orig = llm._call
    llm._call = lambda s, u, seed: (calls.append(u), orig(s, u, seed))[1]
    llm.complete("s", "x K3J9QX7PLM2Z"); llm.complete("s", "x K3J9QX7PLM2Z")
    assert len(calls) == 1                        # memo hit outside timing
    with llm.uncached():
        llm.complete("s", "x K3J9QX7PLM2Z")
        llm.complete_many([("s", "x K3J9QX7PLM2Z")])
    assert len(calls) == 3                        # real calls while timing
    llm.complete("s", "x K3J9QX7PLM2Z")
    assert len(calls) == 3                        # memo restored afterwards


def test_lsed_retrieval_only_never_calls_llm():
    _, llm, emb = _offline()
    calls = []
    llm.complete = lambda *a, **k: calls.append(1) or ""
    llm.complete_many = lambda pairs: calls.append(1) or ["" for _ in pairs]
    docs = [d for s in build_population(20, 3, 2) for d in s.docs]
    sut = LSEDSystem(llm, emb, emb.dim, n_partitions=4, slice_size=8, retrieval_only=True)
    sut.ingest(docs); sut.query("Who is someone?"); sut.delete([docs[0].doc_id])
    assert calls == [] and sut.query("x").hits


def test_render_style_switch():
    MiniGraphRAG.set_render_style("one_sentence")
    assert "one-sentence" in MiniGraphRAG._RENDER_SYS
    MiniGraphRAG.set_render_style("comprehensive")
    assert "every fact" in MiniGraphRAG._RENDER_SYS
    with pytest.raises(ValueError):
        MiniGraphRAG.set_render_style("bogus")


# --- shared managers: the running example needs Bob to manage several people ---
def test_managers_are_shared_and_deterministic():
    subs = build_population(40, 2, 1, seed=3, subjects_per_manager=10)
    managers = [s.manager for s in subs]
    assert len(set(managers)) == 4
    assert managers[0] == managers[9] != managers[10]
    assert managers == [s.manager for s in build_population(40, 2, 1, seed=3,
                                                              subjects_per_manager=10)]
    # manager descriptions must survive one subject's deletion (shared entity)
    _, llm, emb = _offline()
    g = MiniGraphRAG(llm, emb, "lsed"); g.ingest([d for s in subs for d in s.docs])
    g.delete([d.doc_id for d in subs[0].docs])
    assert managers[0] in g._entity_desc


def test_strict_answer_only_metrics_reported():
    from palimpsest.attacks import run_residue_recovery, run_zombie_poisoning
    _, llm, emb = _offline()
    subs = build_population(30, 3, 2); bg = [d for s in subs[1:] for d in s.docs]
    rr = run_residue_recovery(lambda: MiniGraphRAG(llm, emb, "naive"), bg, subs[0], 4)
    assert 0.0 <= rr.recovered_answer_frac <= rr.recovered_frac
    z = run_zombie_poisoning(lambda: MiniGraphRAG(llm, emb, "naive"), bg, subs, 4, 3, 6)
    assert z.asr_after_answer <= z.asr_after


# --- IVF-PQ: identical codebook GEOMETRY across worlds (no parameter confound) ---
def test_ivfpq_geometry_fixed_by_train_size():
    """With train_size set, the deletion world (background+target) and the
    counterfactual world (background only) train codebooks of identical shape,
    so deletion inference measures codebook CONTENT residue, not a size artifact."""
    _, _, emb = _offline()
    subs = build_population(300, 2, 1)
    bg = [d for s in subs[20:] for d in s.docs]
    target = subs[0]
    ts = len(bg)
    mk = lambda extra: FaissSUT(emb, emb.dim, kind="ivfpq",
                                deletion_option="remove_ids", train_size=ts)
    a = mk(None); a.ingest(bg + target.docs)
    b = mk(None); b.ingest(bg)
    assert a.effective == b.effective            # same nlist/nbits/m_pq


# --- DI reporting: CI brackets the AUC; low-FPR TPR flagged when not estimable ---
def test_di_reports_ci_and_min_fpr():
    from palimpsest.attacks import run_deletion_inference
    _, llm, emb = _offline()
    bg = [d for s in build_population(80, 3, 2) for d in s.docs]
    targets = build_population(12, 5, 2, seed=1, offset=DI_TARGET_OFFSET)
    r = run_deletion_inference(lambda: HnswlibSUT(emb, emb.dim, M=4, ef=20, ef_construction=40),
                               bg, targets, k=5, shadow_models=6, n_probe=2, n_control=2,
                               n_sentinels=3)
    lo, hi = r.auc_ci
    assert lo <= r.auc <= hi
    assert r.min_fpr == 1 / 6                     # 6 held-out negatives
    assert r.min_fpr > 0.01                       # => TPR@1% is NOT estimable here


# --- decoy null: identical live sets => LSED must be exactly at chance ---
def test_lsed_exact_under_decoy_null():
    """H1 deletes the target, H0 deletes a decoy: both leave the same live set,
    so a history-independent index must yield identical state => AUC = 0.5."""
    from palimpsest.attacks import run_deletion_inference
    _, llm, emb = _offline()
    bg = [d for s in build_population(60, 3, 2) for d in s.docs]
    targets = build_population(12, 5, 2, seed=1, offset=DI_TARGET_OFFSET)
    mk = lambda: LSEDSystem(llm, emb, emb.dim, n_partitions=8, slice_size=4, M=4, ef=20,
                            ef_construction=40, retrieval_only=True)
    r = run_deletion_inference(mk, bg, targets, k=5, shadow_models=6, n_probe=2,
                               n_control=2, n_sentinels=3, null="decoy")
    assert r.auc == 0.5 and r.null == "decoy"


# --- IVF nprobe is applied; sentinel-free channel has the expected shape ---
def test_ivf_nprobe_applied_and_topscore_channel():
    import faiss
    from palimpsest.attacks.deletion_inference import _features, _sentinel_docs
    _, _, emb = _offline()
    docs = [d for s in build_population(300, 2, 1) for d in s.docs]
    sut = FaissSUT(emb, emb.dim, kind="ivfpq", deletion_option="remove_ids",
                   train_size=len(docs), nprobe=4)
    sut.ingest(docs)
    assert faiss.downcast_index(sut._index.index).nprobe == 4
    t = build_population(1, 3, 1, seed=1, offset=DI_TARGET_OFFSET)[0]
    sents = _sentinel_docs(None, t.name, 3)
    f = _features(sut, t.name, sents, [f"Who is {t.name}?"] * 2, ["Who is x?"] * 2,
                  ("rank", "score", "topscore"))
    assert f.shape == (6,) and np.all(np.isfinite(f))


# --- IVF-PQ full rebuild retrains on exactly the counterfactual data => chance ---
def test_ivfpq_rebuild_is_exact():
    from palimpsest.attacks import run_deletion_inference
    _, _, emb = _offline()
    bg = [d for s in build_population(150, 3, 2) for d in s.docs]
    targets = build_population(12, 5, 2, seed=1, offset=DI_TARGET_OFFSET)
    mk = lambda: FaissSUT(emb, emb.dim, kind="ivfpq", deletion_option="rebuild",
                          train_size=len(bg), nprobe=1)
    r = run_deletion_inference(mk, bg, targets, k=5, shadow_models=6, n_probe=2,
                               n_control=2, n_sentinels=3,
                               channels=("rank", "score", "topscore"))
    assert r.auc == 0.5


# --- checkpoint directories must not leak (they filled the disk) ---
def test_hindex_checkpoints_cleaned_up(tmp_path, monkeypatch):
    import gc
    from palimpsest.defense.hindex import HISlicedHNSW
    monkeypatch.setenv("PALIMPSEST_CKPT_DIR", str(tmp_path))
    rng = np.random.default_rng(0); X = rng.standard_normal((120, 16)).astype("float32")
    ids = [f"r{i:03d}" for i in range(120)]
    for _ in range(5):
        h = HISlicedHNSW(16, slice_size=8, M=4, ef=20, ef_construction=40)
        h.add_many(ids, X); h.delete("r050")
        n_files = len(list(pathlib.Path(h.workdir).glob("ckpt_*.bin")))
        assert n_files == 120 // 8 - 1 or n_files <= 120 // 8   # no stale files pile up
        del h; gc.collect()
    assert list(tmp_path.iterdir()) == []                         # every workdir removed
