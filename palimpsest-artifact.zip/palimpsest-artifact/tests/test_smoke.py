"""Offline smoke tests (CPU, no downloads). Run: pytest -q"""
from palimpsest.config import Config
from palimpsest.llm import LLM, Embedder
from palimpsest.canaries import build_population
from palimpsest.systems import HnswlibSUT, FaissSUT, MiniGraphRAG, MiniMemory
from palimpsest.defense import LSEDSystem
from palimpsest.replay import run_replay
from palimpsest.attacks import run_residue_recovery, run_zombie_poisoning


def _setup():
    cfg = Config(); cfg.llm.backend = "echo"; cfg.emb.backend = "hash"; cfg.emb.dim = 128
    llm = LLM(cfg.llm); emb = Embedder(cfg.emb)
    subs = build_population(12, 3, 2, seed=0)
    bg = [d for s in subs[1:] for d in s.docs]
    return llm, emb, subs, bg


def test_hnswlib_shows_structural_residue():
    llm, emb, subs, bg = _setup()
    r = run_replay(lambda: HnswlibSUT(emb, emb.dim, deletion_option="mark_deleted"),
                   bg, subs[0], threshold=0.05)
    assert r.tier2_struct is True


def test_faiss_rebuild_is_clean():
    llm, emb, subs, bg = _setup()
    r = run_replay(lambda: FaissSUT(emb, emb.dim, kind="hnsw", deletion_option="rebuild"),
                   bg, subs[0], threshold=0.05)
    assert r.tier2_struct is False


def test_graphrag_naive_leaks_lsed_does_not():
    llm, emb, subs, bg = _setup()
    naive = run_replay(lambda: MiniGraphRAG(llm, emb, "naive"), bg, subs[0], 0.05)
    lsed = run_replay(lambda: MiniGraphRAG(llm, emb, "lsed"), bg, subs[0], 0.05)
    assert naive.tier3_semantic is True
    assert lsed.tier3_semantic is False


def test_residue_recovery_contrast():
    llm, emb, subs, bg = _setup()
    naive = run_residue_recovery(lambda: MiniGraphRAG(llm, emb, "naive"), bg, subs[0], 4)
    lsed = run_residue_recovery(lambda: MiniGraphRAG(llm, emb, "lsed"), bg, subs[0], 4)
    assert naive.recovered_frac > lsed.recovered_frac


def test_zombie_survives_naive_removed_by_lsed():
    llm, emb, subs, bg = _setup()
    zn = run_zombie_poisoning(lambda: MiniGraphRAG(llm, emb, "naive"), bg, subs, 4, 3, 6)
    zl = run_zombie_poisoning(lambda: MiniGraphRAG(llm, emb, "lsed"), bg, subs, 4, 3, 6)
    assert zn.asr_after >= zn.asr_counterfactual
    assert zl.asr_after <= zl.asr_before


def test_lsed_system_no_residue():
    llm, emb, subs, bg = _setup()
    r = run_replay(lambda: LSEDSystem(llm, emb, emb.dim, n_partitions=8, slice_size=4),
                   bg, subs[0], 0.05)
    assert not (r.tier1_copy or r.tier2_struct or r.tier3_semantic)
