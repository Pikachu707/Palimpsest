| Backend | Tier III (G / M) | M1 | M1 short | M4 | Zombie G before/after | Zombie M before/after | Counterfactual | LSED rec. / zombie |
|---|---|---|---|---|---|---|---|---|
| Qwen2.5-7B-Instruct (rerun) | 10/10 / 10/10 | 98 | 40 | 98 | 50/50 | 100/100 | 0 | 0 / 0 |
| Llama-3.1-8B-Instruct | 10/10 / 10/10 | 88 | 4 | 99 | 60/60 | 100/100 | 0 | 0 / 0 |
| Mistral-7B-Instruct-v0.3 | 10/10 / 10/10 | 95 | 92 | 94 | 95/95 | 100/100 | 0 | 0 / 0 |
| Gemma-2-9B-it | 10/10 / 10/10 | 100 | 53 | 100 | 100/100 | 100/100 | 0 | 0 / 0 |
| Qwen2.5-72B-Instruct | 10/10 / 10/10 | 100 | 99 | 99 | 100/100 | 100/100 | 0 | 0 / 0 |

## Reproducibility: Qwen2.5-7B-Instruct (rerun) vs Qwen2.5-7B-Instruct
| Metric | Paper run | Rerun | Abs. diff (pp) |
|---|---|---|---|
| tier3_graphrag | 100 | 100 | 0.0 |
| tier3_memory | 100 | 100 | 0.0 |
| rec_m1 | 99 | 98 | 1.0 |
| rec_m1_short | 42 | 40 | 2.0 |
| rec_m4 | 98 | 98 | 0.0 |
| zombie_after_g | 60 | 50 | 10.0 |
| zombie_after_m | 100 | 100 | 0.0 |
| zombie_cf | 0 | 0 | 0.0 |
| rec_lsed | 0 | 0 | 0.0 |
| zombie_lsed | 0 | 0 | 0.0 |
