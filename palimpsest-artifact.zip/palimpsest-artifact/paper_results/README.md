# Results behind the paper

`results/` has the same layout as a fresh run's `results/` directory:

| Directory | Paper |
|---|---|
| `final/`, `final_onesent/`, `di_*` | Sections 7.2 to 7.7, Figures 4 to 6, Table 3 (original runs, one NVIDIA B300) |
| `be_<tag>/`, `be_<tag>_onesent/` | Table 4 (backend sweep, a second B300; `be_qwen7b_repro` is Qwen2.5-7B rerun on that machine) |

`logs/main/` and `logs/backends/` hold the corresponding run logs, including each vLLM
server log, whose `serving [...]` line identifies the model behind every backend run.

Regenerate Table 4 and check that the sweep machine reproduces the original runs:

```bash
python -m palimpsest.report.backend_table --backends configs/backends.yaml --results paper_results/results
python scripts/compare_baseline.py --results paper_results/results --tol 0.10
```

The rerun of Qwen2.5-7B matches the original runs on every deletion outcome; it differs
only in MiniGraphRAG zombie success (50% vs. 60%), because greedy decoding under another
software stack extracts some poisoned documents differently (Table 4, footnote).
