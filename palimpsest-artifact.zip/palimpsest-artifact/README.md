# Palimpsest — Artifact

Code artifact for *"Palimpsest: Erased Data Still Shapes Retrieval-Augmented
LLM Systems"* (IEEE S&P submission). It measures whether deleting a record
from a retrieval-augmented system removes the record's **influence** on derived
artifacts (index structure, quantizer codebooks, LLM-merged descriptions,
consolidated memories), runs the paper's three client-side attacks, and
evaluates the LSED exact-deletion defense.

> **Scope and ethics.** Everything runs on systems you deploy locally, on
> synthetic personas with random canary tokens. No real personal data, no
> third-party services. Do not point the attack modules at systems you are not
> authorized to test.

---

## 1. Quick start (CPU, offline, ~2 minutes)

```bash
pip install -r requirements.txt      # pinned; Python 3.12
make test                            # 26 unit/regression tests, ~15 s
make check                           # full pipeline + 22 claim checks, ~2 min
```

`make check` runs every experiment with offline test doubles (an "echo" LLM
and hash embeddings), renders all paper figures from the measured data, and
prints one PASS/FAIL line per claim. Expected: `22/22 checks passed`. The raw
per-experiment lines are in `EXPECTED_SMOKE_OUTPUT.txt`; latency values there
vary by machine, everything else should match.

Docker (no local Python needed):

```bash
docker build -t palimpsest .
docker run --rm palimpsest           # runs `make test check`
```


## LLM-backend sweep

Every LLM-dependent experiment (RQ1 Tier III residue, RQ2 residue recovery and
zombie poisoning under naive and LSED deletion, and RQ2 with one-sentence
rendering) can be rerun per backend. Deletion inference does not involve the LLM
and is not rerun. Backends are listed in `configs/backends.yaml`.

```bash
pip install modelscope                         # only if weights must be downloaded
python scripts/run_backends.py --dry-run       # print the plan
python scripts/run_backends.py                 # all backends, one after another
python scripts/run_backends.py --only llama8b  # or a subset
```

On a fresh B300, first run `bash scripts/setup_b300.sh` (pinned stack, version and
architecture checks, all weights, tests). The sweep starts with `qwen7b_repro`, a
rerun of the paper's Qwen2.5-7B configuration that `backends.md` compares metric
by metric against the original runs; it is kept out of the paper table.

For each backend the driver downloads missing weights, starts vLLM
(`--attention-backend FLASH_ATTN`, `VLLM_USE_FLASHINFER_SAMPLER=0` for B300),
waits for readiness, runs the three stages into `results/be_<tag>[_onesent]/`,
and stops the server. It is resumable: finished backends are skipped. Logs go
to `logs/vllm_<tag>.log` and `logs/be_<tag>_<stage>.log`. At the end,
`python -m palimpsest.report.backend_table` writes `results/backends/`
(`summary.json`, `backends.md`, `backends_table.tex`); missing runs appear as
n/a and are never imputed.

Two client properties make the sweep sound: the completion memo is partitioned
by model, so no backend can be served another's cached answers, and
`llm.system_role: auto` merges the system prompt into the user turn for chat
templates that reject the system role (e.g. Gemma-2).

## 2. Claims and how to check them

| ID | Claim (paper section) | Command | Output | Smoke check |
|----|----|----|----|----|
| C1 | Copy deletion leaves structural (Tier II) residue in ANN indexes and semantic (Tier III) residue in graph-RAG and memory; a full rebuild leaves none (§7.2, Fig. 4) | `run.py rq1` | `rq1_residue.json` | exact tier pattern for all 5 systems |
| C2 | A client using only ranks and scores can infer that a subject was deleted (§5.1, §7.3, Fig. 5) | `run.py di` | `rq2_di_hnswlib.json` | AUC > 0.55 |
| C3 | Deleted documents' facts are recoverable from LLM-derived artifacts through queries (§5.2, Fig. 6) | `run.py rq2` | `rq2_recovery_zombie.json` | ≥ 90% recovered, 0 false recovery |
| C4 | Poison survives deletion of the poisoned documents (§5.3, Fig. 7) | `run.py rq2` | same | after-deletion ASR > counterfactual |
| C5 | Theorem 1: LSED is 0-complete for state-based interfaces (§6) | `run.py rq3` | `rq3_lsed.json` | DI-AUC **exactly** 0.5 for LSED and full rebuild |
| C6 | LSED removes text-level residue and the poison (§6, §7.4, Table 3) | `run.py rq3`, `rq2` | same | 0 recovery, after = counterfactual |
| C7 | Partition count trades deletion cost against tail latency (§7.5, Fig. 9) | `run.py ablations` | `ablations.json` | deletion latency ↓, p99 ↑ in S |

C5 is checked as an identity, not a statistic: in both worlds LSED's
rank/score features are bit-identical for every target, so every likelihood
score ties and the AUC is 0.5 by construction. `tests/test_regressions.py`
asserts the same identity directly.

## 3. What this artifact does and does not establish

**Established by the controlled pipelines** (claims C1–C7, qualitatively):
the residue taxonomy, the existence of each attack channel, LSED's exactness,
and the shape of its cost trade-off.

**Requires the full GPU run for magnitudes.** Smoke numbers come from test
doubles and tiny corpora. Only numbers from §4 belong in the paper.

**Not established here — needs external systems.** The controlled
`MiniGraphRAG` and `MiniMemory` pipelines implement mechanisms M1 (merged
descriptions) and M4 (consolidated memory). They do **not** implement community
reports (M2) or answer caches (M5), and their extraction cache (M3) is never
read by queries, so it shows up only as at-rest residue
(`per_mechanism_at_rest`), not client recovery. Paper statements about M2, M3,
and M5 — including any claim that cached LLM responses are the leakiest
mechanism — require validating against real GraphRAG/LightRAG/Mem0 deployments
via `palimpsest/systems/external_adapters.py`, whose methods are stubs marked
`# VERIFY:`. The exporter writes `null` for these cells; it never fills them in.

**Two conditions the paper should state** (found while building this artifact):

1. *Rank-visible structural residue requires approximate search.* With
   near-exact HNSW search (e.g. M=16, ef=64 over a few hundred vectors),
   deletion moves no ranks and C2 cannot succeed. With approximate search
   (M=4, ef=20) sentinels shift by up to 19 positions. Real deployments are
   approximate, but the run should sweep `ef`.
3. *IVF-PQ ghost centroids.* When a subject has enough records to form a
   dense cluster, k-means dedicates a coarse centroid to it. Deletion removes
   the vectors but not the centroid, so later queries about that subject are
   routed to an emptied inverted list and the subject's neighbourhood "goes
   dark". With `nprobe=1` this is client-visible; with larger `nprobe`
   neighbouring lists refill the hole, so sweep `index.ivf_nprobe`. The
   sentinel-free `topscore` channel (`--set "attack.di_channels=[rank,score,topscore]"`)
   observes it directly. When features saturate (e.g. no sentinel ever
   retrieved), different k can yield bit-identical scores; that is
   saturation, not a bug. IVF-PQ is the exception: its
   trained codebook retains a deleted record's influence (deletion does not
   retrain it), so `remove_ids` leaves a score-channel signal even with exact
   search. That residue lives in the GLOBAL codebook, so it is present already
   at k=1 and does not grow much with k -- unlike the HNSW repair-edge scar.
   `attack.di_channels` and `index` settings select the interface; for IVF-PQ
   `train_size` fixes the codebook geometry across worlds so the attack
   measures content residue, not a parameter-size artifact.
2. *Timing.* At smoke scale all four timing conditions (native/LSED ×
   padded/unpadded) are within the 95% interval of chance: traversing a few
   tombstones in a ~600-vector index is too cheap to time. Whether padding is
   needed was settled by the full-scale runs (see Hardware below), not here.

## 4. Full run on a GPU server (local, offline)

All inference runs on the server; nothing calls a remote API. Weights are
downloaded **once** from ModelScope (no account) and every run sets
`HF_HUB_OFFLINE=1`, so any attempted network access fails loudly. Use two
environments: vLLM pins its own torch/transformers.

```bash
pip install uv
# vLLM environment (+ one-time weight download)
uv venv --python 3.12 /workspace/venv-vllm && source /workspace/venv-vllm/bin/activate
uv pip install "vllm==0.10.2" "transformers>=4.56,<5" modelscope --torch-backend=cu128
modelscope download --model Qwen/Qwen2.5-7B-Instruct --local_dir /workspace/models/Qwen2.5-7B-Instruct
modelscope download --model BAAI/bge-large-en-v1.5   --local_dir /workspace/models/bge-large-en-v1.5
tmux new -s vllm  'bash scripts/start_vllm.sh'      # serves /workspace/models/Qwen2.5-7B-Instruct
deactivate

# artifact environment
uv venv --python 3.12 /workspace/venv-art && source /workspace/venv-art/bin/activate
uv pip install -r requirements.txt openai sentence-transformers "transformers>=4.56,<5"
uv pip install "torch==2.8.0" --torch-backend=cu128
make pilot           # small run: measure runtime first
make local           # all experiments -> results/local_full/
make local-approx    # DI in the approximate-search regime
make figures-local   # paper figures, no watermark
```

**Final runs.** `scripts/final_runs.sh` splits the paper's experiments into
four independent groups -- `llm`, `ivf8`, `ivf1`, `controls` -- meant to run
in parallel, one tmux window each (index builds are single-threaded; each
group loads its own ~1.5 GB embedding model next to vLLM). Logs go to `logs/`.
LSED checkpoints go to `$PALIMPSEST_CKPT_DIR` (default: system temp) and are
deleted when each index is released.

`configs/local.yaml` points at the local weight paths and disables the BEIR
download. Any value can be overridden: `--set index.hnsw_ef=32 --set run_name=ef32`.

**Version pins** (`requirements-gpu.txt`): `vllm==0.10.2` with CUDA 12.8 torch
works on drivers that support CUDA 12.8; newer vLLM wheels fail with "NVIDIA
driver too old". `transformers<5` is required by vLLM 0.10.2.

**Cost.** LLM completions are memoized (exact under `temperature: 0`) and sent
32-way concurrent, so repeated derivations across the paired worlds cost one
request. At pilot scale this cuts ~374k logical completions to ~8.4k requests.
The deletion-inference shadow loop builds `2 × (shadow_models +
di_test_subjects)` index deployments per `k`; lower `attack.shadow_models` for
a faster pass.


## Hardware used for the paper

- **Pilot:** one NVIDIA A100 SXM (80 GB), driver supporting CUDA 12.8. Newer
  vLLM wheels refused this driver ("NVIDIA driver too old"), so the pilot used
  `vllm==0.10.2` with CUDA 12.8 torch and `transformers<5`.
- **Final runs:** one NVIDIA B300 (288 GB, compute capability 10.3), driver
  580 / CUDA 13. Use the newest vLLM with `--torch-backend=auto`; do NOT reuse
  the A100 pins. FlashInfer could not JIT-compile its sm_103 attention kernel
  without `nvcc` in the container, so vLLM was started with
  `--attention-backend FLASH_ATTN` and `VLLM_USE_FLASHINFER_SAMPLER=0`.
  Neither change affects results (greedy decoding; latency is measured on the
  retrieval layer).
- Phase timing on the B300 (16 vCPU): LLM experiments ~20 min; each IVF-PQ
  deletion-inference run with 200 held-out subjects ~2-4 h; all runs ~4.5 h
  with four groups in parallel.

## 5. Determinism

Counterfactual replay compares two worlds that must be identical except for
the deleted record, so **every index is built single-threaded**
(`num_threads=1` in hnswlib, `omp_set_num_threads(1)` in FAISS).
Multithreaded HNSW construction is nondeterministic — with 8 threads, 0 of 5
identical rebuilds return identical results — and on a multi-core host would
make construction noise indistinguishable from Tier II residue. Parallelize
across deployments (separate processes), never within one. LLM generation uses
`temperature: 0.0`, which LSED's deterministic re-rendering also requires.

## 6. From results to the paper

```
run.py rq1 … timing  ->  results/<run>/*.json
run.py report        ->  results_snippets.tex    (LaTeX cells for the tables)
run.py export        ->  figure_data.json        (schema = paper_figures/data/placeholder.json)
run.py figures       ->  results/<run>/figures/*.pdf
```

Copy the PDFs into the paper's `figures/` directory. The paper's final figures are rendered directly from the result
directories with `python paper_figures/make_final_figures.py --results results --outdir figs`. Measured systems keep
their real names (e.g. `MiniGraphRAG`), so a figure cannot silently present a
controlled pipeline as GraphRAG.

## 7. Layout

```
palimpsest/
  canaries.py stats.py llm.py replay.py config.py
  systems/     ann_faiss ann_hnswlib graphrag_mini memory_mini external_adapters base
  attacks/     deletion_inference residue_recovery zombie_poisoning
  defense/     hindex (history-independent HNSW) lsed (LSEDSystem)
  experiments/ rq1_residue rq2_deletion_inference rq2_recovery_zombie rq3_lsed ablations common
  report/      make_report export_figure_data
paper_figures/ make_figures.py data/placeholder.json
configs/       smoke.yaml local.yaml hf_models.yaml
scripts/       check_smoke.py start_vllm.sh download_beir.sh
tests/         test_smoke.py test_regressions.py
```

## 8. Changes since the first code drop

Bugs found during artifact preparation; each is pinned by a regression test.

- Index construction is now single-threaded (see §5).
- Deletion-inference targets were part of the background corpus, so the
  "never ingested" world still contained them; targets are now a disjoint,
  config-determined population, and `k` is no longer silently capped.
- DI features included latency, contrary to the paper's rank+score setting
  and outside Theorem 1; channels are now explicit (`attack.di_channels`).
- FAISS IVF-PQ never trained at small scale; training now adapts and records
  its effective parameters.
- `LSEDSystem` ignored `n_partitions` and the padding flag; both now work.
- Compound pipelines did not erase copies, and replay counted derived-text
  hits as Tier I; tiers are now attributed correctly.
- M3 was credited with client recovery it cannot produce.
- Timing measurements are interleaved between worlds and report a standard error.
- LSED's history-independent index was not history-independent across
  checkpoint reloads (hnswlib resets its level RNG on load): every build path
  now resumes from the reloaded checkpoint. Verified for three histories.
- LLM calls are memoized and batched; per-entity rendering only touches
  changed entities; LSED ingests one batch per partition.
- Deletion inference reports a stratified-bootstrap 95% CI for the AUC,
  TPR@5% and TPR@10%, and the smallest attainable FPR (1/#negatives);
  TPR@1% is printed as n/a when fewer than 100 negatives make it
  inestimable. Its features are coarse (integer sentinel ranks), so scores
  tie heavily and different conditions can share an identical AUC; this is
  expected, not a bug. `--set attack.di_null=decoy` uses a stricter null in
  which ANOTHER subject's records are deleted, so the attack must identify
  whose records were erased; LSED is exactly at chance under it too, since
  both worlds keep the same live set.
- LSED checkpoint directories were never deleted; a long run filled the
  disk, after which truncated checkpoints loaded as "corrupted" indexes
  (segfault). Each index now removes its directory when released, and stale
  checkpoint files are deleted as soon as they are superseded.
- Deletion-inference findings (pilot scale, Qwen2.5-7B + bge-large): HNSW
  rank/score residue was not client-visible (AUC ~0.5); IVF-PQ residue was
  (AUC 0.79-0.93 at nprobe=1 via ghost centroids, 0.73-0.84 at nprobe>=8 via
  codebook content), but under the decoy null it fell to chance at both
  settings: the attack detects THAT a deletion happened, not WHOSE. Records in
  the synthetic population share one template, so a ghost centroid is not
  name-specific; heterogeneous corpora may differ (untested).
- Timed measurements bypass the LLM memo (a memo hit costs ~0 ms);
  query latency, the partition sweep, and the timing channel are measured on
  the retrieval layer, which is what partitioning changes; deletion latency
  is end-to-end including LLM re-rendering.
- MiniGraphRAG rendered merged descriptions as ONE sentence, which on a real
  LLM dropped ~68% of facts (extraction kept 99.7%; descriptions kept 32%).
  The default is now a comprehensive description that keeps every fact, as in
  GraphRAG-style description summarization; the lossy variant remains as an
  ablation: `--set graph.render_style=one_sentence`.
- Managers are shared (`data.subjects_per_manager`, default 10), so a
  manager's merged description mixes several subjects, as in the running
  example; with unique managers, deleting a subject deleted its manager's
  entity outright and LSED never had to re-render anything.
- Residue recovery and zombie poisoning report two clients: answer-only
  (strict) and answer + returned context (a client shown sources).
- RQ3 reports end-to-end latency (with generation, memo bypassed) next to
  retrieval-layer latency; the ablation baseline is warmed up; the slice-size
  sweep uses one partition so checkpoints are actually exercised.
- Agent memory is per subject (as in the running example), which also bounds
  every consolidation prompt; a single global memory overflowed the context
  window at realistic corpus sizes.

## License

MIT (see `LICENSE`). Change before release if your institution requires otherwise.

## Results behind the paper

`paper_results/` contains the raw results and logs behind every figure and table, including the LLM-backend sweep of Table 4; see `paper_results/README.md`.
