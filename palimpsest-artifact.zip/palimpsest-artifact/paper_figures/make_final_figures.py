#!/usr/bin/env python3
"""Render the paper's data figures from MEASURED results, in the style of
systems papers such as NSDI'25 ntprof:
  * every line carries markers; legends sit ABOVE the axes in a framed box,
    spread over several columns; dual-axis plots colour each axis like its series;
  * bars have thin black edges; full axis box; inward ticks; light dotted grid;
  * panels are drawn on FIXED, equal canvases at their printed size, so a row of
    panels tiles exactly (4 per text width, or 2 per column width).
Palette (muted): naive = brick, LSED = navy, baselines = khaki / grey.

    python make_final_figures.py --results /path/to/results --outdir .
"""
import argparse, glob, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
from sklearn.metrics import roc_curve

NAVY, BRICK, BRICK_L, OLIVE = "#1F3B5C", "#B5523F", "#DDA08F", "#8A9A3B"
KHAKI, GREY, GREY_L, TEAL = "#D8CF96", "#7F7F7F", "#CFCFCF", "#2B7A73"
TIER = {0: "#5B7DA3", 1: "#B8924A", 2: "#A15C57"}
EDGE, INK, GRID = "#000000", "#111111", "#D6D6D6"
QW, QH = 1.74, 1.52          # quarter-text-width panel (figure* row of four)
HW, HH = 1.70, 1.45          # half-column panel (two per column)
CW, CH = 3.45, 1.55          # full single-column figure


def style(fs=6.4):
    plt.rcParams.update({
        "font.family": "Liberation Sans", "font.size": fs, "axes.labelsize": fs,
        "xtick.labelsize": fs - 0.6, "ytick.labelsize": fs - 0.6, "legend.fontsize": fs - 0.8,
        "axes.linewidth": 0.6, "axes.edgecolor": "#262626", "axes.labelcolor": INK,
        "text.color": INK, "xtick.color": "#262626", "ytick.color": "#262626",
        "xtick.direction": "in", "ytick.direction": "in", "xtick.top": True, "ytick.right": True,
        "xtick.major.size": 2.2, "ytick.major.size": 2.2, "xtick.major.width": 0.5,
        "ytick.major.width": 0.5, "lines.linewidth": 1.0, "lines.markersize": 3.2,
        "legend.frameon": True, "legend.framealpha": 1.0, "legend.edgecolor": "#262626",
        "legend.fancybox": False, "legend.borderpad": 0.3, "legend.handlelength": 1.6,
        "legend.handletextpad": 0.35, "legend.columnspacing": 0.8, "legend.borderaxespad": 0.2,
        "axes.axisbelow": True, "hatch.linewidth": 0.5,
        "pdf.fonttype": 42, "ps.fonttype": 42, "figure.dpi": 200,
        "figure.constrained_layout.use": False,
    })


# Axes boxes share bottom/top across every panel of a row (ntprof-style tiling);
# the band above `top` holds the framed legend (or the AUC colour scale).
ROW_BOTTOM, ROW_TOP = 0.215, 0.80


def panel(w, h, left, right=0.965):
    fig = plt.figure(figsize=(w, h))
    ax = fig.add_axes([left, ROW_BOTTOM, right - left, ROW_TOP - ROW_BOTTOM])
    return fig, ax


def grid(ax, axis="both"):
    ax.grid(True, axis=axis, color=GRID, lw=0.45, ls=(0, (1, 1.6)))


def top_legend(ax, handles, labels, ncol, fs=None):
    kw = dict(loc="lower center", bbox_to_anchor=(0.5, 1.03), ncol=ncol, borderaxespad=0.0,
              handlelength=1.2, columnspacing=0.6, handletextpad=0.3)
    if fs: kw["fontsize"] = fs
    return ax.legend(handles, labels, **kw)


def load(d, pattern):
    f = glob.glob(os.path.join(d, pattern))
    return json.load(open(f[0])) if f else None


def di(d, run):
    j = load(os.path.join(d, run), "rq2_di_*.json")
    return j["curves"] if j else {}


def save(fig, out):
    fig.savefig(out); plt.close(fig)


# ---------------- Fig. 4: residue matrix (single column) ----------------
def fig_rq1(R, out):
    style(6.6)
    sysmap = [("faiss-hnsw", "FAISS HNSW\n(rebuild)"), ("faiss-ivfpq", "FAISS IVF-PQ\n(remove_ids)"),
              ("hnswlib", "hnswlib\n(mark_deleted)"), ("graphrag", "MiniGraphRAG\n(naive)"),
              ("memory", "MiniMemory\n(naive)")]
    rq1 = load(os.path.join(R, "final"), "rq1_residue.json")["systems"]
    sem = {"graphrag", "memory"}
    fig = plt.figure(figsize=(CW, CH))
    ax = fig.add_axes([0.235, 0.215, 0.76, 0.775])
    for c, (sid, _) in enumerate(sysmap):
        v = [rq1[sid]["tier1_frac"], rq1[sid]["tier2_frac"], rq1[sid]["tier3_frac"]]
        for r in range(3):
            if r == 2 and sid not in sem:
                ax.add_patch(plt.Rectangle((c - .5, r - .5), 1, 1, fc="white", ec="#BDBDBD", lw=0.5, hatch="////"))
                ax.text(c, r, "n/a", ha="center", va="center", color=GREY, fontsize=6.0,
                        bbox=dict(fc="white", ec="none", pad=0.5))
                continue
            hit = v[r] > .5
            ax.add_patch(plt.Rectangle((c - .5, r - .5), 1, 1, fc=TIER[r] if hit else "#F3F3F3",
                                       ec="white", lw=1.4))
            ax.text(c, r, f"{round(v[r]*10)}/10", ha="center", va="center", fontsize=6.6,
                    color="white" if hit else GREY, fontweight="bold" if hit else "normal")
    ax.set_xlim(-.5, len(sysmap) - .5); ax.set_ylim(2.5, -.5)
    ax.set_xticks(range(len(sysmap))); ax.set_xticklabels([s for _, s in sysmap], fontsize=5.7)
    ax.set_yticks([0, 1, 2]); ax.set_yticklabels(["Tier I (copy)", "Tier II (structural)", "Tier III (semantic)"], fontsize=6.2)
    ax.tick_params(length=0, top=False, right=False)
    for s in ax.spines.values():
        s.set_visible(False)
    save(fig, out)


# ---------------- Fig. 5: four panels in one row ----------------
def p_roc(R, out):
    style()
    fig, ax = panel(QW, QH, left=0.235)
    cur = di(R, "di_ivf_np8")
    sty = {"1": (GREY, "-", "o"), "5": (BRICK, "-", "s"), "20": (NAVY, "-", "^")}
    hs, ls_ = [], []
    marks = np.logspace(-3, 0, 8)
    for k in ("1", "5", "20"):
        c = cur[k]; fpr, tpr, _ = roc_curve(c["labels"], c["scores"])
        col, ls, mk = sty[k]
        x = np.clip(fpr, 1e-3, 1)
        ax.plot(x, tpr, color=col, ls=ls, drawstyle="steps-post", lw=1.0)
        my = [tpr[np.searchsorted(x, m, side="right") - 1] for m in marks]
        ax.plot(marks, my, ls="none", marker=mk, color=col, mfc="white", mew=0.8, ms=3.0)
        hs.append(Line2D([0], [0], color=col, marker=mk, mfc="white", mew=0.8, ms=3.0))
        ls_.append(f"k={k}")
    ax.plot([1e-3, 1], [1e-3, 1], ls=(0, (2, 1.5)), color=GREY_L, lw=0.8)
    ax.axvline(.01, color=GREY, lw=0.6, ls=":")
    ax.set_xscale("log"); ax.set_xlim(1e-3, 1); ax.set_ylim(0, 1.02)
    ax.set_xticks([1e-3, 1e-2, 1e-1, 1]); ax.set_xticklabels(["0.001", "0.01", "0.1", "1"])
    ax.xaxis.set_minor_locator(NullLocator())
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate"); grid(ax)
    top_legend(ax, hs, ls_, 3)
    save(fig, out)


def p_auc(R, out):
    style()
    rows = [("HNSW", "di_hnsw_approx"), ("IVF-PQ np=1", "di_ivf_np1"), ("IVF-PQ np=8", "di_ivf_np8"),
            ("Decoy np=1", "di_ivf_np1_decoy"), ("Decoy np=8", "di_ivf_np8_decoy"),
            ("Rebuild", "di_ivf_rebuild"), ("LSED", "di_lsed")]
    ks = ["1", "5", "20"]
    cmap = LinearSegmentedColormap.from_list("auc", ["#FFFFFF", "#D9E1EA", "#6F8BAA", NAVY])
    fig, ax = panel(QW, QH, left=0.345, right=0.975)
    for i, (lab, run) in enumerate(rows):
        for j, k in enumerate(ks):
            c = di(R, run).get(k)
            if not c:
                ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fc="white", ec="#D0D0D0", lw=0.4, hatch="////"))
                continue
            t = max(0.0, min(1.0, (c["auc"] - .5) / .5))
            ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fc=cmap(t), ec="white", lw=0.9))
            ax.text(j, i, f"{c['auc']:.2f}", ha="center", va="center", fontsize=5.7,
                    color="white" if t > .5 else INK)
    for y in (2.5, 4.5):
        ax.axhline(y, color="#262626", lw=0.6)
    ax.set_xlim(-.5, 2.5); ax.set_ylim(len(rows) - .5, -.5)
    ax.set_xticks(range(3)); ax.set_xticklabels([f"k={k}" for k in ks])
    ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows])
    ax.tick_params(length=0, top=False, right=False, pad=1.5)
    for s in ax.spines.values():
        s.set_linewidth(0.6)
    ax.set_xlabel("Deleted records")
    # colour scale in the legend band, aligned with the axes box
    pos = ax.get_position()
    cax = fig.add_axes([pos.x0 + 0.08 * pos.width, ROW_TOP + 0.075, 0.84 * pos.width, 0.055])
    grad = np.linspace(0, 1, 256)[None, :]
    cax.imshow(grad, aspect="auto", cmap=cmap, extent=[0.5, 1.0, 0, 1])
    cax.set_yticks([]); cax.set_xticks([0.5, 0.75, 1.0]); cax.set_xticklabels(["0.5", "AUC", "1.0"])
    cax.tick_params(axis="x", length=0, pad=1.0, labelsize=5.4, top=False, bottom=True)
    for sp in cax.spines.values():
        sp.set_linewidth(0.5)
    save(fig, out)


def p_recovery(R, out):
    style()
    rr = load(os.path.join(R, "final"), "rq2_recovery_zombie.json")["residue_recovery"]
    one = load(os.path.join(R, "final_onesent"), "rq2_recovery_zombie.json")["residue_recovery"]
    cats = [("M1", rr["graphrag:naive"]["per_mechanism_client"].get("M1", 0), BRICK, None),
            ("M1\n(short)", one["graphrag:naive"]["per_mechanism_client"].get("M1", 0), BRICK_L, None),
            ("M3", rr["graphrag:naive"]["per_mechanism_at_rest"].get("M3", 0), "white", "/////"),
            ("M4", rr["memory:naive"]["per_mechanism_client"].get("M4", 0), BRICK, None)]
    fig, ax = panel(QW, QH, left=0.235)
    w = 0.36
    for i, (lab, v, col, hatch) in enumerate(cats):
        ax.bar(i - w / 2, v * 100, w, fc=col, ec=EDGE if not hatch else BRICK, hatch=hatch, lw=0.5)
        ax.bar(i + w / 2, 0.0, w, fc=NAVY, ec=EDGE, lw=0.5)
        ax.text(i - w / 2, v * 100 + 2.5, f"{v*100:.0f}", ha="center", fontsize=5.4)
        ax.text(i + w / 2, 2.5, "0", ha="center", fontsize=5.4, color=NAVY, fontweight="bold")
    ax.set_xticks(range(len(cats))); ax.set_xticklabels([c[0] for c in cats])
    ax.set_ylim(0, 112); ax.set_yticks([0, 25, 50, 75, 100]); ax.set_xlim(-.6, len(cats) - .4)
    ax.set_ylabel("Facts recovered (%)"); grid(ax, "y")
    top_legend(ax, [Patch(fc=BRICK, ec=EDGE, lw=0.5), Patch(fc="white", ec=BRICK, hatch="/////", lw=0.5),
                    Patch(fc=NAVY, ec=EDGE, lw=0.5)], ["Naive", "At rest", "LSED"], 3)
    save(fig, out)


def p_zombie(R, out):
    style()
    z = load(os.path.join(R, "final"), "rq2_recovery_zombie.json")["zombie"]
    systems = [("graphrag", "GraphRAG"), ("memory", "Memory")]
    conds = [("before", "naive", "Before", KHAKI, None), ("after", "naive", "Naive", BRICK, None),
             ("after", "lsed", "LSED", NAVY, None), ("counterfactual", "naive", "Never", "white", "....")]
    fig, ax = panel(QW, QH, left=0.235)
    xs = np.arange(len(systems)); w = 0.2
    for j, (field, opt, lab, col, hatch) in enumerate(conds):
        vals = [z[f"{s_}:{opt}"][field] * 100 for s_, _ in systems]
        ax.bar(xs + (j - 1.5) * w, vals, w * 0.92, fc=col, ec=EDGE, lw=0.5, hatch=hatch, label=lab)
        for x, v in zip(xs, vals):
            if v == 0:      # tall bars read off the axis; zeros carry the finding
                ax.text(x + (j - 1.5) * w, 2.5, "0", ha="center", fontsize=5.4,
                        color=NAVY if opt == "lsed" else GREY, fontweight="bold" if opt == "lsed" else "normal")
    ax.set_xticks(xs); ax.set_xticklabels([n for _, n in systems]); ax.set_xlim(-.55, 1.55)
    ax.set_ylim(0, 112); ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_ylabel("Attack success (%)"); grid(ax, "y")
    h, l = ax.get_legend_handles_labels(); top_legend(ax, h, l, 4, fs=5.2)
    save(fig, out)


# ---------------- Appendix: two half-column panels ----------------
def p_sweep_s(R, out):
    style()
    a = load(os.path.join(R, "final"), "ablations.json")
    S = sorted(a["partition_sweep"], key=int); s = [int(x) for x in S]
    dl = [a["partition_sweep"][x]["del_lat_s"] * 1000 for x in S]
    px = [a["partition_sweep"][x]["p99_x_native"] for x in S]
    fig, ax = panel(HW, HH, left=0.215, right=0.80)
    ax.plot(s, dl, "-o", color=NAVY, mfc="white", mew=0.8)
    ax.set_xscale("log", base=2); ax.set_yscale("log")
    ax.set_xlabel("Partitions S"); ax.set_ylabel("Deletion latency (ms)", color=NAVY)
    ax.tick_params(axis="y", colors=NAVY, right=False)
    ax.set_xticks(s); ax.set_xticklabels([str(x) for x in s]); ax.xaxis.set_minor_locator(NullLocator())
    yt = [t for t in (2, 3, 5, 10, 20, 30, 50) if min(dl) * .8 <= t <= max(dl) * 1.25]
    ax.yaxis.set_major_locator(FixedLocator(yt)); ax.yaxis.set_major_formatter(FixedFormatter([str(t) for t in yt]))
    ax.yaxis.set_minor_locator(NullLocator()); grid(ax)
    ax2 = ax.twinx(); ax2.plot(s, px, ls=(0, (3, 1.5)), marker="s", color=BRICK, mfc="white", mew=0.8)
    ax2.set_ylabel("Retrieval p99 (x)", color=BRICK); ax2.tick_params(axis="y", colors=BRICK, direction="in")
    top_legend(ax, [Line2D([0], [0], color=NAVY, marker="o", mfc="white"),
                    Line2D([0], [0], color=BRICK, ls=(0, (3, 1.5)), marker="s", mfc="white")],
               ["Deletion", "Retrieval p99"], 2)
    save(fig, out)


def p_sweep_c(R, out):
    style()
    a = load(os.path.join(R, "final"), "ablations.json")["slice_sweep"]
    C = sorted(a, key=int); v = [a[c]["del_lat_s"] for c in C]
    fig, ax = panel(HW, HH, left=0.215)
    ax.bar(range(len(C)), v, 0.55, fc=OLIVE, ec=EDGE, lw=0.5, label="Deletion latency")
    for i, y in enumerate(v):
        ax.text(i, y + 0.03, f"{y:.2f}", ha="center", fontsize=5.6)
    ax.set_xticks(range(len(C))); ax.set_xticklabels(C)
    ax.set_xlabel("Slice size c (records)"); ax.set_ylabel("Deletion latency (s)")
    ax.set_ylim(0, 1.5); grid(ax, "y")
    h, l = ax.get_legend_handles_labels(); top_legend(ax, h, l, 1)
    save(fig, out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--outdir", default=".")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    P = lambda n: os.path.join(a.outdir, n)
    fig_rq1(a.results, P("fig_rq1_heat.pdf"))
    p_roc(a.results, P("fig_rq2a_roc.pdf")); p_auc(a.results, P("fig_rq2b_auc.pdf"))
    p_recovery(a.results, P("fig_rq2c_recovery.pdf")); p_zombie(a.results, P("fig_rq2d_zombie.pdf"))
    p_sweep_s(a.results, P("fig_abl_s.pdf")); p_sweep_c(a.results, P("fig_abl_c.pdf"))
    print("wrote measured figures to", a.outdir)


if __name__ == "__main__":
    main()
