#!/usr/bin/env python3
"""Check that this machine reproduces the paper's LLM-dependent runs.

Compares results/be_qwen7b_repro[_onesent] (the `qwen7b_repro` backend, i.e.
python scripts/run_backends.py --only qwen7b_repro) with the paper's
results/final[_onesent]. Greedy decoding on a different vLLM/CUDA build
can change individual completions, so small differences are possible; the
invariants (LSED and counterfactual at 0) must hold exactly.

    python scripts/compare_baseline.py [--results results] [--tol 0.05]
"""
import argparse, json, sys
from pathlib import Path


def flat(o, pre=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from flat(v, f"{pre}{k}.")
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        yield pre[:-1], float(o)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--tol", type=float, default=0.05, help="max abs difference for rates")
    ap.add_argument("--run", default="be_qwen7b_repro", help="rerun to compare with the paper's runs")
    a = ap.parse_args()
    R = Path(a.results)
    pairs = [("final/rq1_residue.json", f"{a.run}/rq1_residue.json"),
             ("final/rq2_recovery_zombie.json", f"{a.run}/rq2_recovery_zombie.json"),
             ("final_onesent/rq2_recovery_zombie.json", f"{a.run}_onesent/rq2_recovery_zombie.json")]
    worst, n, fail = 0.0, 0, []
    for old, new in pairs:
        if not (R / old).exists() or not (R / new).exists():
            sys.exit(f"missing {R/old} or {R/new}")
        A = dict(flat(json.load(open(R / old)))); B = dict(flat(json.load(open(R / new))))
        for k in sorted(set(A) & set(B)):
            if any(t in k for t in ("latency", "_s", "time", "seconds")):
                continue                      # wall-clock values are machine-dependent
            d = abs(A[k] - B[k]); n += 1; worst = max(worst, d)
            if d > a.tol:
                fail.append(f"  {new}:{k}  paper={A[k]:.3f}  here={B[k]:.3f}")
            must_be_zero = ((":lsed." in k and ("after" in k or "recovered" in k or "per_mechanism" in k))
                            or "counterfactual" in k or "false_recovery" in k)
            if must_be_zero and B[k] != 0.0:
                fail.append(f"  INVARIANT {new}:{k} = {B[k]} (must be 0)")
    print(f"compared {n} measured rates; largest difference {worst:.3f} (tolerance {a.tol})")
    if fail:
        print("DIFFERENCES:\n" + "\n".join(fail)); sys.exit(1)
    print("OK: this machine reproduces the paper's LLM-dependent runs")


if __name__ == "__main__":
    main()
