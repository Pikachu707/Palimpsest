#!/usr/bin/env python3
"""Check a smoke run against the paper's qualitative claims.

Usage: python scripts/check_smoke.py results/smoke [EXPECTED_SMOKE_OUTPUT.txt]

Timing and latency values vary by machine, so this checks the properties the
paper relies on (tier pattern, exactness, attack ordering), not exact numbers.
Exit code 0 iff every check passes.
"""
import json
import sys
from pathlib import Path


def main():
    d = Path(sys.argv[1] if len(sys.argv) > 1 else "results/smoke")
    load = lambda n: json.loads((d / n).read_text())
    checks = []
    def check(cid, desc, ok):
        checks.append((cid, desc, bool(ok)))

    rq1 = load("rq1_residue.json")["systems"]
    tiers = lambda s: tuple(int(rq1[s][f"tier{i}_frac"] > 0.5) for i in (1, 2, 3))
    check("C1", "FAISS-HNSW + rebuild leaves no residue (-,-,-)", tiers("faiss-hnsw") == (0, 0, 0))
    check("C1", "FAISS-IVFPQ: structural residue only (-,*,-)", tiers("faiss-ivfpq") == (0, 1, 0))
    check("C1", "hnswlib mark_deleted: structural residue only (-,*,-)", tiers("hnswlib") == (0, 1, 0))
    check("C1", "graph-RAG: structural + semantic (-,*,*)", tiers("graphrag") == (0, 1, 1))
    check("C1", "agent memory: semantic only (-,-,*)", tiers("memory") == (0, 0, 1))

    di = load("rq2_di_hnswlib.json")["curves"]
    check("C2", "deletion inference beats chance on native hnswlib (AUC > 0.55)",
          max(c["auc"] for c in di.values()) > 0.55)

    rz = load("rq2_recovery_zombie.json")
    for s in ("graphrag", "memory"):
        n, l = rz["residue_recovery"][f"{s}:naive"], rz["residue_recovery"][f"{s}:lsed"]
        check("C3", f"{s}: naive deletion leaks canary facts (>= 0.9)", n["recovered_mean"] >= 0.9)
        check("C3", f"{s}: no false recovery in counterfactual", n["false_recovery_mean"] == 0)
        check("C6", f"{s}: LSED leaks nothing", l["recovered_mean"] == 0)
        zn, zl = rz["zombie"][f"{s}:naive"], rz["zombie"][f"{s}:lsed"]
        check("C4", f"{s}: poison survives naive deletion (after > counterfactual)",
              zn["after"] > zn["counterfactual"])
        check("C6", f"{s}: LSED removes the poison (after == counterfactual)",
              zl["after"] == zl["counterfactual"])

    rq3 = load("rq3_lsed.json")
    check("C5", "Theorem 1: LSED DI-AUC exactly 0.5 (state features identical)",
          rq3["lsed"]["di_auc"] == 0.5)
    check("C5", "full rebuild DI-AUC exactly 0.5", rq3["full_rebuild"]["di_auc"] == 0.5)
    check("C5", "native DI-AUC above LSED", rq3["native"]["di_auc"] > rq3["lsed"]["di_auc"])
    check("C6", "LSED and rebuild: zero text residue, native leaks",
          rq3["lsed"]["recovered_after_delete"] == 0 == rq3["full_rebuild"]["recovered_after_delete"]
          and rq3["native"]["recovered_after_delete"] > 0)

    sw = load("ablations.json")["partition_sweep"]
    S = sorted(sw, key=int)
    dl = [sw[s]["del_lat_s"] for s in S]; p99 = [sw[s]["p99_x_native"] for s in S]
    check("C7", "more partitions -> cheaper deletion (first vs last S)", dl[-1] < dl[0])
    check("C7", "more partitions -> higher tail latency (first vs last S)", p99[-1] > p99[0])

    width = max(len(c[1]) for c in checks)
    for cid, desc, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {cid}  {desc:<{width}}")
    n_fail = sum(not ok for *_, ok in checks)
    print(f"\n{len(checks) - n_fail}/{len(checks)} checks passed")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
