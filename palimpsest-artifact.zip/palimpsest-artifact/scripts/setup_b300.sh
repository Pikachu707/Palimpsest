#!/usr/bin/env bash
# One-shot setup of a FRESH B300 (sm_103) server for the LLM-backend sweep.
# Pins the stack the paper's final runs used: vLLM 0.30.0 / torch 2.13.0+cu132.
# Stops at the first failed check.
#
#   bash scripts/setup_b300.sh            # install + verify + download all weights + tests
#   SKIP_DOWNLOAD=1 bash scripts/setup_b300.sh
set -euo pipefail
cd "$(dirname "$0")/.."
step() { echo; echo "=== $* ==="; }
die()  { echo "SETUP FAILED: $*" >&2; exit 1; }

step "1/6 hardware"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader || die "no GPU visible"
avail=$(df -BG --output=avail /workspace | tail -1 | tr -dc 0-9)
echo "free on /workspace: ${avail}G"; [ "$avail" -ge 250 ] || die "need >= 250G free on /workspace (weights ~200G)"

step "2/6 python stack (pinned to the paper's final B300 runs)"
python -m pip install -q -U pip uv
uv pip install --system "vllm==0.30.0" --torch-backend=auto
uv pip install --system -r requirements.txt openai sentence-transformers modelscope

step "3/6 verify versions and GPU architecture"
python - <<'PY'
import torch, vllm, sys
cap = torch.cuda.get_device_capability()
print("vllm", vllm.__version__, "| torch", torch.__version__, "| cuda", torch.version.cuda, "| capability", cap)
ok = vllm.__version__.startswith("0.30.0") and torch.__version__.startswith("2.13.0") and cap == (10, 3)
if not ok:
    sys.exit("version/architecture differs from the paper's final runs (vllm 0.30.0, torch 2.13.0, cap (10,3))")
PY

step "4/6 weights (embedder, baseline LLM, sweep backends)"
if [ "${SKIP_DOWNLOAD:-0}" != "1" ]; then
python - <<'PY'
import yaml
from pathlib import Path
from modelscope import snapshot_download
need = [("BAAI/bge-large-en-v1.5", "/workspace/models/bge-large-en-v1.5")]
need += [(b["modelscope"], b["path"]) for b in yaml.safe_load(open("configs/backends.yaml"))["backends"]]
seen = set()
for mid, path in need:
    if path in seen: continue
    seen.add(path)
    if (Path(path) / "config.json").exists():
        print("present:", path); continue
    print(">>> downloading", mid, "->", path)
    try:
        snapshot_download(mid, local_dir=path)
    except Exception as e:
        raise SystemExit(f"download failed for {mid}: {e}\n"
                         "check the ID on modelscope.cn (some models need the license accepted) "
                         "and edit configs/backends.yaml")
PY
fi
du -sh /workspace/models/* || true

step "5/6 baseline results (results/final, results/final_onesent)"
if [ -f results/final/rq2_recovery_zombie.json ] && [ -f results/final_onesent/rq2_recovery_zombie.json ]; then
  echo "present"
elif [ -f /workspace/baseline_results.tgz ]; then
  tar xzf /workspace/baseline_results.tgz -C . && echo "restored from /workspace/baseline_results.tgz"
else
  die "upload baseline_results.tgz to /workspace first (the paper's original Qwen2.5-7B runs)"
fi

step "6/6 tests"
python -m pytest tests/ -q
echo; echo "SETUP OK. Next: python scripts/run_backends.py --dry-run"
