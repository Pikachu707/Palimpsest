#!/usr/bin/env bash
# Final experiment runs, split into independent groups that can run IN PARALLEL
# (one tmux window each). Every index build is single-threaded, so groups do not
# compete for a core; each group loads its own embedding model (~1.5 GB GPU).
#
#   bash scripts/final_runs.sh llm       # RQ1, RQ2, RQ3, ablations, timing, one-sentence ablation
#   bash scripts/final_runs.sh ivf8      # headline DI: IVF-PQ, nprobe=8, never-null
#   bash scripts/final_runs.sh ivf1      # DI: IVF-PQ, nprobe=1, never-null
#   bash scripts/final_runs.sh controls  # decoy nulls (nprobe 1 and 8) + HNSW negative control
set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
cd "$(dirname "$0")/.."
C="--config configs/local.yaml"
mkdir -p logs
run() { local name=$1; shift; echo ">>> $name  ($(date))"; python run.py "$@" 2>&1 | tee "logs/$name.log"; }

case "${1:-}" in
  llm)
    for s in rq1 rq2 rq3 ablations timing; do run "final_$s" $s $C --set run_name=final; done
    run final_onesent rq2 $C --set graph.render_style=one_sentence --set run_name=final_onesent
    ;;
  ivf8)
    run di_ivf_np8 di $C --system faiss-ivfpq --set index.ivf_nprobe=8 --set run_name=di_ivf_np8
    ;;
  ivf1)
    run di_ivf_np1 di $C --system faiss-ivfpq --set index.ivf_nprobe=1 --set run_name=di_ivf_np1
    ;;
  controls)
    for np in 1 8; do
      run di_ivf_np${np}_decoy di $C --system faiss-ivfpq --set index.ivf_nprobe=$np \
          --set attack.di_null=decoy --set attack.di_test_subjects=48 --set run_name=di_ivf_np${np}_decoy
    done
    run di_hnsw_approx di $C --system hnswlib --set index.hnsw_M=8 --set index.hnsw_ef=16 \
        --set attack.di_test_subjects=48 --set run_name=di_hnsw_approx
    ;;
  *) echo "usage: $0 {llm|ivf8|ivf1|controls}"; exit 1 ;;
esac
echo ">>> group ${1} done ($(date))"
