#!/usr/bin/env bash
# Start a local OpenAI-compatible vLLM server from LOCAL weights (no network).
# Request logging is off by default in current vLLM, so no logging flag is passed
# (older releases used --disable-log-requests, which newer ones reject).
set -euo pipefail
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
MODEL="${MODEL:-/workspace/models/Qwen2.5-7B-Instruct}"
PORT="${PORT:-8000}"
GPU_UTIL="${GPU_UTIL:-0.85}"
MAXLEN="${MAXLEN:-8192}"
echo "Starting vLLM: $MODEL on :$PORT (gpu_util=$GPU_UTIL, max_len=$MAXLEN)"
exec python -m vllm.entrypoints.openai.api_server \
  --model "$MODEL" \
  --port "$PORT" \
  --gpu-memory-utilization "$GPU_UTIL" \
  --max-model-len "$MAXLEN"
