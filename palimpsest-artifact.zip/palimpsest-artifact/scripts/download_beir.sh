#!/usr/bin/env bash
# Download a BEIR dataset to use as realistic background corpus.
# Usage: DATASET=scifact bash scripts/download_beir.sh
set -euo pipefail
DATASET="${DATASET:-scifact}"
ROOT="${ROOT:-data/beir}"
mkdir -p "$ROOT"
python - "$DATASET" "$ROOT" <<'PY'
import sys
from beir import util
dataset, root = sys.argv[1], sys.argv[2]
url = f"https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/{dataset}.zip"
path = util.download_and_unzip(url, root)
print("downloaded to", path)
PY
