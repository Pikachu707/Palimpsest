#!/usr/bin/env python3
"""Microsoft GraphRAG experiment on one GPU: start vLLM and the embedding server, smoke-test, run, stop.

    python scripts/run_graphrag.py --vllm-python /usr/bin/python3 --graphrag-python /workspace/venv-graphrag/bin/python

GraphRAG lives in its own virtualenv (it pins pandas/pyarrow versions that conflict with
the other experiments); the embedding server and every GraphRAG world run with that python.
"""
import argparse, importlib.util, json, os, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)


def port_free(port: int) -> bool:
    """True only if nothing listens on the port on ANY address (IPv4 or IPv6): 'localhost'
    may resolve to ::1, so a check on 127.0.0.1 alone can miss another service."""
    import socket
    for fam, addr in ((socket.AF_INET, "0.0.0.0"), (socket.AF_INET6, "::")):
        try:
            s = socket.socket(fam, socket.SOCK_STREAM)
        except OSError:                  # e.g. no IPv6 on this host: nothing can listen there
            continue
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if fam == socket.AF_INET6:
                s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
            s.bind((addr, port))
        except OSError:
            return False
        finally:
            s.close()
    return True


def preflight(env) -> None:
    """Call both endpoints exactly as the GraphRAG worlds will, before any indexing."""
    def post(url, body):
        req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status, json.load(r)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode(errors="ignore")[:300]
    st, body = post(env["PAL_EMB_BASE_URL"] + "/embeddings", {"input": ["ping"], "model": "bge"})
    dim = len(body["data"][0]["embedding"]) if st == 200 and isinstance(body, dict) else None
    if dim != 1024:
        sys.exit(f"embedding preflight failed at {env['PAL_EMB_BASE_URL']}/embeddings: HTTP {st}, dim {dim}, body {str(body)[:200]}\n"
                 f"Another service may be answering on that port; pick a free one with --emb-port.")
    st, body = post(env["PAL_LLM_BASE_URL"] + "/chat/completions",
                    {"model": env["PAL_LLM_MODEL"], "messages": [{"role": "user", "content": "Say OK."}], "max_tokens": 4})
    if st != 200:
        sys.exit(f"chat preflight failed at {env['PAL_LLM_BASE_URL']}/chat/completions: HTTP {st}, body {str(body)[:200]}")
    rb.log(f"preflight ok: embeddings (dim {dim}) and chat both answer from the expected servers")


def run(cmd, env, log):
    with open(log, "w") as f:
        p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=ROOT)
        for line in p.stdout:
            sys.stdout.write(line); f.write(line)
        return p.wait()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen7b"); ap.add_argument("--skip-smoke", action="store_true")
    ap.add_argument("--n-subjects", type=int, default=10); ap.add_argument("--parallel", type=int, default=4)
    ap.add_argument("--out", default="results/graphrag")
    ap.add_argument("--vllm-python", help="python that has vLLM, if different")
    ap.add_argument("--graphrag-python", default="/workspace/venv-graphrag/bin/python")
    ap.add_argument("--emb-port", type=int, default=8001)
    ap.add_argument("--max-model-len", type=int, default=32768)
    ap.add_argument("--world-timeout", type=int, default=2700)
    a = ap.parse_args()
    if a.vllm_python:
        os.environ["PAL_VLLM_PYTHON"] = a.vllm_python
    os.chdir(ROOT)
    cfg = yaml.safe_load(open("configs/backends.yaml")); cfg["max_model_len"] = a.max_model_len
    b = next(x for x in cfg["backends"] if x["tag"] == a.model)
    emb = yaml.safe_load(open(cfg["base_config"]))["emb"]["model"]
    for path in (b["path"], emb):
        ok, why = rb.weights_complete(Path(path))
        if not ok:
            sys.exit(f"model files incomplete at {path}: {why}")
    chk = subprocess.run([a.graphrag_python, "-c", "import graphrag, importlib.metadata as m; print(m.version('graphrag'))"],
                         capture_output=True, text=True)
    if chk.returncode:
        sys.exit(f"GraphRAG not importable with {a.graphrag_python}: {chk.stderr[-300:]}")
    rb.log(f"GraphRAG {chk.stdout.strip()} at {a.graphrag_python}")
    if not port_free(a.emb_port):
        sys.exit(f"port {a.emb_port} is already in use on some address (check: ss -ltnp | grep :{a.emb_port}); "
                 f"stop that service or pick another port with --emb-port")
    Path("logs").mkdir(exist_ok=True)
    env = dict(os.environ, PAL_LLM_BASE_URL=f"http://127.0.0.1:{cfg['port']}/v1", PAL_LLM_MODEL=b["path"],
               PAL_EMB_MODEL=emb, PAL_EMB_BASE_URL=f"http://127.0.0.1:{a.emb_port}/v1", PAL_GRAPHRAG_PYTHON=a.graphrag_python,
               PYTHONPATH=str(ROOT), HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    proc = rb.start_server(b, cfg, Path("logs"), dry=False)
    emb_log = open("logs/embed_server.log", "w")
    eproc = subprocess.Popen([a.graphrag_python, "-m", "palimpsest.real.embed_server", "--port", str(a.emb_port)],
                             env=env, stdout=emb_log, stderr=subprocess.STDOUT, cwd=ROOT, start_new_session=True)
    try:
        for _ in range(60):
            if eproc.poll() is not None:
                sys.exit("embedding server exited; see logs/embed_server.log")
            if rb.served_models(a.emb_port) is not None:
                break
            time.sleep(5)
        else:
            sys.exit("embedding server did not start")
        rb.log("embedding server ready")
        preflight(env)
        base = [sys.executable, "-m", "palimpsest.experiments.graphrag_exp", "--parallel", str(a.parallel),
                "--world-timeout", str(a.world_timeout)]
        if not a.skip_smoke:
            rb.log("smoke test (2 subjects)")
            if run(base + ["--quick", "--out", a.out], env, "logs/graphrag_smoke.log"):
                sys.exit("smoke test failed; see logs/graphrag_smoke.log")
            s = json.load(open(f"{a.out}_quick/graphrag.json"))["summary"]
            if s.get("invalid_worlds"):
                sys.exit(f"smoke test: invalid worlds {s['invalid_worlds'][:2]}")
            if not any((v.get("live") or 0) > 0 for v in s["recovery"].values()):
                sys.exit("smoke test: queries recovered nothing even while the data was live; retrieval is broken")
            rb.log("smoke test passed")
        if run(base + ["--n-subjects", str(a.n_subjects), "--out", a.out], env, "logs/graphrag_full.log"):
            sys.exit("full run failed; see logs/graphrag_full.log")
    finally:
        import signal
        try:
            os.killpg(eproc.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        rb.stop_server(proc, cfg["port"])
    rb.log(f"done: {a.out}/graphrag.json, {a.out}/meta.json")


if __name__ == "__main__":
    main()
