#!/usr/bin/env python3
"""Verify every model the experiments use: all shards present, non-empty, and of
the exact size their safetensors header implies (catches truncated downloads).

    python scripts/check_weights.py                 # all backends + the embedder
    python scripts/check_weights.py --only qwen72b
"""
import argparse, importlib.util, sys
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)

ap = argparse.ArgumentParser()
ap.add_argument("--backends", default=str(ROOT / "configs" / "backends.yaml"))
ap.add_argument("--only", nargs="*")
a = ap.parse_args()
cfg = yaml.safe_load(open(a.backends))
targets = [(b["tag"], b["path"]) for b in cfg["backends"]]
sys.path.insert(0, str(ROOT))
from palimpsest.config import load_config      # same loader the experiments use
emb = load_config(ROOT / cfg["base_config"]).emb.model
targets.append(("embedder", emb))
ok_all = True
for tag, path in targets:
    if a.only and tag not in a.only:
        continue
    ok, why = rb.weights_complete(Path(path))
    ok_all &= ok
    print(f"{'OK ' if ok else 'BAD'}  {tag:10s} {path}  ({why})")
sys.exit(0 if ok_all else 1)
