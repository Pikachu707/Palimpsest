#!/usr/bin/env python3
"""Palimpsest experiment CLI.

  python run.py --config configs/smoke.yaml all     # CPU, offline, ~minutes
  python run.py --config configs/local.yaml all     # full run, local weights

Stages (paper artifact in parentheses):
  rq1        residue localization                 (Fig. 4, Sec. 7.2)
  di         deletion inference sweep over k      (Fig. 5a-b, Sec. 7.3)
  rq2        residue recovery + zombie poisoning  (Fig. 5c-d, Secs. 7.4-7.5)
  rq3        LSED vs native vs full rebuild       (Table 3, Sec. 7.6)
  ablations  partition-count and slice sweeps     (Fig. 6, Sec. 7.7)
  timing     timing channel with/without padding  (Sec. 7.6, "Timing Channel")
  report     LaTeX snippets for the tables
  export     measured results -> figure-data JSON
  figures    render the paper figures from that JSON
"""
import argparse
import subprocess
import sys
from pathlib import Path

from palimpsest.config import load_config
from palimpsest.experiments import (rq1_residue, rq2_deletion_inference,
                                    rq2_recovery_zombie, rq3_lsed, ablations)
from palimpsest.report import make_report
from palimpsest.report.export_figure_data import export

STAGES = ["rq1", "di", "rq2", "rq3", "ablations", "timing", "report", "export", "figures"]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("stage", choices=["all"] + STAGES)
    ap.add_argument("--config", default=None)
    ap.add_argument("--system", default="hnswlib",
                    help="DI target: hnswlib | hnswlib-rebuild | faiss-ivfpq | lsed")
    ap.add_argument("--no-rq3-di", action="store_true",
                    help="skip the per-regime DI comparison inside rq3 (saves time)")
    ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                    help="override a config value, e.g. --set index.hnsw_ef=16 "
                         "--set run_name=ef16 (repeatable)")
    ap.add_argument("--measured", action="store_true",
                    help="render figures without the PLACEHOLDER watermark "
                         "(only for real runs you intend to put in the paper)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    for kv in args.set:
        import yaml
        key, _, val = kv.partition("=")
        *path, leaf = key.split(".")
        obj = cfg
        for part in path:
            obj = getattr(obj, part)
        if not hasattr(obj, leaf):
            sys.exit(f"--set: unknown config key {key!r}")
        v = yaml.safe_load(val)
        cur = getattr(obj, leaf)
        setattr(obj, leaf, tuple(v) if isinstance(cur, tuple) and isinstance(v, list) else v)
    results_dir = Path(cfg.out_dir) / cfg.run_name
    results_dir.mkdir(parents=True, exist_ok=True)
    cfg.dump(results_dir / "config.used.yaml")
    run = lambda s: args.stage in ("all", s)

    if run("rq1"):
        rq1_residue.run(cfg)
    if run("di"):
        rq2_deletion_inference.run(cfg, system=args.system)
    if run("rq2"):
        rq2_recovery_zombie.run(cfg)
    if run("rq3"):
        rq3_lsed.run(cfg, with_di=not args.no_rq3_di)
    if run("ablations"):
        ablations.run_ablations(cfg)
    if run("timing"):
        ablations.run_timing_channel(cfg)
    if run("report"):
        make_report.build_all(str(results_dir), out_dir=str(results_dir))

    fig_json = results_dir / "figure_data.json"
    if run("export"):
        import json
        fig_json.write_text(json.dumps(export(str(results_dir), di_system=args.system), indent=2))
        print(f"wrote {fig_json}")
    if run("figures"):
        if not fig_json.exists():
            sys.exit(f"{fig_json} missing; run the 'export' stage first")
        here = Path(__file__).resolve().parent
        cmd = [sys.executable, str(here / "paper_figures" / "make_figures.py"),
               "--data", str(fig_json.resolve()),
               "--outdir", str((results_dir / "figures").resolve())]
        if args.measured:
            cmd.append("--measured")
        subprocess.run(cmd, check=True, cwd=here / "paper_figures")


if __name__ == "__main__":
    main()
