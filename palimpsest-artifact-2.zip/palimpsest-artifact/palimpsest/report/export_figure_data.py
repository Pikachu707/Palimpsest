"""Convert measured results (results/<run>/*.json) into the figure-data schema
read by paper_figures/make_figures.py (quick-look figures of a run).

Only measured quantities are exported. Anything the run did not measure is
`null` (rendered as an absent bar / '--' cell), never filled in. Systems keep
their real names, so a controlled pipeline is labeled 'MiniGraphRAG', not
'GraphRAG'.

    python -m palimpsest.report.export_figure_data results/local_full \
        -o paper_figures/data/measured.json
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import numpy as np

# code system id -> (display name, category, has semantic tier)
RQ1_NAMES = {
    "faiss-hnsw":  ("FAISS-HNSW",   "ANN",      False),
    "faiss-ivfpq": ("FAISS-IVFPQ",  "ANN",      False),
    "hnswlib":     ("hnswlib",      "ANN",      False),
    "graphrag":    ("MiniGraphRAG", "GraphRAG", True),
    "memory":      ("MiniMemory",   "Memory",   True),
}
MECHS = ["M1 merged desc.", "M2 comm. reports", "M3 cached LLM resp.",
         "M4 consol. memory", "M5 cached answers"]
# Mechanisms each controlled pipeline implements; others are null (N/A).
APPLICABLE = {"graphrag": {"M1", "M3"}, "memory": {"M4"}}
RQ2_SYSTEMS = [("graphrag", "MiniGraphRAG"), ("memory", "MiniMemory")]


def _load(d: Path, name: str):
    f = d / name
    return json.loads(f.read_text()) if f.exists() else None


def _roc_points(scores, labels):
    from sklearn.metrics import roc_curve
    labels = np.asarray(labels)
    if labels.min() == labels.max():
        return None, None
    fpr, tpr, _ = roc_curve(labels, scores)
    return fpr.tolist(), tpr.tolist()


def export(results_dir: str, di_system: str = "hnswlib",
           recovery_metric: str = "client") -> dict:
    d = Path(results_dir)
    out: dict = {"_comment": f"MEASURED from {d} (recovery metric: {recovery_metric}). "
                             "null = not measured / not applicable."}

    rq1 = _load(d, "rq1_residue.json")
    if rq1:
        comps = []
        for sid, r in rq1["systems"].items():
            name, cat, sem = RQ1_NAMES.get(sid, (sid, "Other", True))
            comps.append({"name": name, "cat": cat,
                          "vals": [r["tier1_frac"], r["tier2_frac"],
                                   r["tier3_frac"] if sem else None]})
        out["rq1"] = {"tiers": ["I: copy", "II: structural", "III: semantic"],
                      "components": comps}

    di = _load(d, f"rq2_di_{di_system}.json")
    if di:
        roc = []
        for k, cur in sorted(di["curves"].items(), key=lambda kv: int(kv[0])):
            fpr, tpr = _roc_points(cur["scores"], cur["labels"])
            roc.append({"k": int(k), "auc": cur["auc"], "tpr1": cur["tpr_at_1pct"],
                        "fpr": fpr, "tpr": tpr})
        out["di"] = {"system": di_system, "roc": roc}

    rq2 = _load(d, "rq2_recovery_zombie.json")
    if rq2:
        key = "per_mechanism_client" if recovery_metric == "client" else "per_mechanism_at_rest"
        rec = []
        for m in MECHS:
            mid = m.split()[0]
            row = []
            for sid, _ in RQ2_SYSTEMS:
                r = rq2["residue_recovery"].get(f"{sid}:naive")
                if r is None or mid not in APPLICABLE.get(sid, set()):
                    row.append(None)
                else:
                    row.append(float(r.get(key, {}).get(mid, 0.0)))
            rec.append(row)
        z = rq2["zombie"]
        zget = lambda field: [z.get(f"{sid}:naive", {}).get(field) for sid, _ in RQ2_SYSTEMS]
        out["rq2"] = {"systems": [n for _, n in RQ2_SYSTEMS], "mechanisms": MECHS,
                      "recovery": rec,
                      "zombie": {"before": zget("before"), "after": zget("after"),
                                 "counterfactual": zget("counterfactual")}}

    rq3 = _load(d, "rq3_lsed.json"); abl = _load(d, "ablations.json")
    if rq3 or abl:
        r3: dict = {}
        if rq3:
            nat_p99 = rq3["native"]["query_p99_ms"]
            labels = {"native": "Native", "full_rebuild": "Full rebuild", "lsed": "LSED"}
            r3["points"] = [{"label": labels[k],
                             "del_s": rq3[k]["deletion_latency_s"],
                             "adv": rq3[k].get("di_advantage"),
                             "p99x": rq3[k]["query_p99_ms"] / max(nat_p99, 1e-9)}
                            for k in ("native", "full_rebuild", "lsed") if k in rq3]
        if abl:
            r3["s_sweep"] = [{"S": int(S), "del_s": v["del_lat_s"], "p99x": v["p99_x_native"]}
                             for S, v in sorted(abl["partition_sweep"].items(),
                                                key=lambda kv: int(kv[0]))]
        out["rq3"] = r3

    timing = _load(d, "timing_channel.json")
    if timing:
        out["timing"] = timing
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results_dir")
    ap.add_argument("-o", "--out", default="paper_figures/data/measured.json")
    ap.add_argument("--di-system", default="hnswlib")
    ap.add_argument("--recovery-metric", choices=["client", "at_rest"], default="client")
    a = ap.parse_args()
    data = export(a.results_dir, a.di_system, a.recovery_metric)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(data, indent=2))
    print(f"wrote {a.out}  (sections: {', '.join(k for k in data if not k.startswith('_'))})")


if __name__ == "__main__":
    main()
