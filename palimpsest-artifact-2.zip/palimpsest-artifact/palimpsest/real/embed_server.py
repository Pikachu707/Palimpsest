"""Minimal OpenAI-compatible /v1/embeddings server (bge-large via sentence-transformers).

GraphRAG calls embeddings through an OpenAI-style API; vLLM serves the chat model, and
this serves the embedding model the other experiments use, so all systems share it.

    python -m palimpsest.real.embed_server --port 8001
"""
import argparse, json, threading, http.server
from palimpsest.real import common

_LOCK = threading.Lock()


def make_handler(emb):
    class H(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            inp = body.get("input", [])
            texts = [inp] if isinstance(inp, str) else list(inp)
            with _LOCK:                                     # sentence-transformers is not re-entrant
                vecs = emb.encode(texts) if texts else []
            out = {"object": "list", "model": body.get("model", "bge"),
                   "data": [{"object": "embedding", "index": i, "embedding": [float(x) for x in v]} for i, v in enumerate(vecs)],
                   "usage": {"prompt_tokens": 0, "total_tokens": 0}}
            b = json.dumps(out).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

        def do_GET(self):                                   # health check
            b = json.dumps({"data": [{"id": "bge"}]}).encode()
            self.send_response(200); self.end_headers(); self.wfile.write(b)

        def log_message(self, *a):
            pass
    return H


def serve(port: int):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), make_handler(common.Embedder()))
    return srv


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--port", type=int, default=8001)
    serve(ap.parse_args().port).serve_forever()


if __name__ == "__main__":
    main()
