"""Real-system validation: LightRAG and Mem0 driven through their own deletion APIs.

Each "world" (a deletion world or a counterfactual world for one subject) runs in
its own subprocess (`python -m palimpsest.real.<system>_world`), because both
libraries keep process-global state; separate processes rule out cross-world
leakage. Residue is measured with canary values, which the counterfactual world
never sees, so any occurrence after deletion is residue by construction.
"""
