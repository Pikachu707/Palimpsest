"""One LightRAG world, driven through LightRAG's own API, in its own process.

    python -m palimpsest.real.lightrag_world --dir W --ops ops.json --out out.json [--no-extract-cache]

ops.json is a list of operations executed in order:
  {"op": "insert", "docs": [{"id": ..., "text": ...}]}
  {"op": "delete", "ids": [...], "delete_llm_cache": bool}
  {"op": "query", "tag": ..., "qs": [...], "mode": "mix", "context": bool}
  {"op": "scan", "tag": ..., "values": [...]}
  {"op": "status", "tag": ..., "ids": [...]}      # per-document processing status
"""
import argparse, asyncio, json, sys
from pathlib import Path
import numpy as np
from palimpsest.real import common


async def _llm(prompt, system_prompt=None, history_messages=None, **kw):
    from openai import AsyncOpenAI
    client = _llm.client = getattr(_llm, "client", None) or AsyncOpenAI(base_url=common.LLM_BASE_URL, api_key="EMPTY")
    msgs = ([{"role": "system", "content": system_prompt}] if system_prompt else []) + list(history_messages or []) \
        + [{"role": "user", "content": prompt}]
    r = await client.chat.completions.create(model=common.LLM_MODEL, messages=msgs, temperature=0.0,
                                             max_tokens=kw.get("max_tokens", 1024), seed=0)
    return r.choices[0].message.content or ""


async def make_rag(workdir: Path, extract_cache: bool):
    from lightrag import LightRAG
    from lightrag.utils import EmbeddingFunc
    emb = common.Embedder()

    async def embed(texts, **_):
        return np.asarray(emb.encode(texts), dtype=np.float32)
    rag = LightRAG(working_dir=str(workdir), llm_model_func=_llm,
                   embedding_func=EmbeddingFunc(embedding_dim=common.EMB_DIM, max_token_size=512, func=embed),
                   tokenizer=common.lightrag_tokenizer(),
                   enable_llm_cache=True, enable_llm_cache_for_entity_extract=extract_cache,
                   llm_model_max_async=8, max_parallel_insert=1)
    await rag.initialize_storages()
    try:
        from lightrag.kg.shared_storage import initialize_pipeline_status
        await initialize_pipeline_status()
    except Exception:
        pass
    return rag


async def main_async(a):
    from lightrag import QueryParam
    ops = json.load(open(a.ops))
    rag = await make_rag(Path(a.dir), not a.no_extract_cache)
    out = {"queries": {}, "scans": {}, "deletions": []}
    try:
        for op in ops:
            if op["op"] == "insert":
                await rag.ainsert([d["text"] for d in op["docs"]], ids=[d["id"] for d in op["docs"]])
            elif op["op"] == "delete":
                for did in op["ids"]:
                    r = await rag.adelete_by_doc_id(did, delete_llm_cache=bool(op.get("delete_llm_cache")))
                    out["deletions"].append({"id": did, "status": getattr(r, "status", str(r))})
            elif op["op"] == "query":
                res = []
                for q in op["qs"]:
                    p = QueryParam(mode=op.get("mode", "mix"), only_need_context=bool(op.get("context")),
                                   enable_rerank=False)
                    res.append(str(await rag.aquery(q, param=p)))
                out["queries"][op["tag"]] = res
            elif op["op"] == "status":
                st = {}
                for did in op["ids"]:
                    rec = await rag.doc_status.get_by_id(did)
                    st[did] = (rec or {}).get("status", "absent") if isinstance(rec, dict) else str(getattr(rec, "status", rec))
                out.setdefault("status", {})[op["tag"]] = st
            elif op["op"] == "scan":
                await rag.finalize_storages()                   # flush to disk before a logical scan
                out["scans"][op["tag"]] = common.scan_json_tree(Path(a.dir), op["values"])
                rag = await make_rag(Path(a.dir), not a.no_extract_cache)
    finally:
        try:
            await rag.finalize_storages()
        except Exception:
            pass
    json.dump(out, open(a.out, "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True); ap.add_argument("--ops", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--no-extract-cache", action="store_true")
    asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    sys.exit(main())
