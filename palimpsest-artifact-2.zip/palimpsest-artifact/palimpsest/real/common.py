"""Shared helpers for the real-system worlds: LLM endpoint, embeddings, tokenizer, canary scans."""
import hashlib, json, os
from pathlib import Path
import numpy as np

LLM_BASE_URL = os.environ.get("PAL_LLM_BASE_URL", "http://localhost:8000/v1")
LLM_MODEL = os.environ.get("PAL_LLM_MODEL", "/workspace/models/Qwen2.5-7B-Instruct")
EMB_MODEL = os.environ.get("PAL_EMB_MODEL", "/workspace/models/bge-large-en-v1.5")
FAKE_EMBED = os.environ.get("PAL_FAKE_EMBED") == "1"     # tests only: no model download
# OpenAI-compatible embedding endpoint (palimpsest/real/embed_server.py, bge-large) for the
# systems that only accept an embedding API: GraphRAG, Graphiti, Cognee, Letta, A-MEM.
EMB_BASE_URL = os.environ.get("PAL_EMB_BASE_URL", "http://localhost:8001/v1")
EMB_DIM = 1024


class Embedder:
    """bge-large via sentence-transformers, or a deterministic hash embedding in tests."""
    def __init__(self):
        self.model = None
        if not FAKE_EMBED:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(EMB_MODEL, device=os.environ.get("PAL_EMB_DEVICE", "cuda"))

    def encode(self, texts):
        if self.model is not None:
            return np.asarray(self.model.encode(list(texts), normalize_embeddings=True, batch_size=64))
        out = []
        for t in texts:
            h = hashlib.sha256(t.encode()).digest()
            v = np.frombuffer((h * (EMB_DIM // len(h) + 1))[:EMB_DIM], dtype=np.uint8).astype(np.float32)
            v = v - v.mean(); out.append(v / (np.linalg.norm(v) + 1e-9))
        return np.stack(out)


def find_values(text: str, values) -> list:
    """Canary values that occur in `text` (case-insensitive)."""
    low = (text or "").lower()
    return sorted({v for v in values if v.lower() in low})


def scan_json_tree(root: Path, values) -> dict:
    """Logical at-rest scan: parse every JSON/GraphML store under `root` and report,
    per store file, which canary values its CONTENT holds (not raw free-page bytes)."""
    hits = {}
    for f in sorted(Path(root).rglob("*")):
        if not f.is_file() or f.suffix not in (".json", ".graphml"):
            continue
        try:
            text = json.dumps(json.load(open(f))) if f.suffix == ".json" else f.read_text(errors="ignore")
        except Exception:
            continue
        found = find_values(text, values)
        if found:
            hits[str(f.relative_to(root))] = found
    return hits


class _ByteTok:
    """Reversible byte-level tokenizer for tests (no download, thread-safe)."""
    def encode(self, text):
        return list(text.encode("utf-8"))

    def decode(self, ids):
        return bytes(ids).decode("utf-8", errors="ignore")


class _ThreadLocalHFTok:
    """The LLM's own tokenizer, loaded from the local model directory (no network).
    LightRAG calls encode/decode from several worker threads; one instance per
    thread makes that safe without a lock."""
    def __init__(self, path):
        import threading
        self.path, self.local = path, threading.local()

    def _tok(self):
        if not hasattr(self.local, "tok"):
            from transformers import AutoTokenizer
            self.local.tok = AutoTokenizer.from_pretrained(self.path, local_files_only=True)
        return self.local.tok

    def __deepcopy__(self, memo):
        # LightRAG deep-copies its configuration; an injected tokenizer must survive
        # copy.deepcopy, and LightRAG documents returning self as the way to do it.
        return self

    def __reduce__(self):
        # pickling (e.g. across processes) rebuilds a fresh per-thread cache
        return (_ThreadLocalHFTok, (self.path,))

    def encode(self, text):
        return self._tok().encode(text, add_special_tokens=False)

    def decode(self, ids):
        return self._tok().decode(ids)


def lightrag_tokenizer():
    """LightRAG otherwise downloads tiktoken's BPE file at start-up, which fails
    offline and counts tokens in OpenAI units rather than the served model's."""
    from lightrag.utils import Tokenizer
    if FAKE_EMBED:
        return Tokenizer("bytes", _ByteTok())
    return Tokenizer(LLM_MODEL, _ThreadLocalHFTok(LLM_MODEL))
