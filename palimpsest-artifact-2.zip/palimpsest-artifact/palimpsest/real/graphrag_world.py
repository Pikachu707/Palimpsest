"""One Microsoft GraphRAG world, driven through GraphRAG's own Python API, in its own process.

    python -m palimpsest.real.graphrag_world --dir W --ops ops.json --out out.json

Operations, executed in order:
  {"op": "index",  "docs": [{"id": ..., "text": ...}]}   # full (re)index of exactly these documents
  {"op": "update", "docs": [{"id": ..., "text": ...}]}   # incremental update to exactly these documents
  {"op": "query",  "tag": ..., "qs": [...]}              # local search: answer and retrieved context
  {"op": "scan",   "tag": ..., "values": [...]}          # logical at-rest scan of every GraphRAG store
  {"op": "status", "tag": ..., "ids": [...]}             # which documents the index currently holds
GraphRAG matches documents across runs by title, so each document's title is its id.
"""
import argparse, asyncio, json, os, shutil, subprocess, sys
from pathlib import Path
from palimpsest.real import common

EMB_BASE_URL = os.environ.get("PAL_EMB_BASE_URL", "http://localhost:8001/v1")


def _test_mode_patches():
    """Tests only: tiktoken's vocabulary cannot be downloaded offline, so use a
    reversible byte-level encoding under the same name. Never active in real runs."""
    if not common.FAKE_EMBED:
        return
    import tiktoken

    class _Enc:
        name = "o200k_base"
        def encode(self, text, **_): return list(text.encode("utf-8"))
        def decode(self, ids, **_): return bytes(ids).decode("utf-8", errors="ignore")
        def encode_batch(self, texts, **_): return [self.encode(t) for t in texts]
        def decode_batch(self, batch, **_): return [self.decode(b) for b in batch]
        @property
        def n_vocab(self): return 256
    tiktoken.get_encoding = lambda name: _Enc()
    tiktoken.encoding_for_model = lambda name: _Enc()


SETTINGS = """completion_models:
  default_completion_model:
    model_provider: openai
    model: "{llm}"
    api_base: "{llm_base}"
    api_key: EMPTY
    call_args:
      temperature: 0.0
      seed: 0
      max_tokens: 4096          # bound a runaway generation (GraphRAG sets no cap by default)
      timeout: 300              # a stuck connection fails instead of blocking the world
    retry:
      type: exponential_backoff
      max_retries: 2            # under greedy decoding a retry repeats the same output
  report_completion_model:      # community reports only: structured JSON over possibly repetitive input
    model_provider: openai
    model: "{llm}"
    api_base: "{llm_base}"
    api_key: EMPTY
    call_args:
      temperature: 0.0
      seed: 0
      max_tokens: 4096
      timeout: 300
      frequency_penalty: 0.3    # keeps a report from looping on repeated findings
    retry:
      type: exponential_backoff
      max_retries: 2
embedding_models:
  default_embedding_model:
    model_provider: openai
    model: bge
    api_base: "{emb_base}"
    api_key: EMPTY
    call_args:
      timeout: 120
    retry:
      type: exponential_backoff
      max_retries: 3
input:
  type: text
chunking:
  type: tokens
  size: 1200
  overlap: 100
  encoding_model: o200k_base
input_storage:
  type: file
  base_dir: "input"
output_storage:
  type: file
  base_dir: "output"
update_output_storage:
  type: file
  base_dir: "update_output"
reporting:
  type: file
  base_dir: "logs"
cache:
  type: json
  storage:
    type: file
    base_dir: "cache"
vector_store:
  type: lancedb
  db_uri: output/lancedb
  vector_size: 1024           # bge-large-en-v1.5; GraphRAG's default (3072) is OpenAI's model
embed_text:
  embedding_model_id: default_embedding_model
extract_graph:
  completion_model_id: default_completion_model
  prompt: "prompts/extract_graph.txt"
  entity_types: [organization,person,geo,event]
  max_gleanings: 1
summarize_descriptions:
  completion_model_id: default_completion_model
  prompt: "prompts/summarize_descriptions.txt"
  max_length: 500
cluster_graph:
  max_cluster_size: 10
extract_claims:
  enabled: false
  completion_model_id: default_completion_model
  prompt: "prompts/extract_claims.txt"
community_reports:
  completion_model_id: report_completion_model
  graph_prompt: "prompts/community_report_graph.txt"
  text_prompt: "prompts/community_report_text.txt"
  max_length: 2000
  max_input_length: 8000
local_search:
  completion_model_id: default_completion_model
  embedding_model_id: default_embedding_model
  prompt: "prompts/local_search_system_prompt.txt"
global_search:
  completion_model_id: default_completion_model
  map_prompt: "prompts/global_search_map_system_prompt.txt"
  reduce_prompt: "prompts/global_search_reduce_system_prompt.txt"
  knowledge_prompt: "prompts/global_search_knowledge_system_prompt.txt"
drift_search:
  completion_model_id: default_completion_model
  embedding_model_id: default_embedding_model
  prompt: "prompts/drift_search_system_prompt.txt"
  reduce_prompt: "prompts/drift_search_reduce_prompt.txt"
basic_search:
  completion_model_id: default_completion_model
  embedding_model_id: default_embedding_model
  prompt: "prompts/basic_search_system_prompt.txt"
"""


def ensure_project(root: Path):
    """Create settings.yaml (pointing at the local vLLM and embedding servers) and
    GraphRAG's own default prompts, taken from `graphrag init`."""
    root.mkdir(parents=True, exist_ok=True)
    if not (root / "prompts").exists():
        tmp = root / "_init"
        subprocess.run([sys.executable, "-m", "graphrag", "init", "--root", str(tmp), "--model", "m", "--embedding", "e", "--force"],
                       stdin=subprocess.DEVNULL, capture_output=True, timeout=300, check=True)
        shutil.copytree(tmp / "prompts", root / "prompts"); shutil.rmtree(tmp)
    (root / "settings.yaml").write_text(SETTINGS.format(llm=common.LLM_MODEL, llm_base=common.LLM_BASE_URL, emb_base=EMB_BASE_URL))


def _docs_df(docs):
    """Documents as GraphRAG's own file loader produces them, including the sequential
    human_readable_id that incremental updates use to number new rows (passing documents
    directly to build_index does not add it, and the update merge then fails)."""
    import pandas as pd
    df = pd.DataFrame([{"id": d["id"], "title": d["id"], "text": d["text"], "creation_date": "2026-01-01", "raw_data": None}
                       for d in docs])
    df["human_readable_id"] = df.index
    return df


def _read(root: Path, name: str):
    import pandas as pd
    f = root / "output" / f"{name}.parquet"
    return pd.read_parquet(f) if f.exists() else None


def scan(root: Path, values) -> dict:
    """Logical at-rest scan: parsed rows of every output table, every LanceDB table,
    every cache entry, and the update-output store; reports which canaries each holds."""
    import pandas as pd
    hits = {}
    def add(store, text):
        found = common.find_values(text, values)
        if found:
            hits.setdefault(store, set()).update(found)
    for sub in ("output", "update_output"):
        for f in sorted((root / sub).rglob("*.parquet")) if (root / sub).exists() else []:
            add(f"{sub}/{f.relative_to(root / sub).as_posix()}", pd.read_parquet(f).to_json())
    db = root / "output" / "lancedb"
    if db.exists():
        import lancedb
        con = lancedb.connect(str(db))
        for t in con.table_names():
            df = con.open_table(t).to_pandas()
            add(f"lancedb/{t}", df.drop(columns=[c for c in df.columns if "vector" in c], errors="ignore").to_json())
    for f in sorted((root / "cache").rglob("*")) if (root / "cache").exists() else []:
        if f.is_file():
            add("cache", f.read_text(errors="ignore"))
    return {k: sorted(v) for k, v in hits.items()}


async def main_async(a):
    _test_mode_patches()
    import graphrag.api as api
    from graphrag.config.load_config import load_config
    root = Path(a.dir).resolve(); ensure_project(root)
    os.chdir(root)                       # GraphRAG resolves relative storage paths; keep them inside this world
    a.out = str(Path(a.out).resolve()) if os.path.isabs(a.out) else a.out
    out = {"queries": {}, "contexts": {}, "scans": {}, "runs": [], "status": {}}
    for op in json.load(open(a.ops)):
        cfg = load_config(root)
        if op["op"] in ("index", "update"):
            res = await api.build_index(config=cfg, is_update_run=(op["op"] == "update"), input_documents=_docs_df(op["docs"]))
            errs = [str(r.error) for r in res if getattr(r, "error", None)]
            out["runs"].append({"op": op["op"], "n_docs": len(op["docs"]), "workflows": [r.workflow for r in res], "errors": errs})
            if errs:                       # a half-built index must never be scored
                json.dump(out, open(a.out, "w"), indent=1)
                sys.exit(f"GraphRAG {op['op']} failed: {errs[0][:300]}")
        elif op["op"] == "query":
            tabs = {n: _read(root, n) for n in ("entities", "communities", "community_reports", "text_units", "relationships")}
            answers, contexts = [], []
            for q in op["qs"]:
                resp, ctx = await api.local_search(config=cfg, entities=tabs["entities"], communities=tabs["communities"],
                                                   community_reports=tabs["community_reports"], text_units=tabs["text_units"],
                                                   relationships=tabs["relationships"], covariates=None, community_level=2,
                                                   response_type="Multiple Paragraphs", query=q)
                answers.append(str(resp))
                contexts.append(json.dumps({k: (v.to_json() if hasattr(v, "to_json") else str(v)) for k, v in ctx.items()})
                                if isinstance(ctx, dict) else str(ctx))
            out["queries"][op["tag"]] = answers; out["contexts"][op["tag"]] = contexts
        elif op["op"] == "scan":
            out["scans"][op["tag"]] = scan(root, op["values"])
        elif op["op"] == "status":
            d = _read(root, "documents")
            titles = set(d["title"]) if d is not None else set()
            out["status"][op["tag"]] = {i: ("present" if i in titles else "absent") for i in op["ids"]}
    json.dump(out, open(a.out, "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True); ap.add_argument("--ops", required=True); ap.add_argument("--out", required=True)
    args = ap.parse_args()
    args.out = str(Path(args.out).resolve()); args.ops = str(Path(args.ops).resolve())
    asyncio.run(main_async(args))


if __name__ == "__main__":
    sys.exit(main())
