#!/usr/bin/env python3
"""Generate all data figures for the Palimpsest paper as vector PDFs.

Consistent visual system across every figure:
  - single serif family (matches the paper body), small type
  - one ordered, colorblind-safe tier palette reused everywhere
  - no top/right spines, hairline axes, light dotted grid on value axis only
  - column-width and double-column canonical sizes

Usage:
  python make_figures.py --data data/xxx.json  # measured data (same schema)
All figures are watermarked PLACEHOLDER unless --measured is passed.
"""
import argparse, sys, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# ----------------------------------------------------------------------
# Style system
# ----------------------------------------------------------------------
# Tier palette (colorblind-safe, ordered light->dark by severity)
C_TIER1 = "#7DA7D9"   # copy      (blue)
C_TIER2 = "#E8A33D"   # structural(amber)
C_TIER3 = "#C4453C"   # semantic  (red)
C_INK   = "#1a1a1a"
C_MUTE  = "#8a8a8a"
C_GRID  = "#d7d7d7"
C_ACCENT= "#3b6ea5"
SERIES  = ["#9aa7b4", C_ACCENT, C_TIER3, "#4f9d69", "#8562a8"]  # generic ordered

def _install_font():
    for cand in ["TeX Gyre Termes", "Nimbus Roman", "Liberation Serif", "STIXTwoText", "DejaVu Serif"]:
        names = {f.name for f in fm.fontManager.ttflist}
        if cand in names:
            return cand
    return "serif"

FONT = _install_font()

def set_style():
    plt.rcParams.update({
        "font.family": FONT, "font.size": 8,
        "axes.titlesize": 8.5, "axes.labelsize": 8, "legend.fontsize": 6.8,
        "xtick.labelsize": 7, "ytick.labelsize": 7,
        "axes.linewidth": 0.6, "axes.edgecolor": "#4d4d4d",
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "xtick.major.size": 2.5, "ytick.major.size": 2.5,
        "xtick.color": "#4d4d4d", "ytick.color": "#4d4d4d",
        "axes.labelcolor": C_INK, "text.color": C_INK,
        "figure.dpi": 200, "savefig.dpi": 200, "savefig.bbox": "tight",
        "savefig.pad_inches": 0.015, "pdf.fonttype": 42, "ps.fonttype": 42,
        "legend.frameon": False, "legend.handlelength": 1.4,
        "legend.handletextpad": 0.5, "legend.columnspacing": 1.0,
        "lines.antialiased": True,
    })

COL = 3.40          # single column width (in)
DBL = 7.16          # double column width (in)

def _clean(ax, grid_axis="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.tick_params(length=2.5)
    if grid_axis:
        ax.grid(axis=grid_axis, color=C_GRID, lw=0.5, ls=(0, (1, 2)), zorder=0)
        ax.set_axisbelow(True)

def _watermark(fig, measured):
    if measured:
        return
    fig.text(0.5, 0.5, "PLACEHOLDER", fontsize=30, color="#000000",
             alpha=0.055, ha="center", va="center", rotation=28,
             fontweight="bold", zorder=1000)

# ----------------------------------------------------------------------
# Synthetic ROC generator (monotone, smooth) from (auc, tpr@1%) targets
# ----------------------------------------------------------------------
def _roc_from_targets(auc_target, tpr1_target, n=400, seed=0):
    """A plausible, concave, monotone ROC that (i) passes through (1,1),
    (ii) hits ~tpr@1%FPR, and (iii) decays smoothly toward the origin with no
    flat shelf. Built as two concave power segments joined at FPR=1%."""
    fpr = np.logspace(-3, 0, n)
    a = 0.01
    t1 = 0.02 if tpr1_target is None else max(tpr1_target, 1e-3)
    # low-FPR segment: tpr = t1 * (fpr/a)^p_lo  for fpr <= a, p_lo>0 -> ->0 at origin
    p_lo = 0.55
    lo = t1 * (fpr / a) ** p_lo
    # high-FPR segment: concave rise from (a, t1) to (1, 1)
    # tpr = 1 - (1 - t1) * ((1 - x)/(1 - la))^p_hi  in log space x=log10(fpr)
    la = np.log10(a); x = np.log10(fpr)
    p_hi = np.clip(1.6 * (1 - auc_target) / max(1 - t1, 1e-3), 0.35, 2.5)
    hi = 1 - (1 - t1) * ((0 - x) / (0 - la)) ** p_hi
    tpr = np.where(fpr <= a, lo, hi)
    tpr = np.clip(np.maximum.accumulate(tpr), 0, 1)
    return fpr, tpr

# ----------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------
def fig_di_roc(d, measured, out):
    set_style()
    fig, ax = plt.subplots(figsize=(COL, 2.45))
    rocs = d["di"]["roc"]
    shades = ["#c2d3e8", "#8fb0d6", "#5b84b1", "#2f5580"]
    for i, r in enumerate(rocs):
        if r.get("fpr") and r.get("tpr"):          # measured curve
            fpr = np.clip(np.asarray(r["fpr"], float), 1e-3, 1.0)
            tpr = np.asarray(r["tpr"], float)
        elif measured:                              # never invent a curve for a measured figure
            sys.exit(f"ROC for k={r['k']} has no measured fpr/tpr; refusing to synthesize under --measured")
        else:                                       # quick look only (watermarked PLACEHOLDER)
            fpr, tpr = _roc_from_targets(r["auc"], r["tpr1"], seed=i)
        ax.plot(fpr, tpr, lw=1.5, color=shades[i % len(shades)], drawstyle="default",
                label=f"$k={r['k']}$  (AUC {r['auc']:.2f})", zorder=5)
    ax.plot([1e-3, 1], [1e-3, 1], ls=(0, (2, 2)), color=C_MUTE, lw=0.8, zorder=2)
    ax.axvline(0.01, color=C_TIER3, lw=0.7, ls=(0, (1, 1.5)), zorder=2, alpha=0.7)
    ax.text(0.01, 1.015, "1\\% FPR", color=C_TIER3, fontsize=6, ha="center", va="bottom")
    ax.set_xscale("log"); ax.set_xlim(1e-3, 1); ax.set_ylim(0, 1.0)
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    _clean(ax, grid_axis="both")
    leg = ax.legend(loc="lower right", title="records deleted / subject", fontsize=6.4)
    leg.get_title().set_fontsize(6.4)
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def fig_rq1_heat(d, measured, out):
    set_style()
    comps = d["rq1"]["components"]
    names = [c["name"] for c in comps]
    M = np.array([[np.nan if v is None else v for v in c["vals"]] for c in comps]).T  # 3 x N
    tiers = d["rq1"]["tiers"]
    fig, ax = plt.subplots(figsize=(DBL, 1.72))
    # per-tier colormaps so hue encodes tier, luminance encodes magnitude
    from matplotlib.colors import LinearSegmentedColormap, Normalize
    cmaps = [LinearSegmentedColormap.from_list("t1", ["#eef4fb", C_TIER1]),
             LinearSegmentedColormap.from_list("t2", ["#fdf3e2", C_TIER2]),
             LinearSegmentedColormap.from_list("t3", ["#fbeceb", C_TIER3])]
    norm = Normalize(0, 1)
    N = len(names)
    for r in range(3):
        for c in range(N):
            v = M[r, c]
            x, y = c, 2 - r
            if np.isnan(v):
                ax.add_patch(plt.Rectangle((x-0.5, y-0.5), 1, 1, facecolor="#f4f4f4",
                             edgecolor="white", lw=1.2, zorder=1))
                ax.plot([x-0.28, x+0.28], [y, y], color="#c2c2c2", lw=0.9, zorder=2)
            else:
                ax.add_patch(plt.Rectangle((x-0.5, y-0.5), 1, 1, facecolor=cmaps[r](norm(v)),
                             edgecolor="white", lw=1.2, zorder=1))
                tc = "white" if v > 0.62 else C_INK
                ax.text(x, y, f"{v:.2f}", ha="center", va="center", fontsize=6.1,
                        color=tc, zorder=3)
    ax.set_xlim(-0.5, N-0.5); ax.set_ylim(-0.5, 2.5)
    ax.set_xticks(range(N)); ax.set_xticklabels(names, rotation=38, ha="right", fontsize=6.6)
    ax.set_yticks([2, 1, 0]); ax.set_yticklabels(["Tier I\ncopy", "Tier II\nstructural", "Tier III\nsemantic"], fontsize=7)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)
    # category separators
    cats = [c["cat"] for c in comps]
    for c in range(1, N):
        if cats[c] != cats[c-1]:
            ax.axvline(c-0.5, color="#b0b0b0", lw=0.7, ls=(0, (2, 2)), zorder=4)
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def fig_rq2_recovery(d, measured, out):
    set_style()
    rq = d["rq2"]
    mechs = rq["mechanisms"]; systems = rq["systems"]
    R = np.array([[np.nan if v is None else v for v in row] for row in rq["recovery"]])  # mech x sys
    fig, ax = plt.subplots(figsize=(COL, 2.35))
    nmech = len(mechs); nsys = len(systems)
    w = 0.26
    xs = np.arange(nmech)
    sys_colors = ["#3b6ea5", "#c98a26", "#6a6f76"]
    for j in range(nsys):
        vals = R[:, j]
        ax.bar(xs + (j - (nsys-1)/2) * w, np.nan_to_num(vals) * 100, w,
               color=sys_colors[j % len(sys_colors)], label=systems[j], zorder=3,
               edgecolor="white", linewidth=0.4)
    ax.set_xticks(xs)
    ax.set_xticklabels([m.split()[0] for m in mechs], fontsize=7)
    ax.set_ylabel("Canary facts recovered (\\%)")
    ax.set_ylim(0, 100)
    _clean(ax, grid_axis="y")
    ax.legend(loc="upper right", ncol=1, fontsize=6.4)
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def fig_rq2_zombie(d, measured, out):
    set_style()
    z = d["rq2"]["zombie"]; systems = d["rq2"]["systems"]
    conds = ["before", "after", "counterfactual"]
    labels = ["before\ndeletion", "after\ndeletion", "counter-\nfactual"]
    colors = [C_TIER3, "#e0894a", C_MUTE]
    fig, ax = plt.subplots(figsize=(COL, 2.35))
    xs = np.arange(len(systems)); w = 0.24
    for i, cond in enumerate(conds):
        vals = np.array([np.nan if v is None else v for v in z[cond]], float) * 100
        bars = ax.bar(xs + (i-1)*w, vals, w, color=colors[i], label=labels[i],
                      zorder=3, edgecolor="white", linewidth=0.4)
    # annotate the residue gap (after - counterfactual) on the first system
    ax.set_xticks(xs); ax.set_xticklabels(systems, fontsize=7)
    ax.set_ylabel("Attack success rate (\\%)"); ax.set_ylim(0, 100)
    _clean(ax, grid_axis="y")
    ax.legend(loc="upper right", fontsize=6.2, ncol=1)
    # residue bracket
    a = (z["after"][0] or 0)*100; cf = (z["counterfactual"][0] or 0)*100
    xr = xs[0] + w
    ax.annotate("", xy=(xr, a), xytext=(xr, cf),
                arrowprops=dict(arrowstyle="<->", color=C_INK, lw=0.7))
    ax.text(xr+0.06, (a+cf)/2, "residue", fontsize=6, va="center", color=C_INK)
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def fig_rq3_tradeoff(d, measured, out):
    set_style()
    pts = [p for p in d["rq3"]["points"] if p.get("adv") is not None]
    sw = d["rq3"].get("s_sweep", [])
    if not pts:
        return
    fig, ax = plt.subplots(figsize=(COL, 2.5))
    colors = {"Native": C_TIER3, "Full rebuild": C_MUTE, "LSED": C_ACCENT}
    xs_all = [p["del_s"] for p in pts] + [s["del_s"] for s in sw]
    xlo, xhi = min(xs_all) / 3, max(xs_all) * 3
    ymax = max(0.85, max(p["adv"] for p in pts) + 0.12)
    lsed_adv = next((p["adv"] for p in pts if p["label"] == "LSED"), 0.04)
    if sw:
        ax.plot([s["del_s"] for s in sw], [lsed_adv] * len(sw), color=C_ACCENT, lw=0.8,
                ls=(0, (3, 2)), alpha=0.5, zorder=3)
    ax.axhspan(0, 0.05, color="#eaf3ea", zorder=0)
    ax.text(xlo * 1.15, 0.062, "chance (complete)", fontsize=6, color="#4f9d69")
    for p in pts:
        ax.scatter(p["del_s"], p["adv"], s=44, zorder=6, color=colors.get(p["label"], C_INK),
                   edgecolor="white", linewidth=0.8)
        if p["label"] == "LSED":
            ax.annotate("LSED", (p["del_s"], p["adv"]), xytext=(p["del_s"], p["adv"] + 0.1),
                        ha="center", fontsize=6.8, color=C_ACCENT,
                        arrowprops=dict(arrowstyle="-", color=C_ACCENT, lw=0.5))
        else:
            ha = "left" if p["label"] == "Native" else "right"
            ax.annotate(p["label"], (p["del_s"], p["adv"]),
                        xytext=(p["del_s"] * (1.3 if ha == "left" else 0.78), p["adv"] + 0.04),
                        fontsize=6.8, ha=ha, color=C_INK)
    ax.set_xscale("log"); ax.set_xlabel("Deletion latency (s, log scale)")
    ax.set_ylabel("Deletion-inference advantage")
    ax.set_ylim(-0.02, ymax); ax.set_xlim(xlo, xhi)
    _clean(ax, grid_axis="both")
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def fig_rq3_sweep(d, measured, out):
    set_style()
    sw = d["rq3"]["s_sweep"]
    S = [x["S"] for x in sw]; dl = [x["del_s"] for x in sw]; p99 = [x["p99x"] for x in sw]
    fig, ax = plt.subplots(figsize=(COL, 2.4))
    ax.plot(S, dl, "-o", color=C_ACCENT, lw=1.4, ms=3.5, label="deletion latency (s)", zorder=5)
    ax.set_xlabel("Number of partitions $S$"); ax.set_ylabel("Deletion latency (s)", color=C_ACCENT)
    ax.set_xscale("log", base=2); ax.set_yscale("log")
    ax.tick_params(axis="y", labelcolor=C_ACCENT)
    _clean(ax, grid_axis="x")
    ax2 = ax.twinx()
    ax2.plot(S, p99, "-s", color=C_TIER3, lw=1.4, ms=3.2, label="p99 latency ($\\times$)", zorder=5)
    ax2.set_ylabel("Tail query latency ($\\times$ native)", color=C_TIER3)
    ax2.tick_params(axis="y", labelcolor=C_TIER3)
    ax2.spines["top"].set_visible(False)
    # combined legend
    lines = [Line2D([0],[0], color=C_ACCENT, marker="o", lw=1.4, ms=3.5),
             Line2D([0],[0], color=C_TIER3, marker="s", lw=1.4, ms=3.2)]
    ax.legend(lines, ["deletion latency", "p99 query latency"], loc="upper center", fontsize=6.4)
    ax.set_xticks(S); ax.set_xticklabels([str(s) for s in S])
    _watermark(fig, measured)
    fig.savefig(out); plt.close(fig)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="figure-data JSON from `run.py export`")
    ap.add_argument("--measured", action="store_true",
                    help="omit the PLACEHOLDER watermark (use with real data)")
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()
    d = json.loads(open(args.data).read())
    os.makedirs(args.outdir, exist_ok=True)
    P = lambda n: os.path.join(args.outdir, n)
    jobs = [("di", fig_di_roc, "fig_di_roc.pdf"),
            ("rq1", fig_rq1_heat, "fig_rq1_heat.pdf"),
            ("rq2", fig_rq2_recovery, "fig_rq2_recovery.pdf"),
            ("rq2", fig_rq2_zombie, "fig_rq2_zombie.pdf"),
            ("rq3", fig_rq3_tradeoff, "fig_rq3_tradeoff.pdf"),
            ("rq3", fig_rq3_sweep, "fig_rq3_sweep.pdf")]
    for section, fn, name in jobs:
        if section not in d:
            print(f"  skip {name}: no '{section}' section in data"); continue
        if fn is fig_rq3_sweep and not d["rq3"].get("s_sweep"):
            print(f"  skip {name}: no s_sweep"); continue
        if fn is fig_rq3_tradeoff and not d["rq3"].get("points"):
            print(f"  skip {name}: no points"); continue
        fn(d, args.measured, P(name))
        print(f"  wrote {name}")
    print("wrote figures to", args.outdir)

if __name__ == "__main__":
    main()
