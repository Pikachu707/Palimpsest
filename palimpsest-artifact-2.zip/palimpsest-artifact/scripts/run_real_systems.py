#!/usr/bin/env python3
"""Real-system validation on one GPU: start vLLM, smoke-test, run, stop.

    python scripts/run_real_systems.py                  # Qwen2.5-7B, smoke test, then the full run
    python scripts/run_real_systems.py --skip-smoke
    python scripts/run_real_systems.py --vllm-python /usr/bin/python3   # vLLM outside this venv

Reuses the backend sweep's server management: it refuses a port that is already
serving, and accepts the server only if it serves exactly the requested model.
"""
import argparse, importlib.util, json, os, subprocess, sys
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)


def run(cmd, env, log):
    with open(log, "w") as f:
        p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=ROOT)
        for line in p.stdout:
            sys.stdout.write(line); f.write(line)
        return p.wait()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen7b"); ap.add_argument("--skip-smoke", action="store_true")
    ap.add_argument("--n-subjects", type=int, default=20); ap.add_argument("--parallel", type=int, default=6)
    ap.add_argument("--subjects-per-manager", type=int, default=10,
                    help="=1 maximises distinct managers (zombie-poisoning targets)")
    ap.add_argument("--out", default="results/real")
    ap.add_argument("--system", choices=["lightrag", "mem0", "mem0-zombie", "all"], default="all",
                    help="mem0-zombie: rerun only Mem0 zombie poisoning (e.g. --system mem0-zombie --out results/real_zombie)")
    ap.add_argument("--n-poison", type=int, default=10)
    ap.add_argument("--vllm-python", help="python that has vLLM, if the experiments run in a separate venv")
    ap.add_argument("--max-model-len", type=int, default=32768,
                    help="vLLM context length: Mem0's extraction prompt is ~6.7k tokens and LightRAG's "
                         "default query budget is 30k tokens, so 8192 is too small (Qwen2.5 supports 32768)")
    a = ap.parse_args()
    if a.vllm_python:
        os.environ["PAL_VLLM_PYTHON"] = a.vllm_python
    os.chdir(ROOT)
    cfg = yaml.safe_load(open("configs/backends.yaml"))
    b = next(x for x in cfg["backends"] if x["tag"] == a.model)
    cfg["max_model_len"] = a.max_model_len
    emb = yaml.safe_load(open(cfg["base_config"]))["emb"]["model"]
    for path in (b["path"], emb):
        ok, why = rb.weights_complete(Path(path))
        if not ok:
            sys.exit(f"model files incomplete at {path}: {why}")
    Path("logs").mkdir(exist_ok=True)
    proc = rb.start_server(b, cfg, Path("logs"), dry=False)
    env = dict(os.environ, PAL_LLM_BASE_URL=f"http://localhost:{cfg['port']}/v1", PAL_LLM_MODEL=b["path"],
               PAL_EMB_MODEL=emb, MEM0_TELEMETRY="False", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    try:
        base = [sys.executable, "-m", "palimpsest.experiments.real_systems", "--parallel", str(a.parallel),
                "--system", a.system]
        if not a.skip_smoke:
            rb.log("smoke test (2 subjects per system)")
            if run(base + ["--quick", "--out", a.out], env, "logs/real_smoke.log"):
                sys.exit("smoke test failed; see logs/real_smoke.log")
            for sysname in [x for x in ("lightrag", "mem0", "mem0_zombie") if a.system in ("all", x.replace("_", "-"))]:
                s = json.load(open(f"{a.out}_quick/{sysname}.json"))["summary"]
                if s.get("invalid_worlds"):
                    sys.exit(f"smoke test: {sysname} has invalid worlds {s['invalid_worlds'][:2]}; see results")
            rb.log("smoke test passed")
        base += ["--subjects-per-manager", str(a.subjects_per_manager), "--n-poison", str(a.n_poison)]
        if run(base + ["--n-subjects", str(a.n_subjects), "--out", a.out], env, "logs/real_full.log"):
            sys.exit("full run failed; see logs/real_full.log")
    finally:
        rb.stop_server(proc, cfg["port"])
    rb.log(f"done: results in {a.out}/ (lightrag.json, mem0.json, mem0_zombie.json, meta.json)")


if __name__ == "__main__":
    main()
