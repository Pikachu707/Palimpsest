#!/usr/bin/env python3
"""LLM-backend sweep: for each backend in configs/backends.yaml, start vLLM,
rerun every LLM-dependent experiment, stop the server, and move on.

Resumable: a backend whose result files already exist is skipped, so an
interrupted sweep loses at most the backend in progress.

    python scripts/run_backends.py                     # all backends
    python scripts/run_backends.py --only llama8b gemma9b
    python scripts/run_backends.py --no-download       # weights already local
    python scripts/run_backends.py --dry-run           # print the plan only
    python scripts/run_backends.py --only qwen7b_repro   # reproduce the paper's runs on this machine
"""
import argparse, os, subprocess, sys, time, urllib.request, json
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
STAGES = [  # (suffix, run.py stage, extra --set)
    ("", "rq1", []),
    ("", "rq2", []),
    ("_onesent", "rq2", ["graph.render_style=one_sentence"]),
]
EXPECT = {"rq1": "rq1_residue.json", "rq2": "rq2_recovery_zombie.json"}


def log(msg):
    print(f"[backends {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def done(results_dir: Path, run_name: str, stage: str) -> bool:
    return (results_dir / run_name / EXPECT[stage]).exists()


def weights_complete(path: Path) -> tuple:
    """True only if config.json and EVERY weight shard listed in the safetensors
    index exist and are non-empty. config.json alone arrives first during a
    download, so it does not prove the shards are there."""
    if not (path / "config.json").exists():
        return False, "config.json missing"
    idx = path / "model.safetensors.index.json"
    if idx.exists():
        shards = sorted(set(json.load(open(idx))["weight_map"].values()))
    else:
        shards = ["model.safetensors"]
    bad = [s for s in shards if shard_problem(path / s)]
    if bad:
        return False, (f"{len(bad)}/{len(shards)} weight shards missing, empty or truncated "
                       f"(e.g. {bad[0]}: {shard_problem(path / bad[0])})")
    return True, f"{len(shards)} shards present and complete"


def shard_problem(f: Path):
    """None if the shard is complete. A safetensors file is an 8-byte header
    length, a JSON header giving every tensor's byte range, then the data, so its
    exact expected size is known from the header alone: this catches truncated
    downloads (e.g. an interrupted IncompleteRead) without hashing the file."""
    if not f.exists():
        return "missing"
    size = f.stat().st_size
    if size == 0:
        return "empty"
    if f.suffix != ".safetensors":
        return None
    try:
        with open(f, "rb") as fh:
            n = int.from_bytes(fh.read(8), "little")
            if n <= 0 or n > size:
                return "corrupt header"
            header = json.loads(fh.read(n))
    except Exception as e:
        return f"unreadable header ({e.__class__.__name__})"
    end = max((v["data_offsets"][1] for k, v in header.items() if k != "__metadata__"), default=0)
    expected = 8 + n + end
    if size != expected:
        return f"truncated ({size / 1e9:.2f} of {expected / 1e9:.2f} GB)"
    return None


def ensure_weights(b, allow_download: bool, dry: bool):
    path = Path(b["path"])
    ok, why = weights_complete(path)
    if ok:
        return
    log(f"{b['tag']}: weights incomplete at {path}: {why}")
    if not allow_download:
        sys.exit(f"weights incomplete for {b['tag']}: {path}: {why}\n"
                 f"finish the download (or rerun without --no-download), then rerun this command")
    log(f"downloading {b['modelscope']} -> {path}")
    if dry:
        return
    from modelscope import snapshot_download  # pip install modelscope
    try:
        snapshot_download(b["modelscope"], local_dir=str(path))
    except Exception as e:
        sys.exit(f"download failed for {b['modelscope']}: {e}\n"
                 f"check the model ID on modelscope.cn and edit configs/backends.yaml")


def served_models(port: int):
    """Model ids served on localhost:port, or None if nothing answers."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/models", timeout=5) as r:
            return [m["id"] for m in json.load(r)["data"]]
    except Exception:
        return None


def start_server(b, cfg, logdir: Path, dry: bool):
    # PAL_VLLM_PYTHON: interpreter that has vLLM, when the experiment libraries live in a
    # separate virtualenv (keeps their dependencies from upgrading vLLM's).
    cmd = [os.environ.get("PAL_VLLM_PYTHON", sys.executable), "-m", "vllm.entrypoints.openai.api_server",
           "--model", b["path"], "--port", str(cfg["port"]),
           "--gpu-memory-utilization", str(b.get("gpu_util", 0.4)),
           "--max-model-len", str(cfg.get("max_model_len", 8192))]
    if cfg.get("attention_backend"):
        cmd += ["--attention-backend", cfg["attention_backend"]]
    env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
               VLLM_USE_FLASHINFER_SAMPLER="0")
    log("vLLM: " + " ".join(cmd))
    if dry:
        return None
    busy = served_models(cfg["port"])
    if busy is not None:
        sys.exit(f"port {cfg['port']} is already in use by a server serving {busy}.\n"
                 f"Another vLLM is running (a sweep in another window, or a leftover). "
                 f"Wait for it, or stop it: pkill -f vllm.entrypoints ; then rerun.")
    out = open(logdir / f"vllm_{b['tag']}.log", "w")
    proc = subprocess.Popen(cmd, env=env, stdout=out, stderr=subprocess.STDOUT,
                            start_new_session=True)      # own process group: stop kills all children
    for _ in range(180):                        # up to 30 min (72B load + compile)
        if proc.poll() is not None:
            sys.exit(f"vLLM exited early for {b['tag']}; see logs/vllm_{b['tag']}.log")
        served = served_models(cfg["port"])
        if served is not None:
            if b["path"] not in served:         # someone else's server answered
                stop_server(proc)
                sys.exit(f"port {cfg['port']} answered with {served}, not {b['path']}; refusing to run")
            log(f"server ready, serving {served}")
            return proc
        time.sleep(10)
    stop_server(proc)
    sys.exit(f"vLLM did not become ready for {b['tag']}")


def stop_server(proc, port: int = 8000):
    if proc is None:
        return
    import signal
    try:
        os.killpg(proc.pid, signal.SIGTERM)          # the server and all its workers
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for _ in range(30):                              # wait until the port is really free
        if served_models(port) is None:
            break
        time.sleep(2)
    time.sleep(5)                                    # let the GPU memory drain


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backends", default="configs/backends.yaml")
    ap.add_argument("--only", nargs="*", help="tags to run (default: all)")
    ap.add_argument("--no-download", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    os.chdir(ROOT)
    cfg = yaml.safe_load(open(a.backends))
    base = cfg["base_config"]
    results_dir = Path(yaml.safe_load(open(base)).get("out_dir", "results"))
    logdir = Path("logs"); logdir.mkdir(exist_ok=True)
    for b in cfg["backends"]:
        if a.only and b["tag"] not in a.only:
            continue
        if b.get("reuse"):
            log(f"{b['tag']}: reusing existing runs '{b['reuse']}' (baseline)")
            continue
        todo = [(s, st, ex) for s, st, ex in STAGES if not done(results_dir, f"be_{b['tag']}{s}", st)]
        if not todo:
            log(f"{b['tag']}: all results present, skipping")
            continue
        ensure_weights(b, not a.no_download, a.dry_run)
        proc = start_server(b, cfg, logdir, a.dry_run)
        try:
            for suffix, stage, extra in todo:
                run_name = f"be_{b['tag']}{suffix}"
                cmd = [sys.executable, "run.py", stage, "--config", base,
                       "--set", f"llm.model={b['path']}", "--set", f"run_name={run_name}"]
                for e in list(extra) + list(b.get("overrides", [])):
                    cmd += ["--set", e]
                log(f"{b['tag']}: {' '.join(cmd[1:])}")
                if a.dry_run:
                    continue
                with open(logdir / f"{run_name}_{stage}.log", "w") as out:
                    rc = subprocess.call(cmd, stdout=out, stderr=subprocess.STDOUT)
                if rc != 0:
                    sys.exit(f"{run_name} {stage} failed (rc={rc}); see logs/{run_name}_{stage}.log")
        finally:
            stop_server(proc, cfg["port"])
        log(f"{b['tag']}: done")
    if not a.dry_run:
        subprocess.call([sys.executable, "-m", "palimpsest.report.backend_table",
                         "--backends", a.backends, "--results", str(results_dir)])


if __name__ == "__main__":
    main()
