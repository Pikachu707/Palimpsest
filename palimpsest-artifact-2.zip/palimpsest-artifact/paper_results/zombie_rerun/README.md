# Zombie-poisoning rerun: GraphRAG and Mem0 (Table 5, Appendix H)

One NVIDIA H100, Qwen2.5-7B-Instruct (vLLM 0.30.0), bge-large-en-v1.5; all worlds valid.

* `real_zombie/`: `python scripts/run_real_systems.py --system mem0-zombie` (Mem0 2.2.1,
  10 users x {lineage, delete_all, counterfactual} x {ref, neutral}; 3.1 minutes).
* `graphrag_zombie/`: `python scripts/run_graphrag.py --only zombie` (GraphRAG 3.2.0,
  10 indexed background subjects x {update, reindex} + counterfactual; 21.8 minutes).
  `ops/` holds every world's answers, retrieved contexts, and at-rest scans.

| | before | after deletion | after the user's next message |
|---|---|---|---|
| Mem0, one `add()`'s memories | 100% | 0% | 30% referring back, 0% unrelated |
| Mem0, `delete_all` | 100% | 0% | 90% referring back, 0% unrelated |
| GraphRAG, incremental update (7 of 10 targets retrieved) | 63% | 90% of the 7 | |
| GraphRAG, full re-index (7 of 10 targets retrieved) | 70% | 0% | |

After `delete_all` and a referring message, Mem0 also re-extracts 90% of the user's erased
benign facts (67% to 100% per user). The deleted conversation is in the next extraction prompt
in every Mem0 world; no counterfactual world in either system ever returns the poison.
