# Microsoft GraphRAG 3.2.0 results

* `run2/`: the reported run (32 worlds, all valid; 40 minutes on one NVIDIA H100).
  Community reports use frequency_penalty 0.3 and every completion is capped at 4,096 tokens.
* `run1/ops/`: an earlier run without those two settings. All 20 recovery worlds completed and
  agree with run 2; 4 zombie worlds did not terminate (a community report looped under greedy
  decoding) and are recorded as errors.

GraphRAG's indexing is not deterministic across runs (concurrent LLM calls), so each world is
compared before and after its own deletion. Zombie poisoning could not be measured: local search
did not retrieve the poisoned entity even before deletion (0% success), so no deletion effect is claimed.
