"""The real (non-test) tokenizer path of the LightRAG world must survive copy.deepcopy
and pickling: LightRAG deep-copies its configuration. The plumbing test uses a byte
tokenizer, so without this test the real path would go untested."""
import copy, pickle
import pytest
from palimpsest.real.common import _ThreadLocalHFTok


def test_thread_local_tokenizer_survives_deepcopy_and_pickle():
    tok = _ThreadLocalHFTok("/nonexistent/model")          # lazy: nothing is loaded here
    assert copy.deepcopy(tok) is tok                        # LightRAG's documented contract
    clone = pickle.loads(pickle.dumps(tok))
    assert isinstance(clone, _ThreadLocalHFTok) and clone.path == tok.path


def test_wrapped_in_lightrag_tokenizer_survives_deepcopy():
    lr = pytest.importorskip("lightrag.utils")
    wrapped = lr.Tokenizer("qwen", _ThreadLocalHFTok("/nonexistent/model"))
    copy.deepcopy(wrapped)                                   # raised "cannot pickle '_thread._local'" before the fix
    copy.deepcopy({"tokenizer": wrapped, "other": 1})
