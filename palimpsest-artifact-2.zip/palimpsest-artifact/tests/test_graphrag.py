"""End-to-end plumbing of the GraphRAG experiment against a stub LLM. GraphRAG lives in its
own virtualenv, so this runs only when PAL_GRAPHRAG_PYTHON points at a python that has it.
Asserts only model-independent behaviour of GraphRAG 3.2.0's storage."""
import json, os, subprocess, sys, threading
import pytest
PY = os.environ.get("PAL_GRAPHRAG_PYTHON")
if not PY or subprocess.run([PY, "-c", "import graphrag"], capture_output=True).returncode:
    pytest.skip("PAL_GRAPHRAG_PYTHON with graphrag not available", allow_module_level=True)
sys.path.insert(0, os.path.dirname(__file__))
import stub_openai


def test_graphrag_quick_pipeline(tmp_path):
    os.environ["PAL_FAKE_EMBED"] = "1"
    from palimpsest.real import embed_server, common
    common.FAKE_EMBED = True          # common may already be imported by an earlier test
    srv, url = stub_openai.start()
    es = embed_server.serve(0); threading.Thread(target=es.serve_forever, daemon=True).start()
    env = dict(os.environ, PAL_LLM_BASE_URL=url, PAL_FAKE_EMBED="1", PAL_LLM_MODEL="stub", PAL_GRAPHRAG_PYTHON=PY,
               PAL_EMB_BASE_URL=f"http://127.0.0.1:{es.server_address[1]}/v1", PYTHONPATH=os.getcwd())
    r = subprocess.run([sys.executable, "-m", "palimpsest.experiments.graphrag_exp", "--quick", "--parallel", "3",
                        "--out", str(tmp_path / "g")], env=env, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stderr[-2000:]
    s = json.load(open(f"{tmp_path}/g_quick/graphrag.json"))["summary"]
    assert s["invalid_worlds"] == []
    # GraphRAG 3.2.0: an incremental update ignores removed documents ...
    assert s["recovery"]["update"]["docs_still_indexed"] == 1.0
    assert "output/documents.parquet" in s["recovery"]["update"]["at_rest_stores"]
    # ... a full re-index removes them from the index, but not from the LLM cache or update backups
    assert s["recovery"]["reindex"]["docs_still_indexed"] == 0.0
    assert {"cache", "update_output"} <= set(s["recovery"]["reindex"]["at_rest_stores"])
    assert s["counterfactual"]["recovery"] == 0.0
    # zombie poisoning targets an indexed entity, so the attack is measurable; the update keeps
    # the poison documents indexed, a re-index drops them, and the counterfactual never sees it
    assert s["zombie"]["update"]["docs_still_indexed"] == 1.0 and s["zombie"]["reindex"]["docs_still_indexed"] == 0.0
    assert s["counterfactual"]["zombie"] == 0.0
