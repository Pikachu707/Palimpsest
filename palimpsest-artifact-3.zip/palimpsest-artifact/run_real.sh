#!/usr/bin/env bash
# One command for every real-system experiment of the paper (Table 5, Appendix H):
# Microsoft GraphRAG 3.2.0, LightRAG 1.5.7 and Mem0 2.2.1 driven through their own
# deletion APIs, on one NVIDIA GPU (>= 40 GB; the paper used one H100 80 GB).
#
#   bash run_real.sh                  # set up everything, then the full Table 5 run (~2.5 h + setup)
#   bash run_real.sh --profile quick  # same setup, smoke tests only (~15 min): check the stack first
#   bash run_real.sh --setup-only     # environments and weights, no experiment
#   bash run_real.sh --systems graphrag          # one driver only (or lightrag-mem0)
#   bash run_real.sh --dry-run                   # preflight and plan; start nothing
#   bash run_real.sh --lsed only                 # add only the LSED conditions to an existing run
#   bash run_real.sh --systems graphiti hotpotqa timing   # the follow-up experiments (Appendix H)
#   Any other option is passed to scripts/real_all.py (see: python scripts/real_all.py -h).
#
# Idempotent and resumable: run the same command again after an interruption; finished
# setup steps and finished experiment stages are skipped.
#
# Environment (all optional):
#   PAL_WORKDIR    root for venvs and weights        default /workspace if writable, else ~/palimpsest-work
#   PAL_MODELS_DIR model weights                     default $PAL_WORKDIR/models
#   PAL_VENV, PAL_VENV_GRAPHRAG, PAL_VENV_GRAPHITI   default $PAL_WORKDIR/venv, venv-graphrag, venv-graphiti
#   HUB            modelscope | hf                   default modelscope (as in the paper)
#   PAL_OUT        results directory                 default results/real_eval
#   PAL_GPU_UTIL   vLLM --gpu-memory-utilization     default 0.40 (0.60 on GPUs under 70 GB)
#   PAL_ATTN_BACKEND  vLLM attention backend         default FLASH_ATTN; "auto" lets vLLM choose
#   PAL_VLLM_PORT  vLLM port                         default 8000
#   CUDA_VISIBLE_DEVICES  which GPU to use
set -euo pipefail
cd "$(dirname "$0")"
REPO="$(pwd)"

SETUP_ONLY=0; SKIP_SETUP=0; PASS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --setup-only) SETUP_ONLY=1 ;;
    --skip-setup) SKIP_SETUP=1 ;;
    -h|--help) sed -n "2,32p" "$0"; exit 0 ;;
    *) PASS+=("$1") ;;
  esac
  shift
done

if [ -z "${PAL_WORKDIR:-}" ]; then
  if [ -d /workspace ] && [ -w /workspace ]; then PAL_WORKDIR=/workspace; else PAL_WORKDIR="$HOME/palimpsest-work"; fi
fi
export PAL_WORKDIR
export PAL_MODELS_DIR="${PAL_MODELS_DIR:-$PAL_WORKDIR/models}"
PAL_VENV="${PAL_VENV:-$PAL_WORKDIR/venv}"
PAL_VENV_GRAPHRAG="${PAL_VENV_GRAPHRAG:-$PAL_WORKDIR/venv-graphrag}"
export PAL_GRAPHRAG_PYTHON="$PAL_VENV_GRAPHRAG/bin/python"
PAL_VENV_GRAPHITI="${PAL_VENV_GRAPHITI:-$PAL_WORKDIR/venv-graphiti}"
export PAL_GRAPHITI_PYTHON="$PAL_VENV_GRAPHITI/bin/python"
HUB="${HUB:-modelscope}"
PAL_OUT="${PAL_OUT:-results/real_eval}"
mkdir -p "$PAL_WORKDIR" "$PAL_MODELS_DIR" logs "$PAL_OUT"
SETUP_LOG="$REPO/$PAL_OUT/setup.log"
[ "${PAL_OUT:0:1}" = "/" ] && SETUP_LOG="$PAL_OUT/setup.log"

step() { printf '\n\033[1m=== %s ===\033[0m\n' "$*"; }
die()  { printf '\n\033[31mSETUP FAILED:\033[0m %s\n' "$*" >&2; exit 1; }
req_hash() { cat "$@" | sha256sum | cut -c1-16; }

echo "repo     $REPO"
echo "workdir  $PAL_WORKDIR   models $PAL_MODELS_DIR   hub $HUB"
echo "venvs    $PAL_VENV   $PAL_VENV_GRAPHRAG   $PAL_VENV_GRAPHITI"
echo "results  $PAL_OUT"

if [ "$SKIP_SETUP" = 0 ]; then
  {
  step "1/6 GPU and disk"
  command -v nvidia-smi >/dev/null || die "nvidia-smi not found: this experiment needs an NVIDIA GPU and driver"
  nvidia-smi --query-gpu=index,name,memory.total,driver_version --format=csv,noheader || die "nvidia-smi failed"
  avail=$(df -BG --output=avail "$PAL_WORKDIR" | tail -1 | tr -dc 0-9)
  need=50; for m in Qwen2.5-7B-Instruct bge-large-en-v1.5; do [ -f "$PAL_MODELS_DIR/$m/config.json" ] && need=$((need-15)); done
  echo "free under $PAL_WORKDIR: ${avail}G (need ~${need}G for venvs and weights)"
  [ "$avail" -ge "$need" ] || die "not enough disk under $PAL_WORKDIR; set PAL_WORKDIR to a larger volume"

  step "2/6 uv (Python and package manager)"
  if ! command -v uv >/dev/null; then
    python3 -m pip install -q --user -U uv 2>/dev/null || curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
  fi
  command -v uv >/dev/null || die "could not install uv"
  uv --version

  step "3/6 main environment: vLLM 0.30.0, LightRAG 1.5.7, Mem0 2.2.1"
  H=$(req_hash requirements.txt requirements-real.txt)
  if [ "$(cat "$PAL_VENV/.pal-ok" 2>/dev/null)" = "$H" ]; then
    echo "up to date: $PAL_VENV"
  else
    [ -x "$PAL_VENV/bin/python" ] || uv venv -p 3.12 "$PAL_VENV"
    VIRTUAL_ENV="$PAL_VENV" uv pip install "vllm==0.30.0" --torch-backend=auto
    VIRTUAL_ENV="$PAL_VENV" uv pip install -r requirements.txt -r requirements-real.txt \
        openai sentence-transformers modelscope huggingface_hub pyyaml
    "$PAL_VENV/bin/python" -c "import vllm, lightrag, mem0, torch; assert torch.cuda.is_available(), 'torch sees no GPU'; \
print('vllm', vllm.__version__, '| torch', torch.__version__, '| GPU', torch.cuda.get_device_name(0))" \
        || die "main environment does not import or does not see the GPU"
    echo "$H" > "$PAL_VENV/.pal-ok"
  fi

  step "4/6 GraphRAG environment (its pins conflict with the main one)"
  H=$(req_hash requirements-graphrag.txt)
  if [ "$(cat "$PAL_VENV_GRAPHRAG/.pal-ok" 2>/dev/null)" = "$H" ]; then
    echo "up to date: $PAL_VENV_GRAPHRAG"
  else
    [ -x "$PAL_VENV_GRAPHRAG/bin/python" ] || uv venv -p 3.12 "$PAL_VENV_GRAPHRAG"
    VIRTUAL_ENV="$PAL_VENV_GRAPHRAG" uv pip install -r requirements-graphrag.txt sentence-transformers pyyaml
    "$PAL_VENV_GRAPHRAG/bin/python" -c "import importlib.metadata as m; print('graphrag', m.version('graphrag'))" \
        || die "GraphRAG environment broken"
    echo "$H" > "$PAL_VENV_GRAPHRAG/.pal-ok"
  fi

  step "5/6 Graphiti environment: graphiti-core 0.31.2 on an embedded FalkorDB"
  H=$(req_hash requirements-graphiti.txt)
  if [ "$(cat "$PAL_VENV_GRAPHITI/.pal-ok" 2>/dev/null)" = "$H" ]; then
    echo "up to date: $PAL_VENV_GRAPHITI"
  else
    [ -x "$PAL_VENV_GRAPHITI/bin/python" ] || uv venv -p 3.12 "$PAL_VENV_GRAPHITI"
    VIRTUAL_ENV="$PAL_VENV_GRAPHITI" uv pip install -r requirements-graphiti.txt
    "$PAL_VENV_GRAPHITI/bin/python" -c "import graphiti_core, redislite, importlib.metadata as m; \
print('graphiti-core', m.version('graphiti-core'), '| falkordblite', m.version('falkordblite'))" \
        || die "Graphiti environment broken"
    echo "$H" > "$PAL_VENV_GRAPHITI/.pal-ok"
  fi

  step "6/6 weights: Qwen2.5-7B-Instruct, bge-large-en-v1.5 (from $HUB)"
  "$PAL_VENV/bin/python" scripts/fetch_models.py --hub "$HUB"
  } 2>&1 | tee "$SETUP_LOG"
  rc=${PIPESTATUS[0]}
  [ "$rc" = 0 ] || exit "$rc"
  echo; echo "setup ok (log: $SETUP_LOG)"
fi

[ "$SETUP_ONLY" = 1 ] && exit 0
[ -x "$PAL_VENV/bin/python" ] || die "no environment at $PAL_VENV; run without --skip-setup"

# The experiment itself: preflight, plumbing tests, LightRAG + Mem0, GraphRAG, report.
exec "$PAL_VENV/bin/python" scripts/real_all.py --out "$PAL_OUT" \
     --graphrag-python "$PAL_GRAPHRAG_PYTHON" --graphiti-python "$PAL_GRAPHITI_PYTHON" "${PASS[@]+"${PASS[@]}"}"
