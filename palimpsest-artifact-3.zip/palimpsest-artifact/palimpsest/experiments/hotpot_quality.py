"""Quality cost of LSED's atomize-then-render (P4) on HotpotQA (distractor, validation).

Native graph-RAG systems (GraphRAG, LightRAG) have the LLM write a free-text description of
each entity per chunk and merge an entity's descriptions with another LLM call; the merged text
has no record-level lineage. P4 instead extracts atomic facts (subject; relation; object), each
tied to its source record, and renders an entity's description from exactly its surviving facts
in a canonical order. This experiment asks what that costs in answer quality, and what deletion
then costs, on a standard multi-hop QA benchmark.

Knowledge layers (same LLM, greedy decoding, same retrieval, same answer prompt):
  native  per-paragraph entity descriptions; descriptions of the same entity merged by the LLM
  lsed    per-paragraph atomic facts; per-entity descriptions rendered from the sorted facts
Answer conditions:
  chunks             top-k retrieved paragraphs only (no knowledge layer)
  native+chunks      paragraphs and native entity descriptions
  lsed+chunks        paragraphs and LSED entity descriptions
  native_only, lsed_only   entity descriptions only (what the knowledge layer itself carries)
Deletion phase: a random share of the paragraphs is deleted. LSED re-renders the entities whose
facts changed; native either keeps its merged descriptions (native_keep, as LightRAG's default
deletion does) or re-merges the affected entities from the surviving paragraphs' cached
descriptions (native_remerge). Questions whose two supporting paragraphs survive are answered
again, and LSED's descriptions are compared with a counterfactual built without the deleted
paragraphs.

    python -m palimpsest.experiments.hotpot_quality --n-questions 300 --out results/hotpot
"""
import argparse, collections, json, os, random, re, string, time
from pathlib import Path
import numpy as np

from palimpsest.config import LLMConfig
from palimpsest.llm import LLM

EXTRACT_NATIVE = ("HOTPOT-NATIVE. Identify every named entity in the text (people, organizations, places, works, "
                  "events, and other named things). For each one, write a description of the entity based on the "
                  "text. Output one entity per line in the form: entity name | description")
MERGE_NATIVE = ("HOTPOT-MERGE. You are given several descriptions of the same entity, taken from different "
                "documents. Write one comprehensive description that combines them. Keep every fact.")
EXTRACT_ATOMS = ("HOTPOT-ATOMS. List every fact stated in the text as an atomic triple: subject; relation; object. "
                 "Use full names for entities, one fact per line, and nothing else.")
RENDER_ATOMS = ("HOTPOT-RENDER. Write a description of the entity that states every fact below and nothing else.")
ANSWER = ("HOTPOT-ANSWER. Answer the question from the context. Reply with the answer only: a short span "
          "such as a name, a date, a number, or yes or no.")


# ------------------------------------------------------------------ data
def load_hotpot(path=None, cache=Path("data/hotpot")):
    """HotpotQA distractor validation as a list of dicts {id, question, answer, type, context: [(title, text)],
    support: [titles]}. Sources, in order: --data, the HF parquet, the official JSON."""
    cache.mkdir(parents=True, exist_ok=True)
    rows = None
    if path:
        p = Path(path)
        rows = json.load(open(p)) if p.suffix == ".json" else __import__("pandas").read_parquet(p).to_dict("records")
    if rows is None:
        try:
            from huggingface_hub import hf_hub_download, list_repo_files
            files = sorted(f for f in list_repo_files("hotpotqa/hotpot_qa", repo_type="dataset")
                           if f.startswith("distractor/validation") and f.endswith(".parquet"))
            import pandas as pd
            rows = pd.concat([pd.read_parquet(hf_hub_download("hotpotqa/hotpot_qa", f, repo_type="dataset",
                                                              cache_dir=str(cache))) for f in files]).to_dict("records")
        except Exception as e:
            print(f"[hotpot] HF download failed ({e.__class__.__name__}: {str(e)[:200]}); trying the official JSON", flush=True)
    if rows is None:
        import urllib.request
        dst = cache / "hotpot_dev_distractor_v1.json"
        if not dst.exists():
            urllib.request.urlretrieve("http://curtis.ml.cmu.edu/datasets/hotpot/hotpot_dev_distractor_v1.json", dst)
        rows = json.load(open(dst))
    out = []
    for r in rows:
        ctx = r["context"]
        if isinstance(ctx, dict):                      # HF layout: {"title": [...], "sentences": [[...]]}
            pairs = list(zip(ctx["title"], ctx["sentences"]))
            sup = list(r["supporting_facts"]["title"])
        else:                                          # official layout: [[title, [sentences]]]
            pairs = [(t, s) for t, s in ctx]
            sup = [t for t, _ in r["supporting_facts"]]
        out.append({"id": r.get("id") or r.get("_id"), "question": r["question"], "answer": r["answer"],
                    "type": r.get("type"), "context": [(t, "".join(list(s))) for t, s in pairs],
                    "support": sorted(set(sup))})
    return out


# ------------------------------------------------------------------ HotpotQA metrics (official normalization)
def normalize(s):
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def f1(pred, gold):
    p, g = normalize(pred), normalize(gold)
    if p in ("yes", "no", "noanswer") or g in ("yes", "no", "noanswer"):
        return float(p == g)
    pt, gt = p.split(), g.split()
    common = collections.Counter(pt) & collections.Counter(gt)
    same = sum(common.values())
    if same == 0:
        return 0.0
    prec, rec = same / len(pt), same / len(gt)
    return 2 * prec * rec / (prec + rec)


def em(pred, gold):
    return float(normalize(pred) == normalize(gold))


def clean_answer(a):
    a = (a or "").strip().splitlines()[0] if (a or "").strip() else ""
    return re.sub(r"^(answer|final answer)\s*:\s*", "", a, flags=re.I).strip().rstrip(".")


def boot(xs, n=2000, seed=0):
    xs = np.asarray(xs, dtype=float)
    if len(xs) == 0:
        return None
    rng = np.random.default_rng(seed)
    m = xs[rng.integers(0, len(xs), (n, len(xs)))].mean(1)
    return [round(float(xs.mean()), 4), round(float(np.percentile(m, 2.5)), 4), round(float(np.percentile(m, 97.5)), 4)]


# ------------------------------------------------------------------ knowledge layers
def key(name):
    return " ".join(re.sub(r"[^\w\s]", " ", name.lower()).split())


def parse_native(out):
    res = []
    for line in out.splitlines():
        if "|" in line:
            n, d = line.split("|", 1)
            n, d = n.strip(" -*\t0123456789.").strip(), d.strip()
            if n and d and len(n) < 120:
                res.append((n, d))
    return res


def parse_atoms(out):
    res = []
    for line in out.splitlines():
        parts = [p.strip(" -*\t") for p in line.split(";")]
        if len(parts) >= 3 and parts[0] and parts[2]:
            s = re.sub(r"^\d+[.)]\s*", "", parts[0]).strip()
            if s and len(s) < 120:
                res.append((s, parts[1], ";".join(parts[2:]).strip()))
    return res


def display(names):
    """History-independent display name: most frequent surface form, ties broken lexicographically."""
    c = collections.Counter(names)
    return sorted(c, key=lambda n: (-c[n], n))[0]


class Native:
    def __init__(self, llm, extraction):            # extraction: doc -> [(name, desc)]
        self.llm, self.ex = llm, extraction
        self.desc, self.names, self.docs_of = {}, {}, collections.defaultdict(set)

    def build(self, docs):
        for d in docs:
            for n, _ in self.ex[d]:
                self.docs_of[key(n)].add(d); self.names.setdefault(key(n), []).append(n)
        return self._merge(set(self.docs_of))

    def clone(self):
        c = Native(self.llm, self.ex)
        c.desc, c.names = dict(self.desc), {k: list(v) for k, v in self.names.items()}
        c.docs_of = collections.defaultdict(set, {k: set(v) for k, v in self.docs_of.items()})
        return c

    def _merge(self, ents):
        prompts, order = [], []
        for e in sorted(ents):
            ds = [dd for d in sorted(self.docs_of.get(e, ())) for n, dd in self.ex[d] if key(n) == e]
            if not ds:
                self.desc.pop(e, None); continue
            if len(ds) == 1:
                self.desc[e] = ds[0]; continue
            order.append(e)
            prompts.append((MERGE_NATIVE, f"Entity: {display(self.names[e])}\nDescriptions:\n" + "\n".join(f"- {x}" for x in ds)))
        for e, out in zip(order, self.llm.complete_many(prompts)):
            self.desc[e] = out.strip()
        return len(prompts)

    def delete(self, docs, remerge):
        affected = set()
        for d in docs:
            for n, _ in self.ex[d]:
                e = key(n); self.docs_of[e].discard(d); affected.add(e)
        for e in affected:
            if not self.docs_of[e]:
                self.docs_of.pop(e); self.desc.pop(e, None)  # an entity no surviving document mentions
        return self._merge({e for e in affected if e in self.docs_of}) if remerge else 0

    def entities_of(self, doc):
        return [key(n) for n, _ in self.ex[doc]]


class Atomized:
    """P4: facts with provenance; descriptions rendered from exactly the surviving facts."""
    def __init__(self, llm, extraction):            # extraction: doc -> [(s, r, o)]
        self.llm, self.ex = llm, extraction
        self.facts = collections.defaultdict(set)   # entity -> {(s, r, o, doc)}
        self.names = collections.defaultdict(list)
        self.desc = {}

    def _ents(self, d):
        out = []
        for s, r, o in self.ex[d]:
            out.append((key(s), s, (s, r, o)))
            if len(o) < 120 and key(o) != key(s):    # an object that names an entity gets the fact too
                out.append((key(o), o, (s, r, o)))
        return out

    def build(self, docs):
        for d in docs:
            for e, n, f in self._ents(d):
                self.facts[e].add(f + (d,)); self.names[e].append(n)
        return self._render(set(self.facts))

    def _render(self, ents):
        order, prompts = [], []
        for e in sorted(ents):
            fs = sorted({f[:3] for f in self.facts.get(e, ())})
            if not fs:
                self.facts.pop(e, None); self.desc.pop(e, None); continue
            order.append(e)
            prompts.append((RENDER_ATOMS, f"Entity: {display(self.names[e])}\nFacts:\n" + "\n".join(f"- {s}; {r}; {o}" for s, r, o in fs)))
        for e, out in zip(order, self.llm.complete_many(prompts)):
            self.desc[e] = out.strip()
        return len(prompts)

    def delete(self, docs):
        dset, affected = set(docs), set()
        for e in list(self.facts):
            keep = {f for f in self.facts[e] if f[3] not in dset}
            if keep != self.facts[e]:
                affected.add(e); self.facts[e] = keep
                # the display name is recomputed from the surviving mentions (history independence)
                self.names[e] = [n for d in sorted({f[3] for f in keep}) for ee, n, _ in self._ents(d) if ee == e]
        return self._render(affected)

    def entities_of(self, doc):
        return [e for e, _, _ in self._ents(doc)]


# ------------------------------------------------------------------ answering
def select_entities(layer, q, top_docs, cap):
    ql = key(q)
    named = sorted({e for e in layer.desc if len(e) > 3 and f" {e} " in f" {ql} "}, key=lambda e: (-len(e), e))
    cnt = collections.Counter(e for d in top_docs for e in set(layer.entities_of(d)) if e in layer.desc)
    rest = sorted((e for e in cnt if e not in named), key=lambda e: (-cnt[e], e))
    return (named + rest)[:cap]


def contexts(q, top_docs, text, layers, cap_ents=10, cap_chars=1200):
    chunks = "\n\n".join(f"[{d}] {text[d]}" for d in top_docs)
    out = {"chunks": chunks}
    for name, layer in layers.items():
        ents = select_entities(layer, q, top_docs, cap_ents)
        g = "\n".join(f"- {display(layer.names[e])}: {layer.desc[e][:cap_chars]}" for e in ents)
        out[f"{name}+chunks"] = f"Entities:\n{g}\n\nPassages:\n{chunks}"
        out[f"{name}_only"] = f"Entities:\n{g}"
    return out


def answer_all(llm, qs, ctxs):
    """ctxs: list (per question) of {condition: context}. Returns {condition: [answers]}."""
    conds = sorted(ctxs[0]) if ctxs else []
    prompts = [(ANSWER, f"Context:\n{c[k]}\n\nQuestion: {q['question']}") for q, c in zip(qs, ctxs) for k in conds]
    outs = iter(llm.complete_many(prompts))
    res = {k: [] for k in conds}
    for _ in qs:
        for k in conds:
            res[k].append(clean_answer(next(outs)))
    return res


def score(qs, ans):
    return {k: {"em": boot([em(a, q["answer"]) for a, q in zip(v, qs)]),
                "f1": boot([f1(a, q["answer"]) for a, q in zip(v, qs)])} for k, v in ans.items()}


def paired(qs, ans, a, b):
    """Mean F1 difference a - b over the same questions, with a paired bootstrap CI."""
    return boot([f1(x, q["answer"]) - f1(y, q["answer"]) for x, y, q in zip(ans[a], ans[b], qs)])


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-questions", type=int, default=300); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--k", type=int, default=5, help="retrieved paragraphs per question")
    ap.add_argument("--delete-frac", type=float, default=0.10)
    ap.add_argument("--data", default=None, help="a local HotpotQA file (official JSON or HF parquet)")
    ap.add_argument("--concurrency", type=int, default=64)
    ap.add_argument("--out", default="results/hotpot")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True); t0 = time.time()
    from palimpsest.real import common
    llm = LLM(LLMConfig(backend="vllm", model=common.LLM_MODEL, base_url=common.LLM_BASE_URL, max_tokens=1024,
                        temperature=0.0, max_concurrency=a.concurrency, request_timeout_s=600))
    data = load_hotpot(a.data, Path(os.environ.get("PAL_DATA_DIR", "data")) / "hotpot")
    rng = random.Random(a.seed)
    qs = [data[i] for i in sorted(rng.sample(range(len(data)), min(a.n_questions, len(data))))]
    text = {}
    for q in qs:
        for t, s in q["context"]:
            text.setdefault(t, f"{t}. {s}")
    docs = sorted(text)
    print(f"[hotpot] {len(qs)} questions, {len(docs)} paragraphs", flush=True)

    emb = common.Embedder()
    dv = emb.encode([text[d] for d in docs]); qv = emb.encode([q["question"] for q in qs])
    idx = {d: i for i, d in enumerate(docs)}

    def retrieve(i, alive):
        sims = dv @ qv[i]
        order = [docs[j] for j in np.argsort(-sims) if docs[j] in alive]
        return order[:a.k]

    stats = {}
    t = time.time()
    ex_n = dict(zip(docs, map(parse_native, llm.complete_many([(EXTRACT_NATIVE, text[d]) for d in docs]))))
    stats["extract_native_s"] = round(time.time() - t, 1); t = time.time()
    ex_a = dict(zip(docs, map(parse_atoms, llm.complete_many([(EXTRACT_ATOMS, text[d]) for d in docs]))))
    stats["extract_atoms_s"] = round(time.time() - t, 1); t = time.time()
    native = Native(llm, ex_n); stats["native_merge_calls"] = native.build(docs)
    stats["native_build_s"] = round(time.time() - t, 1); t = time.time()
    lsed = Atomized(llm, ex_a); stats["lsed_render_calls"] = lsed.build(docs)
    stats["lsed_build_s"] = round(time.time() - t, 1)
    stats.update(n_questions=len(qs), n_paragraphs=len(docs), native_entities=len(native.desc), lsed_entities=len(lsed.desc),
                 native_desc_chars=int(np.mean([len(x) for x in native.desc.values()] or [0])),
                 lsed_desc_chars=int(np.mean([len(x) for x in lsed.desc.values()] or [0])),
                 lsed_facts=sum(len(v) for v in ex_a.values()),
                 paragraphs_without_facts=sum(not v for v in ex_a.values()),
                 paragraphs_without_entities=sum(not v for v in ex_n.values()))

    alive = set(docs)
    tops = [retrieve(i, alive) for i in range(len(qs))]
    recall = boot([len(set(q["support"]) & set(tp)) / len(q["support"]) for q, tp in zip(qs, tops)])
    layers = {"native": native, "lsed": lsed}
    ans = answer_all(llm, qs, [contexts(q["question"], tp, text, layers) for q, tp in zip(qs, tops)])
    before = {"scores": score(qs, ans), "support_recall_at_k": recall,
              "lsed_minus_native_f1": {"+chunks": paired(qs, ans, "lsed+chunks", "native+chunks"),
                                       "_only": paired(qs, ans, "lsed_only", "native_only")}}
    print("[hotpot] before deletion:", json.dumps(before["scores"]), flush=True)

    # ---------------- deletion
    drng = random.Random(a.seed + 1)
    gone = sorted(drng.sample(docs, int(round(a.delete_frac * len(docs)))))
    alive = set(docs) - set(gone)
    surv = [i for i, q in enumerate(qs) if all(s in alive for s in q["support"])]
    keep, remerge = native.clone(), native.clone()
    with llm.uncached():
        t = time.time(); calls = lsed.delete(gone); lsed_s = round(time.time() - t, 2)
        t = time.time(); rcalls = remerge.delete(gone, remerge=True); remerge_s = round(time.time() - t, 2)
    keep.delete(gone, remerge=False)
    cf = Atomized(llm, ex_a); cf_calls = cf.build(sorted(alive))
    same = [e for e in cf.desc if lsed.desc.get(e) == cf.desc[e]]
    sq = [qs[i] for i in surv]
    stops = [retrieve(i, alive) for i in surv]
    lay2 = {"native_keep": keep, "native_remerge": remerge, "lsed": lsed, "lsed_cf": cf}
    ans2 = answer_all(llm, sq, [contexts(q["question"], tp, text, lay2) for q, tp in zip(sq, stops)])
    after = {"deleted_paragraphs": len(gone), "surviving_questions": len(sq), "scores": score(sq, ans2),
             "lsed_minus_cf_f1": paired(sq, ans2, "lsed+chunks", "lsed_cf+chunks"),
             "lsed_vs_cf_identical_descriptions": [len(same), len(cf.desc)],
             "lsed_entity_sets_equal": sorted(lsed.desc) == sorted(cf.desc),
             "cost": {"lsed_rerender_calls": calls, "lsed_seconds": lsed_s,
                      "native_remerge_calls": rcalls, "native_remerge_seconds": remerge_s,
                      "full_rebuild_calls": len(alive) + cf_calls}}
    print("[hotpot] after deletion:", json.dumps(after["scores"]), flush=True)
    res = {"summary": {"before": before, "after": after, "build": stats},
           "args": vars(a), "llm": common.LLM_MODEL, "minutes": round((time.time() - t0) / 60, 1)}
    json.dump(res, open(out / "hotpot.json", "w"), indent=1)
    json.dump({"before": ans, "after": ans2, "questions": [q["id"] for q in qs], "surviving": surv},
              open(out / "answers.json", "w"))
    print("[hotpot]", json.dumps(res["summary"], indent=1), flush=True)


if __name__ == "__main__":
    main()
