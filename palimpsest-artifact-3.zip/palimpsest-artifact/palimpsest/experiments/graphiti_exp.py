"""Graphiti (graphiti-core 0.31.2, the temporal knowledge graph behind Zep): residue after
remove_episode, Graphiti's documented per-episode delete.

Graphiti derives three kinds of state from an episode: entity nodes with LLM summaries, entity
edges (facts with a validity interval), and communities with LLM summaries. remove_episode
deletes the episode, the edges and nodes only it mentions, and rebuilds the summaries of the
surviving nodes. Two derived artifacts are outside its reach:
  * community summaries (Tier III), rebuilt only by build_communities;
  * the validity of older edges that the episode invalidated (Tier II): a new fact that
    contradicts an old one sets the old edge's invalid_at, and nothing resets it.

Conditions, per world:
  native          remove_episode
  native_rebuild  remove_episode, then build_communities
  lsed            remove_episode, then restore the validity the episodes changed (lineage
                  recorded at add time, P1/P3), then build_communities (P3)
  counterfactual  the background graph that never saw the deleted episodes

Recovery worlds (rr): a target subject's records are added, communities are built, the records
are deleted. Zombie worlds (zp): poison records claim a new employer for an indexed person,
which invalidates the true employer edge; communities are built; the poison is deleted.

    python -m palimpsest.experiments.graphiti_exp --n-subjects 10 --parallel 6 --out results/graphiti
    python -m palimpsest.experiments.graphiti_exp --quick

Worlds run in their own processes with PAL_GRAPHITI_PYTHON (Graphiti lives in its own
virtualenv), each on its own copy of the background database.
"""
import argparse, json, os, random, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from pathlib import Path
from palimpsest.canaries import build_population, _rand_token
from palimpsest.experiments.real_systems import PROBES, PROBES_PARA, ZQ, poison_docs, frac, canaries_in

PY = os.environ.get("PAL_GRAPHITI_PYTHON", sys.executable)
M = "palimpsest.real.graphiti_world"
CONDS = ("native", "native_rebuild", "lsed")
T0 = datetime(2026, 1, 1)


def at(hours):
    return (T0 + timedelta(hours=hours)).isoformat() + "+00:00"


def run_world(wdir: Path, ops, snapshot=None, timeout_s=None):
    ops_dir = wdir.parent / "ops"; ops_dir.mkdir(parents=True, exist_ok=True)
    opf, outf = ops_dir / f"{wdir.name}.ops.json", ops_dir / f"{wdir.name}.out.json"
    json.dump(ops, open(opf, "w")); t = time.time()
    cmd = [PY, "-m", M, "--dir", str(wdir), "--ops", str(opf), "--out", str(outf)]
    if snapshot:
        cmd += ["--snapshot", str(snapshot)]
    # own process group: on a timeout the world's embedded FalkorDB (redis-server) dies with it
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    try:
        so, se = p.communicate(timeout=timeout_s)
        rc, err = p.returncode, (se or so)
    except subprocess.TimeoutExpired:
        import signal
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        so, se = p.communicate()
        rc, err = -9, f"timeout after {timeout_s}s; " + (se or "")[-1200:]
    if rc:
        (ops_dir / f"{wdir.name}.err.txt").write_text(err[-20000:])
        if outf.exists(): outf.unlink()
        return {"error": err[-1500:], "seconds": round(time.time() - t, 1)}
    o = json.load(open(outf)); o["seconds"] = round(time.time() - t, 1); return o


def ctx_texts(q):
    return [x for r in q for x in r["edges"] + r["nodes"] + r["communities"]]


def answers(q):
    return [r["answer"] for r in q]


def channel_hits(q, vals):
    """Which retrieval channel returned a deleted value: entity edges, entity summaries, communities."""
    return {ch: frac(canaries_in([x for r in q for x in r[ch]], vals), vals) for ch in ("edges", "nodes", "communities")}


def valid_share(edges, value):
    """Of the edges stating `value` (the person's true employer), the share still valid."""
    es = [e for e in edges if value.lower() in (e["fact"] or "").lower()]
    return (sum(e["invalid_at"] is None for e in es) / len(es)) if es else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-subjects", type=int, default=10); ap.add_argument("--n-background", type=int, default=10)
    ap.add_argument("--docs", type=int, default=5); ap.add_argument("--facts", type=int, default=3)
    ap.add_argument("--n-poison", type=int, default=10); ap.add_argument("--parallel", type=int, default=6)
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--out", default="results/graphiti")
    ap.add_argument("--quick", action="store_true"); ap.add_argument("--keep-worlds", action="store_true")
    ap.add_argument("--only", choices=["all", "recovery", "zombie"], default="all")
    ap.add_argument("--no-lsed", action="store_true"); ap.add_argument("--only-lsed", action="store_true")
    ap.add_argument("--world-timeout", type=int, default=3600)
    a = ap.parse_args()
    if a.no_lsed and a.only_lsed:
        sys.exit("--no-lsed and --only-lsed are mutually exclusive")
    conds = ("lsed",) if a.only_lsed else tuple(c for c in CONDS if not (a.no_lsed and c == "lsed"))
    if a.quick:
        a.n_subjects, a.n_background, a.n_poison, a.out = 1, 2, 1, a.out.rstrip("/") + "_quick"
    out = Path(a.out); base = out / "graphiti"; base.mkdir(parents=True, exist_ok=True); t0 = time.time()
    pop = build_population(a.n_subjects + a.n_background, a.docs, a.facts, seed=a.seed, subjects_per_manager=1)
    targets, bg = pop[:a.n_subjects], pop[a.n_subjects:]
    h = 0
    bg_ops = []
    for s in bg:
        for j, d in enumerate(s.docs):
            bg_ops.append({"op": "add", "tag": d.doc_id, "text": d.text, "time": at(h)}); h += 1
    t_new = h + 24                                         # records added after the background

    s0 = base / "S0"
    if not (s0 / "done").exists():
        shutil.rmtree(s0, ignore_errors=True)
        o = run_world(s0, bg_ops + [{"op": "communities"}, {"op": "edges", "tag": "bg"}], timeout_s=6 * 3600)
        if "error" in o:
            sys.exit(f"background ingestion failed: {o['error'][-800:]}")
        json.dump(o, open(s0 / "background.json", "w")); (s0 / "done").write_text("ok")
    bg_edges = json.load(open(s0 / "background.json"))["edges"]["bg"]
    snap = s0 / "graph.db"

    jobs = []
    for s in (targets if a.only != "zombie" else []):
        adds = [{"op": "add", "tag": d.doc_id, "text": d.text, "time": at(t_new + j)} for j, d in enumerate(s.docs)]
        tags, vals = [d.doc_id for d in s.docs], [f.value for f in s.all_facts()]
        for cond in conds:
            jobs.append(("rr", s.subject_id, cond, vals, adds + [
                {"op": "communities"}, {"op": "query", "tag": "live", "qs": PROBES(s)},
                {"op": "remove", "tags": tags, "mode": cond}, {"op": "scan", "tag": "after", "values": vals},
                {"op": "query", "tag": "after", "qs": PROBES(s)}, {"op": "query", "tag": "after_para", "qs": PROBES_PARA(s)}]))
    if a.only != "zombie" and not a.only_lsed:
        jobs.append(("cf", "all", "cf", None, [{"op": "query", "tag": s.subject_id, "qs": PROBES(s)} for s in targets]))

    # zombie targets: indexed background people whose current employer is a valid edge of the
    # background graph, which the poison ("<name> works at <value>") then contradicts. A person's
    # records may name several employers; Graphiti has already invalidated all but one of them,
    # and the LLM may have extracted none, so the choice is made on the built graph.
    rng = random.Random(a.seed + 7)
    ztargets = []
    for s in bg:
        cur = [f.value for f in s.all_facts() if f.kind == "employer" and valid_share(bg_edges, f.value) == 1.0]
        if cur:
            ztargets.append((s, cur[-1]))
    ztargets = ztargets[:a.n_poison]
    print(f"[graphiti] {len(ztargets)} of {len(bg)} background people have a valid employer edge: poison targets", flush=True)
    zvals = {}
    for s, true_v in (ztargets if a.only != "recovery" else []):
        fv = _rand_token(rng); zvals[s.subject_id] = (s.name, fv, true_v)
        pd_ = poison_docs(s.name, fv, n=5)
        padds = [{"op": "add", "tag": d["id"], "text": d["text"], "time": at(t_new + 48 + k)} for k, d in enumerate(pd_)]
        qs = ZQ(s.name) + [f"Where does {s.name} work?"]
        for cond in conds:
            jobs.append(("zp", s.subject_id, cond, [fv, true_v], padds + [
                {"op": "communities"}, {"op": "edges", "tag": "live"}, {"op": "query", "tag": "before", "qs": qs},
                {"op": "remove", "tags": [d["id"] for d in pd_], "mode": cond},
                {"op": "edges", "tag": "after"}, {"op": "scan", "tag": "after", "values": [fv]},
                {"op": "query", "tag": "after", "qs": qs}]))
    if a.only != "recovery" and not a.only_lsed and ztargets:
        jobs.append(("zp_cf", "all", "cf", None, [{"op": "query", "tag": s.subject_id, "qs": ZQ(s.name) + [f"Where does {s.name} work?"]}
                                                  for s, _ in ztargets]))

    def go(j):
        kind, key, cond, vals, ops = j
        w = base / "worlds" / f"{kind}_{key}_{cond}"
        done_f = base / "worlds" / "ops" / f"{w.name}.out.json"
        if done_f.exists():
            try:
                o = json.load(open(done_f)); o["resumed"] = True; return j, o
            except Exception:
                done_f.unlink()
        shutil.rmtree(w, ignore_errors=True)
        o = run_world(w, ops, snapshot=snap, timeout_s=a.world_timeout)
        if not a.keep_worlds: shutil.rmtree(w, ignore_errors=True)
        return j, o
    print(f"[graphiti] {len(jobs)} worlds on {a.parallel} workers", flush=True)
    with ThreadPoolExecutor(a.parallel) as ex:
        done = list(ex.map(go, jobs))

    mean = lambda xs: (round(sum(xs) / len(xs), 3) if xs else None)
    rows, invalid, cf = {"rr": {}, "zp": {}}, [], {}
    for (kind, key, cond, vals, ops), o in done:
        if "error" in o:
            invalid.append({"kind": kind, "key": key, "cond": cond, "why": o["error"][-300:]}); continue
        q = o["queries"]
        if kind in ("rr", "zp"):
            n_add = sum(op["op"] == "add" for op in ops)
            if sum(len(v) for v in o["adds"].values()) != n_add:
                invalid.append({"kind": kind, "key": key, "cond": cond, "why": "episodes not all added"}); continue
        if kind == "rr":
            rows["rr"].setdefault(cond, []).append({
                "subject": key, "live": frac(canaries_in(answers(q["live"]) + ctx_texts(q["live"]), vals), vals),
                "answer": frac(canaries_in(answers(q["after"]), vals), vals),
                "reword": frac(canaries_in(answers(q["after_para"]), vals), vals),
                "context": frac(canaries_in(ctx_texts(q["after"]), vals), vals),
                "live_channels": channel_hits(q["live"], vals), "after_channels": channel_hits(q["after"], vals),
                "at_rest": sorted(o["scans"]["after"]), "delete_seconds": o["timing"].get("remove"),
                "removed": o["removed"]})
        elif kind == "zp":
            fv, true_v = vals
            pre = valid_share(bg_edges, true_v)
            rows["zp"].setdefault(cond, []).append({
                "target": key,
                "before": sum(fv.lower() in x.lower() for x in answers(q["before"])) / len(q["before"]),
                "after": sum(fv.lower() in x.lower() for x in answers(q["after"])) / len(q["after"]),
                "context_after": sum(fv.lower() in x.lower() for x in ctx_texts(q["after"])) > 0,
                "true_edge_valid_pre": pre, "true_edge_valid_live": valid_share(o["edges"]["live"], true_v),
                "true_edge_valid_after": valid_share(o["edges"]["after"], true_v),
                "at_rest": sorted(o["scans"]["after"]), "delete_seconds": o["timing"].get("remove"),
                "removed": o["removed"]})
        elif kind == "cf":
            cf["recovery"] = mean([frac(canaries_in(answers(q[s.subject_id]) + ctx_texts(q[s.subject_id]),
                                                    [f.value for f in s.all_facts()]), [f.value for f in s.all_facts()]) for s in targets])
        else:
            cf["zombie"] = mean([sum(zvals[s.subject_id][1].lower() in x.lower() for x in answers(q[s.subject_id])) / len(q[s.subject_id])
                                 for s, _ in ztargets])
            cf["true_edge_valid"] = mean([v for v in (valid_share(bg_edges, tv) for _, tv in ztargets) if v is not None])

    def rr_summary(r):
        return {"n": len(r), "live": mean([x["live"] for x in r]), "answer": mean([x["answer"] for x in r]),
                "reword": mean([x["reword"] for x in r]), "context": mean([x["context"] for x in r]),
                "recovered_any": sum((x["answer"] + x["reword"] + x["context"]) > 0 for x in r),
                "channels_after": {ch: mean([x["after_channels"][ch] for x in r]) for ch in ("edges", "nodes", "communities")},
                "at_rest_stores": sorted({k for x in r for k in x["at_rest"]}),
                "delete_seconds": mean([x["delete_seconds"] for x in r if x["delete_seconds"] is not None])}

    def zp_summary(r):
        inval = [x for x in r if x["true_edge_valid_pre"] == 1.0 and x["true_edge_valid_live"] is not None
                 and x["true_edge_valid_live"] < 1.0]
        return {"n": len(r), "before": mean([x["before"] for x in r]), "after": mean([x["after"] for x in r]),
                "n_effective": sum(x["before"] > 0 for x in r),
                "after_given_effective": mean([x["after"] for x in r if x["before"] > 0]),
                "poison_in_context_after": sum(x["context_after"] for x in r),
                # the poison invalidated the true employer edge; is it valid again once the poison is gone?
                "n_invalidated": len(inval),
                "still_invalid_after": sum((x["true_edge_valid_after"] or 0) < 1.0 for x in inval),
                "at_rest_stores": sorted({k for x in r for k in x["at_rest"]}),
                "delete_seconds": mean([x["delete_seconds"] for x in r if x["delete_seconds"] is not None])}

    summ = {"recovery": {c: rr_summary(r) for c, r in rows["rr"].items()},
            "zombie": {c: zp_summary(r) for c, r in rows["zp"].items()},
            "counterfactual": cf, "invalid_worlds": invalid,
            "background": {"episodes": len(bg_ops), "edges": len(bg_edges), "people": len(bg),
                           "poison_targets": len(ztargets)},
            "label_propagation_capped": sum(bool(o.get("label_propagation_capped")) for _, o in done if "error" not in o),
            "world_seconds": {k: mean([o.get("seconds") for (kk, *_), o in done if kk == k and o.get("seconds")])
                              for k in ("rr", "zp")},
            "background_minutes": json.load(open(s0 / "background.json")).get("seconds", 0) / 60}
    try:
        ver = subprocess.run([PY, "-c", "import importlib.metadata as m; print(m.version('graphiti-core'))"],
                             capture_output=True, text=True).stdout.strip()
    except Exception:
        ver = None
    json.dump({"summary": summ, "rows": rows}, open(out / "graphiti.json", "w"), indent=1)
    json.dump({"graphiti_core": ver, "args": vars(a), "llm": os.environ.get("PAL_LLM_MODEL"),
               "minutes": round((time.time() - t0) / 60, 1)}, open(out / "meta.json", "w"), indent=1)
    print("[graphiti]", json.dumps(summ, indent=1), flush=True)


if __name__ == "__main__":
    main()
