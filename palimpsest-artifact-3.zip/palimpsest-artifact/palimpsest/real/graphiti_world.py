"""One world of Graphiti (graphiti-core, Zep's temporal knowledge graph), driven through its
public API on an embedded FalkorDB. Runs in the Graphiti environment (requirements-graphiti.txt).

    python -m palimpsest.real.graphiti_world --dir W --ops ops.json --out out.json [--snapshot S]

The world's database is W/graph.db; --snapshot copies a saved database there first.

Ops (executed in order):
  {"op": "add", "tag": t, "text": ..., "time": ISO}   add_episode; records its lineage (below)
  {"op": "communities"}                              build_communities (rebuilds all communities)
  {"op": "remove", "tags": [...], "mode": m}         delete the episodes added under these tags
      m = "native": Graphiti's remove_episode, as documented
      m = "native_rebuild": remove_episode, then build_communities (an operator who also
                    refreshes the communities after a deletion)
      m = "lsed":   remove_episode, then restore the validity of every edge those episodes
                    invalidated (lineage recorded at add time, P1; recomputation, P3), then
                    rebuild the communities (P3), so no artifact keeps the deleted episodes' effect
  {"op": "query", "tag": t, "qs": [...]}             Graphiti search (edges, entities, communities), and
                                                     the LLM's answer from those results
  {"op": "edges", "tag": t}                          every entity edge: fact and validity
  {"op": "scan", "tag": t, "values": [...]}          which stores hold any of the values at rest

Lineage (P1): every add_episode is preceded and followed by a snapshot of the edges' validity
(invalid_at, expired_at). The edges an episode invalidated, with their previous validity, are
its lineage; Graphiti itself records only which edges an episode created or touched.
"""
import argparse, asyncio, json, os, shutil, time, warnings
from datetime import datetime
from pathlib import Path

os.environ.setdefault("GRAPHITI_TELEMETRY_ENABLED", "false")
warnings.filterwarnings("ignore")

GROUP = "palimpsest"


LP_ROUNDS = 100
LP_CAPPED = []


def install_label_propagation_cap():
    """graphiti-core 0.31.2 detects communities with synchronous label propagation that loops
    until no label changes. It never terminates when labels oscillate: two entities joined by two
    or more edges and nothing else swap labels on every round (a person and the organization
    that several poison records tie them to). The copy below is the same algorithm with a cap of
    LP_ROUNDS rounds; where Graphiti's converges, the result is identical."""
    from collections import defaultdict
    import graphiti_core.driver.operations.graph_utils as gu
    import graphiti_core.utils.maintenance.community_operations as co
    import graphiti_core.driver.falkordb.operations.graph_ops as fg

    def label_propagation(projection):
        community_map = {uuid: i for i, uuid in enumerate(projection.keys())}
        for _ in range(LP_ROUNDS):
            no_change, new_map = True, {}
            for uuid, neighbors in projection.items():
                curr = community_map[uuid]
                cand = defaultdict(int)
                for nb in neighbors:
                    cand[community_map[nb.node_uuid]] += nb.edge_count
                lst = sorted(((c, k) for k, c in cand.items()), reverse=True)
                rank, best = lst[0] if lst else (0, -1)
                new = best if best != -1 and rank > 1 else max(best, curr)
                new_map[uuid] = new
                no_change &= new == curr
            if no_change:
                break
            community_map = new_map
        else:
            LP_CAPPED.append(len(projection))
        clusters = defaultdict(list)
        for uuid, c in community_map.items():
            clusters[c].append(uuid)
        return list(clusters.values())

    gu.label_propagation = co.label_propagation = fg.label_propagation = label_propagation


def make_graphiti(db_path: Path):
    from falkordb.asyncio import FalkorDB as AsyncFalkor
    from redislite.falkordb_client import FalkorDB as EmbeddedFalkor
    from graphiti_core import Graphiti
    from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
    from graphiti_core.driver.falkordb_driver import FalkorDriver
    from graphiti_core.embedder.openai import OpenAIEmbedder, OpenAIEmbedderConfig
    from graphiti_core.llm_client.config import LLMConfig
    from graphiti_core.llm_client.openai_generic_client import OpenAIGenericClient

    server = EmbeddedFalkor(str(db_path))
    llm_url, model = os.environ["PAL_LLM_BASE_URL"], os.environ.get("PAL_LLM_MODEL", "stub")
    emb_url = os.environ.get("PAL_EMB_BASE_URL", llm_url)
    # OpenAIGenericClient ignores LLMConfig.max_tokens and uses its own argument (default 16384),
    # so the cap is passed there; 16384 is what every reported run used
    max_tokens = int(os.environ.get("PAL_GRAPHITI_MAX_TOKENS", "16384"))
    cfg = LLMConfig(api_key="none", base_url=llm_url, model=model, small_model=model,
                    temperature=0.0, max_tokens=max_tokens)
    g = Graphiti(
        # Graphiti maps a group_id to a FalkorDB graph of the same name
        graph_driver=FalkorDriver(falkor_db=AsyncFalkor(unix_socket_path=server.client.socket_file), database=GROUP),
        llm_client=OpenAIGenericClient(cfg, max_tokens=max_tokens),
        embedder=OpenAIEmbedder(OpenAIEmbedderConfig(api_key="none", base_url=emb_url,
                                                     embedding_model=os.environ.get("PAL_EMB_MODEL_NAME", "bge"),
                                                     embedding_dim=int(os.environ.get("PAL_EMB_DIM", "1024")))),
        # only the RRF search recipes are used, so the reranker is never called
        cross_encoder=OpenAIRerankerClient(config=cfg))
    return g, server


async def rows(g, cypher):
    r, *_ = await g.driver.execute_query(cypher)
    return r


async def validity(g) -> dict:
    """uuid -> (fact, invalid_at, expired_at) for every entity edge."""
    out = {}
    for x in await rows(g, "MATCH ()-[e:RELATES_TO]->() RETURN e.uuid AS u, e.fact AS f, "
                           "e.invalid_at AS inv, e.expired_at AS exp"):
        out[x["u"]] = (x["f"], x["inv"], x["exp"])
    return out


async def restore_validity(g, changes: dict) -> int:
    """Set each edge's invalid_at/expired_at back to the recorded values (LSED, P3). Only these two
    properties change (the edge's embedding and episodes are untouched); FalkorDB stores Graphiti's
    datetimes as ISO strings, as recorded."""
    n = 0
    for uuid, (inv, exp) in changes.items():
        r = await rows(g, f"MATCH ()-[e:RELATES_TO {{uuid: '{uuid}'}}]->() "
                          f"SET e.invalid_at = {_lit(inv)}, e.expired_at = {_lit(exp)} RETURN count(e) AS c")
        n += r[0]["c"] if r else 0                     # 0: removed together with the episode
    return n


def _lit(v):
    return "null" if v is None else json.dumps(str(v))


def iso(v):
    if v is None:
        return None
    return v.isoformat() if hasattr(v, "isoformat") else str(v)


async def search_text(g, q) -> dict:
    from graphiti_core.search.search_config_recipes import COMBINED_HYBRID_SEARCH_RRF
    r = await g.search_(q, config=COMBINED_HYBRID_SEARCH_RRF, group_ids=[GROUP])
    return {"edges": [f"{e.fact} [valid_at={iso(e.valid_at)}; invalid_at={iso(e.invalid_at)}]" for e in r.edges],
            "nodes": [f"{n.name}: {n.summary}" for n in r.nodes],
            "communities": [f"{c.name}: {c.summary}" for c in r.communities],
            "episodes": [e.content for e in r.episodes]}


def answer(q, ctx) -> str:
    """What a client application does with Graphiti's results: put them in the prompt, ask the LLM."""
    import httpx
    facts = "\n".join(ctx["edges"] + ctx["nodes"] + ctx["communities"])
    body = {"model": os.environ.get("PAL_LLM_MODEL", "stub"), "temperature": 0.0, "max_tokens": 512,
            "messages": [{"role": "system", "content": "Answer the question using only these facts from memory.\n" + facts},
                         {"role": "user", "content": q}]}
    r = httpx.post(os.environ["PAL_LLM_BASE_URL"].rstrip("/") + "/chat/completions", json=body, timeout=600)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"] or ""


async def scan(g, values) -> dict:
    vals = [v.lower() for v in values]
    stores = {
        "entity_summaries": "MATCH (n:Entity) RETURN n.name + ' ' + coalesce(n.summary, '') AS t",
        "entity_edges": "MATCH ()-[e:RELATES_TO]->() RETURN coalesce(e.fact, '') AS t",
        "community_summaries": "MATCH (c:Community) RETURN coalesce(c.name, '') + ' ' + coalesce(c.summary, '') AS t",
        "episodes": "MATCH (e:Episodic) RETURN coalesce(e.content, '') AS t",
    }
    hits = {}
    for name, q in stores.items():
        found = sorted({v for x in await rows(g, q) for v in vals if v in (x["t"] or "").lower()})
        if found:
            hits[name] = found
    return hits


async def main_async(a):
    w = Path(a.dir); w.mkdir(parents=True, exist_ok=True)
    db = w / "graph.db"
    if a.snapshot and not db.exists():
        shutil.copy2(a.snapshot, db)
    install_label_propagation_cap()
    g, server = make_graphiti(db)
    await g.build_indices_and_constraints()
    out = {"adds": {}, "queries": {}, "edges": {}, "scans": {}, "removed": {}, "timing": {}}
    # tag -> {"episodes": [...], "invalidated": {uuid: (inv, exp)}}; kept next to the database,
    # so a world started from a snapshot inherits the lineage of the snapshot's episodes
    lin_f = w / "lineage.json"
    if a.snapshot and not lin_f.exists() and (Path(a.snapshot).parent / "lineage.json").exists():
        shutil.copy2(Path(a.snapshot).parent / "lineage.json", lin_f)
    lineage = json.load(open(lin_f)) if lin_f.exists() else {}
    try:
        for op in json.load(open(a.ops)):
            t0 = time.time()
            if op["op"] == "add":
                before = await validity(g)
                r = await g.add_episode(name=op["tag"], episode_body=op["text"], source_description="record",
                                        reference_time=datetime.fromisoformat(op["time"]), group_id=GROUP)
                after = await validity(g)
                inval = {u: (iso(before[u][1]), iso(before[u][2])) for u in before
                         if u in after and (before[u][1], before[u][2]) != (after[u][1], after[u][2])}
                lin = lineage.setdefault(op["tag"], {"episodes": [], "invalidated": {}})
                lin["episodes"].append(r.episode.uuid)
                for u, prev in inval.items():
                    lin["invalidated"].setdefault(u, prev)  # keep the state before the first invalidation
                out["adds"].setdefault(op["tag"], []).append(
                    {"episode": r.episode.uuid, "nodes": len(r.nodes), "edges": len(r.edges), "invalidated": len(inval)})
            elif op["op"] == "communities":
                c = await g.build_communities(group_ids=[GROUP])
                out["communities"] = len(c[0])
            elif op["op"] == "remove":
                eps = [e for t in op["tags"] for e in lineage.get(t, {}).get("episodes", [])]
                for e in eps:
                    await g.remove_episode(e)
                rec = {"episodes": len(eps)}
                if op["mode"] == "lsed":
                    keep = {t for t in lineage if t not in op["tags"]}
                    # an edge that a remaining episode also invalidated stays invalid
                    still = {u for t in keep for u in lineage[t]["invalidated"]}
                    changes = {u: prev for t in op["tags"] for u, prev in lineage.get(t, {}).get("invalidated", {}).items()
                               if u not in still}
                    rec["restored_edges"] = await restore_validity(g, changes)
                    c = await g.build_communities(group_ids=[GROUP])
                    rec["communities_rebuilt"] = len(c[0])
                elif op["mode"] == "native_rebuild":
                    c = await g.build_communities(group_ids=[GROUP])
                    rec["communities_rebuilt"] = len(c[0])
                for t in op["tags"]:
                    lineage.pop(t, None)
                out["removed"][",".join(op["tags"])] = rec
            elif op["op"] == "query":
                res = []
                for q in op["qs"]:
                    ctx = await search_text(g, q)
                    ctx["answer"] = answer(q, ctx)
                    res.append(ctx)
                out["queries"][op["tag"]] = res
            elif op["op"] == "edges":
                out["edges"][op["tag"]] = [{"uuid": u, "fact": f, "invalid_at": iso(i), "expired_at": iso(x)}
                                           for u, (f, i, x) in (await validity(g)).items()]
            elif op["op"] == "scan":
                out["scans"][op["tag"]] = await scan(g, op["values"])
            out["timing"].setdefault(op["op"], 0.0)
            out["timing"][op["op"]] += round(time.time() - t0, 3)
    finally:
        out["label_propagation_capped"] = LP_CAPPED
        json.dump(lineage, open(lin_f, "w"))
        await g.close()
        try:
            server.client.save()                          # graph.db must be complete for a snapshot copy
            server.client.shutdown(save=True, now=True, force=True)
        except Exception:
            pass
    json.dump(out, open(a.out, "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True); ap.add_argument("--ops", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--snapshot", default=None, help="a saved graph.db to start from")
    a = ap.parse_args()
    asyncio.run(main_async(a))


if __name__ == "__main__":
    main()
