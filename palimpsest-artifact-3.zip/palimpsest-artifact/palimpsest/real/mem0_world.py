"""One Mem0 world, driven through Mem0's own API, in its own process.

    python -m palimpsest.real.mem0_world --dir W --ops ops.json --out out.json

Operations, executed in order:
  {"op": "add", "tag": ..., "user_id": ..., "text": ...}           # one user message
  {"op": "delete_from_add", "tags": [...], "erase": bool}   # delete exactly the memories those add() calls returned
  {"op": "delete_all", "user_id": ..., "erase": bool}       # Mem0's documented per-user erasure
      erase (LSED): delete_from_add follows full lineage (P1). Every add() records the
      message-log rows it wrote and the rows its extraction prompt showed the LLM (Mem0
      includes the session's last ten messages), so a later add() whose prompt contained a
      deleted conversation depends on it. The deletion removes the memories, message rows,
      and history rows of the deleted add() and of every dependent add() (P5), then replays
      the dependent add() calls in order, recomputing exactly the affected memories (P3).
      delete_all with erase also removes the user's session rows and history rows.
  {"op": "get_all", "tag": ..., "user_id": ...}
  {"op": "search", "tag": ..., "user_id": ..., "qs": [...]}
  {"op": "scan", "tag": ..., "values": [...]}  # logical at-rest scan of every Mem0 store
  {"op": "last_messages", "tag": ..., "user_id": ...}  # the session context the next add() sends to the LLM
"""
import argparse, json, os, sys
from pathlib import Path
os.environ.setdefault("MEM0_TELEMETRY", "False")          # no experiment data leaves the machine
from palimpsest.real import common


class _FakeEmb:                                          # tests only
    def __init__(self):
        self.e = common.Embedder()

    def embed(self, text, memory_action=None):
        return self.e.encode([text])[0].tolist()

    def embed_batch(self, texts, memory_action=None):
        return [v.tolist() for v in self.e.encode(texts)]


def make_memory(workdir: Path):
    from mem0 import Memory
    cfg = {
        "vector_store": {"provider": "qdrant", "config": {"path": str(workdir / "qdrant"), "on_disk": True,
                                                          "collection_name": "mem", "embedding_model_dims": common.EMB_DIM}},
        "llm": {"provider": "openai", "config": {"model": common.LLM_MODEL, "openai_base_url": common.LLM_BASE_URL,
                                                 "api_key": "EMPTY", "temperature": 0.0, "max_tokens": 1500}},
        "embedder": {"provider": "huggingface", "config": {"model": common.EMB_MODEL, "embedding_dims": common.EMB_DIM}},
        "history_db_path": str(workdir / "history.db"),
    }
    if common.FAKE_EMBED:
        cfg["embedder"] = {"provider": "openai", "config": {"api_key": "unused", "embedding_dims": common.EMB_DIM}}
    m = Memory.from_config(cfg)
    if common.FAKE_EMBED:
        m.embedding_model = _FakeEmb()
    return m


def memories_of(m, user_id):
    res = m.get_all(filters={"user_id": user_id}, top_k=1000)
    items = res.get("results", res) if isinstance(res, dict) else res
    return [it.get("memory", "") for it in items]


def _items(r):
    return r.get("results", r) if isinstance(r, dict) else r


def erase(m, message_ids=(), session_scope=None, memory_ids=()) -> dict:
    """LSED erasure (P5) of what Mem0's deletion leaves: message-log rows (by the lineage the
    world recorded, or a whole session) and every history row of the deleted memories,
    including the DELETE events Mem0 itself writes (they carry the deleted text)."""
    con = m.db.connection
    n = {"messages": 0, "history": 0}
    with m.db._lock:
        con.execute("BEGIN")
        for i in message_ids:
            n["messages"] += con.execute("DELETE FROM messages WHERE id = ?", (i,)).rowcount
        if session_scope is not None:
            n["messages"] += con.execute("DELETE FROM messages WHERE session_scope = ?", (session_scope,)).rowcount
        for i in memory_ids:
            n["history"] += con.execute("DELETE FROM history WHERE memory_id = ?", (i,)).rowcount
        con.execute("COMMIT")
    return n


def scan(m, values) -> dict:
    """Logical scan (rows and payloads as stored, not deleted free pages)."""
    hits = {}
    con = m.db.connection
    hist = " ".join(f"{a or ''} {b or ''}" for a, b in con.execute("SELECT old_memory, new_memory FROM history"))
    msgs = " ".join(r[0] or "" for r in con.execute("SELECT content FROM messages"))
    pts, off = [], None
    while True:
        batch, off = m.vector_store.client.scroll(collection_name="mem", limit=256, offset=off, with_payload=True)
        pts += batch
        if off is None:
            break
    vec = " ".join(json.dumps(p.payload) for p in pts)
    for name, text in (("history_table", hist), ("messages_table", msgs), ("vector_payloads", vec)):
        found = common.find_values(text, values)
        if found:
            hits[name] = found
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True); ap.add_argument("--ops", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    Path(a.dir).mkdir(parents=True, exist_ok=True)
    m = make_memory(Path(a.dir))
    out = {"adds": {}, "get_all": {}, "search": {}, "scans": {}, "deleted": [], "erased": {}}
    con = m.db.connection
    msg_ids = lambda: {r[0] for r in con.execute("SELECT id FROM messages")}
    lineage = {}            # add() tag -> {"wrote": rows, "saw": rows in its prompt, "op": the add} (P1)
    order = []              # add() tags in execution order
    from mem0.memory.main import _build_session_scope

    def do_add(op):
        scope = _build_session_scope({"user_id": op["user_id"]})
        saw = [r[0] for r in con.execute("SELECT id FROM messages WHERE session_scope = ? "
                                         "ORDER BY created_at DESC LIMIT 10", (scope,))]
        before = msg_ids()
        r = m.add([{"role": "user", "content": op["text"]}], user_id=op["user_id"])
        lineage[op["tag"]] = {"wrote": sorted(msg_ids() - before), "saw": saw, "op": op}
        if op["tag"] not in order:
            order.append(op["tag"])
        out["adds"][op["tag"]] = [{"id": it.get("id"), "event": it.get("event"), "memory": it.get("memory")}
                                  for it in _items(r)]

    def produced(tag):
        return [it["id"] for it in out["adds"].get(tag, []) if it["id"] and it["event"] in ("ADD", "UPDATE")]

    for op in common.timed(json.load(open(a.ops)), out):
        if op["op"] == "add":
            do_add(op)
        elif op["op"] == "delete_from_add" and op.get("erase"):
            # LSED: the deleted add() calls and every later add() whose prompt showed their rows
            gone = {x for t in op["tags"] for x in lineage[t]["wrote"]}
            dependent = [t for t in order if t not in op["tags"]
                         and order.index(t) > min(order.index(x) for x in op["tags"]) and gone & set(lineage[t]["saw"])]
            ids = [i for t in op["tags"] + dependent for i in produced(t)]
            for i in ids:
                try:
                    m.delete(i)
                except Exception:                          # already removed by an earlier delete/update
                    pass
            rows = [x for t in op["tags"] + dependent for x in lineage[t]["wrote"]]
            out["erased"][",".join(op["tags"])] = erase(m, message_ids=rows, memory_ids=ids) | {"dependent": dependent}
            out["deleted"] += ids
            for t in op["tags"]:
                order.remove(t)
            for t in dependent:                            # recompute the affected memories, in order
                do_add(lineage[t]["op"])
        elif op["op"] == "delete_from_add":
            for t in op["tags"]:
                for it in out["adds"].get(t, []):
                    if it["id"] and it["event"] in ("ADD", "UPDATE"):
                        m.delete(it["id"]); out["deleted"].append(it["id"])
        elif op["op"] == "delete_all":
            ids = [it.get("id") for it in _items(m.get_all(filters={"user_id": op["user_id"]}, top_k=1000))]
            m.delete_all(user_id=op["user_id"])
            if op.get("erase"):
                out["erased"][op["user_id"]] = erase(m, session_scope=_build_session_scope({"user_id": op["user_id"]}),
                                                     memory_ids=[i for i in ids if i])
        elif op["op"] == "get_all":
            out["get_all"][op["tag"]] = memories_of(m, op["user_id"])
        elif op["op"] == "search":
            res = []
            for q in op["qs"]:
                r = m.search(q, filters={"user_id": op["user_id"]}, top_k=20)
                items = r.get("results", r) if isinstance(r, dict) else r
                res.append([it.get("memory", "") for it in items])
            out["search"][op["tag"]] = res
        elif op["op"] == "scan":
            out["scans"][op["tag"]] = scan(m, op["values"])
        elif op["op"] == "last_messages":                 # what the next add() will show the LLM
            from mem0.memory.main import _build_session_scope
            msgs = m.db.get_last_messages(_build_session_scope({"user_id": op["user_id"]}), limit=10)
            out.setdefault("last_messages", {})[op["tag"]] = [x.get("content", "") if isinstance(x, dict) else str(x) for x in msgs]
    json.dump(out, open(a.out, "w"), indent=1)
    try:
        m.vector_store.client.close()
    except Exception:
        pass


if __name__ == "__main__":
    sys.exit(main())
