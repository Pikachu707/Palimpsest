# Results behind the paper

Raw results and logs of every run reported in the paper. Each directory has the layout of a
fresh run's output, so the repository's report scripts read it directly.

| Directory | Paper | Hardware |
|---|---|---|
| `results/final/`, `results/final_onesent/`, `results/di_*` | Sections 7.2 to 7.7, Figures 4 to 6, Table 3 | one NVIDIA B300 |
| `results/be_<tag>/`, `results/be_<tag>_onesent/` | Table 4 (LLM-backend sweep; `be_qwen7b_repro` is Qwen2.5-7B on the sweep machine) | a second B300 |
| `real/`, `real2/` | Table 5, Appendix H: LightRAG and Mem0 (`real2/`, one manager per subject, is reported) | one NVIDIA H100 |
| `graphrag/` | Table 5, Appendix H: GraphRAG recovery (see `graphrag/README.md`) | one H100 |
| `zombie_rerun/` | Table 5, Appendix H: GraphRAG and Mem0 zombie poisoning | one H100 |
| `a100/table5/` | Table 5 in parentheses and the shaded LSED row: LightRAG, Mem0, and GraphRAG with and without LSED | one NVIDIA A100 |
| `a100/followup/` | Table 5, Graphiti row; Appendix H: Graphiti, HotpotQA, deletion latency, confidence intervals | one A100 |
| `logs/main/`, `logs/backends/` | run logs of `results/`, including each vLLM server log | |

Every number in the paper can be regenerated from these files without a GPU:

```bash
python paper_figures/make_final_figures.py --results paper_results/results --outdir figures   # Figures 4 to 6
python -m palimpsest.report.backend_table --results paper_results/results                      # Table 4
python scripts/report_real.py --paper                                  # Table 5, H100 values (19 cells)
python scripts/report_real.py --run paper_results/a100/table5          # Table 5, A100 values and LSED
python scripts/report_extra.py --run paper_results/a100/followup       # Graphiti, HotpotQA, latency
python scripts/bootstrap_ci.py --paper                                 # 95% intervals for Table 5 (H100)
```

The Qwen2.5-7B run on the sweep machine matches the B300 runs on every deletion outcome and
differs only in MiniGraphRAG zombie success (50% vs. 60%): greedy decoding under another software
stack extracts some poisoned documents differently (Table 4, footnote).

`a100/followup/graphiti/graphiti/worlds/ops/*.err.txt` are the six excluded Graphiti worlds: for two
poison targets, Qwen2.5-7B returned malformed JSON to one of Graphiti's structured calls under
every condition. Per-world files of the other runs are under each run's `ops/` or `worlds/ops/`.
Snapshots of the background indexes are not included; every run rebuilds them.
