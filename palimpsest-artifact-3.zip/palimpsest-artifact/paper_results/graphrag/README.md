# Microsoft GraphRAG 3.2.0: residue recovery (Table 5)

* `run2/`: the reported run (32 worlds, all valid; 40 minutes on one NVIDIA H100). Community
  reports use a frequency penalty of 0.3, and every completion is capped at 4,096 tokens, so that
  every report terminates.
* `run1/ops/`: the same experiment without those two settings. All 20 recovery worlds completed
  and agree with `run2/`; 4 zombie worlds never terminated (a community report looped under
  greedy decoding) and are recorded as errors.

GraphRAG's indexing is not deterministic across runs (concurrent LLM calls), so each world is
compared with itself before deletion.

The zombie worlds in both runs poison the managers of target subjects, who are absent from a zombie
world's corpus. Local search maps a question to entities by embedding similarity and never
retrieved these managers (0% success before deletion), so these worlds measure nothing. Table 5's
GraphRAG zombie numbers come from `../zombie_rerun/graphrag_zombie/`, which poisons indexed
subjects.
