# Real-system evaluation (paper profile)

## Table 5

Deleted canary facts a client recovers, and zombie-poisoning success after deletion (%). Paper values in parentheses. Mem0 cells: next message unrelated / referring back.

| System and deletion | Repeat | Reword | Zombie | At rest |
|---|---|---|---|---|
| GraphRAG 3.2.0, incremental update | 86 (77) | 80 (69) | 83 (90), 8/10 reached | cache, output/community_reports.parquet, output/documents.parquet, output/entities.parquet, output/relationships.parquet, output/text_units.parquet, update_output |
| GraphRAG 3.2.0, full re-index | 0 (0) | 0 (0) | 0 (0), 8/10 reached | cache, update_output |
| GraphRAG + LSED (P1, P5) | 0 | 0 | 0, 7/10 reached | **none** |
| LightRAG 1.5.7, `adelete_by_doc_id` | 97 (99) | 0 (0) | 100 (100) | kv_store_llm_response_cache.json |
| LightRAG 1.5.7, `+ delete_llm_cache` | 98 (98) | 0 (0) | 100 (100) | kv_store_llm_response_cache.json |
| LightRAG 1.5.7, extraction cache off | 98 | 0 | n/a | kv_store_llm_response_cache.json |
| LightRAG + LSED (P5) | 0 | 0 | 0 | **none** |
| Mem0 2.2.1, one `add()`'s memories | 2 (2) | | 0 (0) / 30 (30) | history_table, messages_table, vector_payloads |
| Mem0 + LSED, one `add()` (P1, P5) | 0 | | 0 / 0 | **none** |
| Mem0 2.2.1, `delete_all` | 0 (0) / 96 (90) | | 0 (0) / 90 (90) | history_table, messages_table |
| Mem0 + LSED, `delete_all` (P1, P5) | 0 / 0 | | 0 / 0 | **none** |

Counterfactual worlds (never held the data): graphrag recovery 0, graphrag zombie 0, lightrag answer (cache) 0, lightrag context (cache) 0, lightrag answer (nocache) 0, lightrag zombie 0, mem0 lineage 0, mem0 user 0, mem0 zombie (ref) 0, mem0 zombie (neutral) 0.

## Claims

R/G/L/M: the paper's findings; S: LSED applied to the real systems.

| | Claim | Result | |
|---|---|---|---|
| R0 | every world valid (all documents indexed) | PASS | model-independent |
| R1 | no counterfactual world ever returns a deleted fact or the poison | PASS | model-independent |
| G1 | GraphRAG incremental update leaves every deleted document indexed | PASS | model-independent |
| G2 | GraphRAG full re-index removes them from the index | PASS | model-independent |
| G3 | GraphRAG update: clients still recover deleted facts (>= 50%) | PASS |  |
| G4 | GraphRAG re-index: clients recover nothing | PASS |  |
| L1 | LightRAG: a repeated question returns the deleted facts from the answer cache (>= 90%), both options | PASS |  |
| L2 | LightRAG: reworded questions and retrieved context recover nothing (entities are re-derived, M1 closed) | PASS |  |
| L3 | LightRAG: deleted poison stays fully effective through the cache | PASS |  |
| M1 | Mem0 delete_all hides every memory from clients | PASS | model-independent |
| M2 | Mem0: the deleted conversation is in the next extraction prompt, every world | PASS | model-independent |
| M3 | Mem0: a referring-back message revives deleted poison after delete_all (>= 50%) | PASS |  |
| M4 | Mem0: an unrelated message revives nothing | PASS |  |
| S1 | GraphRAG + LSED: deleted documents leave the index and no store holds a deleted fact | PASS | model-independent |
| S2 | GraphRAG + LSED: clients recover nothing and deleted poison has no effect | PASS | model-independent |
| S3 | LightRAG + LSED: no repeated, reworded, or context recovery, no zombie, nothing at rest | PASS | model-independent |
| S4 | Mem0 + LSED: the deleted conversation is not in the next extraction prompt | PASS | model-independent |
| S5 | Mem0 + LSED: no follow-up message revives deleted facts or poison, and nothing is at rest | PASS | model-independent |

## Numbers vs. the paper (tolerance 15 pp)

19 of 19 cells match.


## Inputs

* `lightrag`: `/workspace/palimpsest-artifact/results/real_eval/real/lightrag.json`
* `mem0`: `/workspace/palimpsest-artifact/results/real_eval/real/mem0.json`
* `mem0_zombie`: `/workspace/palimpsest-artifact/results/real_eval/real/mem0_zombie.json`
* `mem0_zombie_meta`: `/workspace/palimpsest-artifact/results/real_eval/real/meta.json`
* `graphrag`: `/workspace/palimpsest-artifact/results/real_eval/graphrag/graphrag.json`
* `graphrag_zombie`: `/workspace/palimpsest-artifact/results/real_eval/graphrag/graphrag.json`
* `lightrag_lsed`: `/workspace/palimpsest-artifact/results/real_eval/real_lsed/lightrag.json` (LSED conditions, merged)
* `mem0_lsed`: `/workspace/palimpsest-artifact/results/real_eval/real_lsed/mem0.json` (LSED conditions, merged)
* `mem0_zombie_lsed`: `/workspace/palimpsest-artifact/results/real_eval/real_lsed/mem0_zombie.json` (LSED conditions, merged)
* `graphrag_lsed`: `/workspace/palimpsest-artifact/results/real_eval/graphrag_lsed/graphrag.json` (LSED conditions, merged)
