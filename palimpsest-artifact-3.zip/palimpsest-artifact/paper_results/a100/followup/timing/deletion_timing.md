| System | Condition | Worlds | Median (s) | p90 (s) | Max (s) |
|---|---|---:|---:|---:|---:|
| graphiti | lsed | 14 | 46.97 | 60.09 | 64.81 |
| graphiti | native | 14 | 13.71 | 24.79 | 30.6 |
| graphiti | native_rebuild | 14 | 48.08 | 59.01 | 60.44 |
| graphrag | lsed | 2 | 47.88 | 48.1 | 48.1 |
| graphrag | reindex | 2 | 48.7 | 50.57 | 50.57 |
| graphrag | update | 2 | 66.27 | 68.35 | 68.35 |
| lightrag | default | 8 | 3.74 | 4.35 | 4.35 |
| lightrag | lsed | 8 | 4.36 | 4.71 | 4.71 |
| lightrag | nocache | 5 | 3.62 | 3.78 | 3.78 |
| lightrag | thorough | 8 | 4.35 | 4.61 | 4.61 |
| mem0 | lineage | 5 | 0.01 | 0.01 | 0.01 |
| mem0 | lineage_lsed | 5 | 3.12 | 4.31 | 4.31 |
| mem0 | user | 5 | 0.04 | 0.05 | 0.05 |
| mem0 | user_lsed | 5 | 0.04 | 0.06 | 0.06 |
| mem0_zombie | lineage | 6 | 0.0 | 0.01 | 0.01 |
| mem0_zombie | lineage_lsed | 6 | 4.26 | 4.98 | 4.98 |
| mem0_zombie | user | 6 | 0.03 | 0.04 | 0.04 |
| mem0_zombie | user_lsed | 6 | 0.04 | 0.04 | 0.04 |
