| System | Condition | Cell | Worlds | Mean (%) | 95% CI (%) |
|---|---|---|---:|---:|---|
| graphrag | update | repeat | 10 | 86 | [66, 97] |
| graphrag | update | reword | 10 | 80 | [60, 93] |
| graphrag | update | zombie (reached) | 8 | 83 | [67, 96] |
| graphrag | reindex | repeat | 10 | 0 | [0, 26] (exact) |
| graphrag | reindex | reword | 10 | 0 | [0, 26] (exact) |
| graphrag | reindex | zombie (reached) | 8 | 0 | [0, 31] (exact) |
| graphrag | lsed | repeat | 10 | 0 | [0, 26] (exact) |
| graphrag | lsed | reword | 10 | 0 | [0, 26] (exact) |
| graphrag | lsed | zombie (reached) | 7 | 0 | [0, 35] (exact) |
| lightrag | default | repeat | 20 | 97 | [94, 99] |
| lightrag | default | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | default | context | 20 | 0 | [0, 14] (exact) |
| lightrag | default | zombie | 10 | 100 | [74, 100] (exact) |
| lightrag | thorough | repeat | 20 | 98 | [96, 99] |
| lightrag | thorough | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | thorough | context | 20 | 0 | [0, 14] (exact) |
| lightrag | thorough | zombie | 10 | 100 | [74, 100] (exact) |
| lightrag | nocache | repeat | 20 | 98 | [96, 99] |
| lightrag | nocache | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | nocache | context | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | repeat | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | context | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | zombie | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage | repeat | 20 | 2 | [0, 5] |
| mem0 | lineage | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage | benign kept (neutral) | 10 | 96 | [93, 99] |
| mem0 | lineage | zombie (ref) | 10 | 30 | [0, 60] |
| mem0 | lineage | benign kept (ref) | 10 | 99 | [97, 100] |
| mem0 | lineage_lsed | repeat | 20 | 0 | [0, 14] (exact) |
| mem0 | lineage_lsed | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage_lsed | benign kept (neutral) | 10 | 93 | [88, 98] |
| mem0 | lineage_lsed | zombie (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage_lsed | benign kept (ref) | 10 | 97 | [93, 100] |
| mem0 | user | recovered (neutral) | 20 | 0 | [0, 14] (exact) |
| mem0 | user | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | user | recovered (ref) | 10 | 96 | [91, 100] |
| mem0 | user | zombie (ref) | 10 | 90 | [70, 100] |
| mem0 | user_lsed | recovered (neutral) | 20 | 0 | [0, 14] (exact) |
| mem0 | user_lsed | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | user_lsed | recovered (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | user_lsed | zombie (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | counterfactual | benign kept (neutral) | 10 | 93 | [88, 97] |
| mem0 | counterfactual | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | counterfactual | benign kept (ref) | 10 | 97 | [93, 100] |
| mem0 | counterfactual | zombie (ref) | 10 | 0 | [0, 26] (exact) |
