# Follow-up experiments (paper profile)

## Graphiti (graphiti-core 0.31.2): `remove_episode`

Background: 50 episodes. Recovery: deleted canary facts a client recovers (answer to a repeated / reworded question, or the retrieved context). Zombie: the deleted poison value in answers. Invalidated: worlds where the poison invalidated the person's true employer edge; still invalid: of those, worlds where the edge stays invalid after the poison is deleted.

| Deletion | Repeat | Reword | Context | Channels after (edges/entities/communities) | Zombie | Invalidated | Still invalid | At rest | Delete (s) |
|---|---|---|---|---|---|---|---|---|---|
| `remove_episode` | 88 | 89 | 89 | 0/0/89 | 17 | 1/6 | 1 | community_summaries | 13.651 |
| `remove_episode` + `build_communities` | 0 | 0 | 0 | 0/0/0 | 0 | 1/6 | 1 | **none** | 47.075 |
| LSED (P1, P3): restore validity, rebuild communities | 0 | 0 | 0 | 0/0/0 | 0 | 2/6 | 0 | **none** | 48.791 |

Counterfactual (never held the records): recovery 0, zombie 0, true employer edges valid 100.

## HotpotQA: quality cost of atomize-then-render (P4)

300 distractor-dev questions, 2957 paragraphs, top-5 retrieval, Qwen2.5-7B-Instruct. EM and F1 (%) with 95% bootstrap intervals.

| Context | EM | F1 |
|---|---|---|
| chunks | 48.7 [43.0, 54.3] | 63.7 [58.9, 68.6] |
| lsed+chunks | 52.3 [46.7, 57.7] | 66.7 [61.8, 71.3] |
| lsed_only | 31.7 [26.7, 37.0] | 43.6 [38.7, 48.9] |
| native+chunks | 49.3 [43.7, 55.0] | 64.3 [59.6, 69.0] |
| native_only | 39.3 [34.0, 45.0] | 51.4 [46.3, 56.5] |

Paired F1 difference LSED - native: with passages 2.4 [-0.4, 5.4], entity descriptions only -7.8 [-12.7, -3.0]. Supporting-paragraph recall@k 91.8 [89.7, 93.8].
Build: native 16797 entities (2168 merge calls, mean 113 chars); LSED 34518 entities from 36717 facts (34518 render calls, mean 129 chars).

### After deleting 296 paragraphs (250 questions keep both supporting paragraphs)

| Context | EM | F1 |
|---|---|---|
| chunks | 48.8 [42.8, 55.2] | 63.1 [57.6, 68.6] |
| lsed+chunks | 50.8 [45.2, 57.2] | 65.0 [59.8, 70.1] |
| lsed_cf+chunks | 50.8 [44.8, 57.2] | 64.5 [59.4, 69.8] |
| lsed_cf_only | 33.2 [27.6, 39.2] | 44.2 [38.8, 50.0] |
| lsed_only | 32.4 [26.8, 38.4] | 43.2 [37.8, 48.9] |
| native_keep+chunks | 50.0 [44.0, 56.8] | 63.9 [58.4, 69.0] |
| native_keep_only | 38.4 [32.4, 44.4] | 48.9 [43.1, 54.4] |
| native_remerge+chunks | 49.6 [43.6, 56.4] | 63.7 [58.2, 69.1] |
| native_remerge_only | 37.2 [31.2, 43.6] | 49.0 [43.0, 54.9] |

LSED vs. counterfactual: 31293/31411 descriptions identical; paired F1 difference 0.4 [-0.8, 1.8].
Deletion cost: LSED re-renders 662 entities (23.54 s); native re-merge 357 calls (17.83 s); a full rebuild needs 34072 calls.

## Deletion latency (per world, two worlds at a time)

| System | Condition | Worlds | Median (s) | p90 (s) | Max (s) |
|---|---|---:|---:|---:|---:|
| graphiti | lsed | 14 | 46.97 | 60.09 | 64.81 |
| graphiti | native | 14 | 13.71 | 24.79 | 30.6 |
| graphiti | native_rebuild | 14 | 48.08 | 59.01 | 60.44 |
| graphrag | lsed | 2 | 47.88 | 48.1 | 48.1 |
| graphrag | reindex | 2 | 48.7 | 50.57 | 50.57 |
| graphrag | update | 2 | 66.27 | 68.35 | 68.35 |
| lightrag | default | 8 | 3.74 | 4.35 | 4.35 |
| lightrag | lsed | 8 | 4.36 | 4.71 | 4.71 |
| lightrag | nocache | 5 | 3.62 | 3.78 | 3.78 |
| lightrag | thorough | 8 | 4.35 | 4.61 | 4.61 |
| mem0 | lineage | 5 | 0.01 | 0.01 | 0.01 |
| mem0 | lineage_lsed | 5 | 3.12 | 4.31 | 4.31 |
| mem0 | user | 5 | 0.04 | 0.05 | 0.05 |
| mem0 | user_lsed | 5 | 0.04 | 0.06 | 0.06 |
| mem0_zombie | lineage | 6 | 0.0 | 0.01 | 0.01 |
| mem0_zombie | lineage_lsed | 6 | 4.26 | 4.98 | 4.98 |
| mem0_zombie | user | 6 | 0.03 | 0.04 | 0.04 |
| mem0_zombie | user_lsed | 6 | 0.04 | 0.04 | 0.04 |


## Table 5 with 95% confidence intervals

| System | Condition | Cell | Worlds | Mean (%) | 95% CI (%) |
|---|---|---|---:|---:|---|
| graphrag | update | repeat | 10 | 86 | [66, 97] |
| graphrag | update | reword | 10 | 80 | [60, 93] |
| graphrag | update | zombie (reached) | 8 | 83 | [67, 96] |
| graphrag | reindex | repeat | 10 | 0 | [0, 26] (exact) |
| graphrag | reindex | reword | 10 | 0 | [0, 26] (exact) |
| graphrag | reindex | zombie (reached) | 8 | 0 | [0, 31] (exact) |
| graphrag | lsed | repeat | 10 | 0 | [0, 26] (exact) |
| graphrag | lsed | reword | 10 | 0 | [0, 26] (exact) |
| graphrag | lsed | zombie (reached) | 7 | 0 | [0, 35] (exact) |
| lightrag | default | repeat | 20 | 97 | [94, 99] |
| lightrag | default | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | default | context | 20 | 0 | [0, 14] (exact) |
| lightrag | default | zombie | 10 | 100 | [74, 100] (exact) |
| lightrag | thorough | repeat | 20 | 98 | [96, 99] |
| lightrag | thorough | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | thorough | context | 20 | 0 | [0, 14] (exact) |
| lightrag | thorough | zombie | 10 | 100 | [74, 100] (exact) |
| lightrag | nocache | repeat | 20 | 98 | [96, 99] |
| lightrag | nocache | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | nocache | context | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | repeat | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | reword | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | context | 20 | 0 | [0, 14] (exact) |
| lightrag | lsed | zombie | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage | repeat | 20 | 2 | [0, 5] |
| mem0 | lineage | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage | benign kept (neutral) | 10 | 96 | [93, 99] |
| mem0 | lineage | zombie (ref) | 10 | 30 | [0, 60] |
| mem0 | lineage | benign kept (ref) | 10 | 99 | [97, 100] |
| mem0 | lineage_lsed | repeat | 20 | 0 | [0, 14] (exact) |
| mem0 | lineage_lsed | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage_lsed | benign kept (neutral) | 10 | 93 | [88, 98] |
| mem0 | lineage_lsed | zombie (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | lineage_lsed | benign kept (ref) | 10 | 97 | [93, 100] |
| mem0 | user | recovered (neutral) | 20 | 0 | [0, 14] (exact) |
| mem0 | user | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | user | recovered (ref) | 10 | 96 | [91, 100] |
| mem0 | user | zombie (ref) | 10 | 90 | [70, 100] |
| mem0 | user_lsed | recovered (neutral) | 20 | 0 | [0, 14] (exact) |
| mem0 | user_lsed | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | user_lsed | recovered (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | user_lsed | zombie (ref) | 10 | 0 | [0, 26] (exact) |
| mem0 | counterfactual | benign kept (neutral) | 10 | 93 | [88, 97] |
| mem0 | counterfactual | zombie (neutral) | 10 | 0 | [0, 26] (exact) |
| mem0 | counterfactual | benign kept (ref) | 10 | 97 | [93, 100] |
| mem0 | counterfactual | zombie (ref) | 10 | 0 | [0, 26] (exact) |


## Claims

| | Claim | Result | |
|---|---|---|---|
| X0 | every Graphiti world valid, except worlds where the LLM returned invalid JSON to a structured call (listed and excluded: 6) | PASS | model-independent |
| X1 | `remove_episode` leaves deleted facts at rest in community summaries | PASS |  |
| X2 | after `remove_episode`, with or without a community rebuild, the true employer edge the poison invalidated stays invalid in every such world | PASS | model-independent |
| X3 | `remove_episode` + `build_communities`: nothing recovered, nothing at rest | PASS | model-independent |
| X4 | LSED: nothing recovered, no zombie, nothing at rest, every invalidated edge valid again | PASS | model-independent |
| X5 | the counterfactual recovers nothing | PASS | model-independent |
| H1 | after deletion, LSED holds exactly the counterfactual's entities | PASS | model-independent |
