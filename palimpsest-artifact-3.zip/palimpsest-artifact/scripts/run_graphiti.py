#!/usr/bin/env python3
"""Graphiti experiment on one GPU: start vLLM and the embedding server, smoke-test, run, stop.

    python scripts/run_graphiti.py --graphiti-python /workspace/venv-graphiti/bin/python --emb-port 8011

Graphiti (graphiti-core 0.31.2 on an embedded FalkorDB) lives in its own virtualenv; its worlds
run with that python. The embedding server runs with this python (sentence-transformers).
"""
import argparse, importlib.util, json, os, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)
spec = importlib.util.spec_from_file_location("rg", ROOT / "scripts" / "run_graphrag.py")
rg = importlib.util.module_from_spec(spec); spec.loader.exec_module(rg)
GRAPHITI_PIN = "0.31.2"


def preflight(env) -> None:
    """Embeddings, plain chat, and the structured (json_schema) chat Graphiti relies on."""
    def post(url, body):
        req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=300) as r:
                return r.status, json.load(r)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode(errors="ignore")[:300]
    st, body = post(env["PAL_EMB_BASE_URL"] + "/embeddings", {"input": ["ping"], "model": "bge"})
    dim = len(body["data"][0]["embedding"]) if st == 200 and isinstance(body, dict) else None
    if dim != 1024:
        sys.exit(f"embedding preflight failed at {env['PAL_EMB_BASE_URL']}: HTTP {st}, dim {dim}; pick a free --emb-port")
    schema = {"type": "object", "properties": {"names": {"type": "array", "items": {"type": "string"}}}, "required": ["names"]}
    st, body = post(env["PAL_LLM_BASE_URL"] + "/chat/completions",
                    {"model": env["PAL_LLM_MODEL"], "max_tokens": 64, "temperature": 0,
                     "messages": [{"role": "user", "content": "List the people: Alice Ng-0001 reports to Bob Osei-0002."}],
                     "response_format": {"type": "json_schema", "json_schema": {"name": "People", "schema": schema}}})
    try:
        names = json.loads(body["choices"][0]["message"]["content"])["names"]
    except Exception:
        sys.exit(f"structured-output preflight failed: HTTP {st}, body {str(body)[:300]}")
    rb.log(f"preflight ok: embeddings (dim {dim}); json_schema chat -> {names}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen7b"); ap.add_argument("--skip-smoke", action="store_true")
    ap.add_argument("--smoke-only", action="store_true")
    ap.add_argument("--lsed", choices=["include", "skip", "only"], default="include")
    ap.add_argument("--n-subjects", type=int, default=10); ap.add_argument("--n-background", type=int, default=10)
    ap.add_argument("--n-poison", type=int, default=10); ap.add_argument("--parallel", type=int, default=6)
    ap.add_argument("--out", default="results/graphiti")
    ap.add_argument("--graphiti-python", default=os.environ.get("PAL_GRAPHITI_PYTHON", "/workspace/venv-graphiti/bin/python"))
    ap.add_argument("--emb-port", type=int, default=8001)
    ap.add_argument("--max-model-len", type=int, default=32768)
    ap.add_argument("--world-timeout", type=int, default=3600)
    a = ap.parse_args()
    if a.smoke_only and a.skip_smoke:
        sys.exit("--smoke-only and --skip-smoke are mutually exclusive")
    os.chdir(ROOT)
    cfg = rb.load_backends(); cfg["max_model_len"] = a.max_model_len
    b = next(x for x in cfg["backends"] if x["tag"] == a.model)
    emb = rb.emb_model(cfg)
    for path in (b["path"], emb):
        ok, why = rb.weights_complete(Path(path))
        if not ok:
            sys.exit(f"model files incomplete at {path}: {why}")
    chk = subprocess.run([a.graphiti_python, "-c", "import graphiti_core, redislite, importlib.metadata as m; "
                          "print(m.version('graphiti-core'))"], capture_output=True, text=True)
    if chk.returncode or chk.stdout.strip() != GRAPHITI_PIN:
        sys.exit(f"graphiti-core=={GRAPHITI_PIN} with falkordblite required at {a.graphiti_python}: "
                 f"{chk.stdout.strip() or chk.stderr[-300:]}")
    rb.log(f"graphiti-core {chk.stdout.strip()} at {a.graphiti_python}")
    if not rg.port_free(a.emb_port):
        sys.exit(f"port {a.emb_port} is already in use; pick another with --emb-port")
    Path("logs").mkdir(exist_ok=True)
    env = dict(os.environ, PAL_LLM_BASE_URL=f"http://127.0.0.1:{cfg['port']}/v1", PAL_LLM_MODEL=b["path"],
               PAL_EMB_MODEL=emb, PAL_EMB_BASE_URL=f"http://127.0.0.1:{a.emb_port}/v1", PAL_GRAPHITI_PYTHON=a.graphiti_python,
               PYTHONPATH=str(ROOT), HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", GRAPHITI_TELEMETRY_ENABLED="false")
    proc = rb.start_server(b, cfg, Path("logs"), dry=False)
    emb_log = open("logs/embed_server_graphiti.log", "w")
    eproc = subprocess.Popen([sys.executable, "-m", "palimpsest.real.embed_server", "--port", str(a.emb_port)],
                             env=env, stdout=emb_log, stderr=subprocess.STDOUT, cwd=ROOT, start_new_session=True)
    try:
        for _ in range(60):
            if eproc.poll() is not None:
                sys.exit("embedding server exited; see logs/embed_server_graphiti.log")
            if rb.served_models(a.emb_port) is not None:
                break
            time.sleep(5)
        else:
            sys.exit("embedding server did not start")
        preflight(env)
        base = [sys.executable, "-m", "palimpsest.experiments.graphiti_exp", "--parallel", str(a.parallel),
                "--world-timeout", str(a.world_timeout)]
        base += {"include": [], "skip": ["--no-lsed"], "only": ["--only-lsed"]}[a.lsed]
        if not a.skip_smoke:
            rb.log("smoke test (1 subject, 2 background people, 1 poison target)")
            if rg.run(base + ["--quick", "--out", a.out], env, "logs/graphiti_smoke.log"):
                sys.exit("smoke test failed; see logs/graphiti_smoke.log")
            s = json.load(open(f"{a.out}_quick/graphiti.json"))["summary"]
            if s.get("invalid_worlds"):
                sys.exit(f"smoke test: invalid worlds {s['invalid_worlds'][:2]}")
            if not any((v.get("live") or 0) > 0 for v in s["recovery"].values()):
                sys.exit("smoke test: nothing recovered even while the records were live; extraction or search is broken")
            if not any(v.get("n_invalidated") for v in s["zombie"].values()):
                rb.log("smoke test note: the poison invalidated no true employer edge in the smoke world")
            rb.log("smoke test passed")
            if a.smoke_only:
                rb.log("smoke-only: done"); return
        if rg.run(base + ["--n-subjects", str(a.n_subjects), "--n-background", str(a.n_background),
                          "--n-poison", str(a.n_poison), "--out", a.out], env, "logs/graphiti_full.log"):
            sys.exit("full run failed; see logs/graphiti_full.log")
    finally:
        import signal
        try:
            os.killpg(eproc.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        rb.stop_server(proc, cfg["port"])
    rb.log(f"done: {a.out}/graphiti.json, {a.out}/meta.json")


if __name__ == "__main__":
    main()
