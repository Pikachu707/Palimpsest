#!/usr/bin/env python3
"""Table 5 (real systems) from a run, compared cell by cell with the paper.

    python scripts/report_real.py --run results/real_eval                 # a run of scripts/real_all.py
    python scripts/report_real.py --run results/real_eval --profile quick # its smoke-test outputs
    python scripts/report_real.py --paper                                 # the paper's own raw results

Writes <run>/REPORT.md and <run>/table5.json. Two kinds of verdict:

* numbers: each Table 5 cell vs. the paper, within --tol percentage points. Greedy decoding
  on another GPU or software stack changes some completions, so a differing number is
  reported, not fatal;
* claims: the paper's qualitative conclusions, several of them model-independent (deleted
  documents still indexed, the deleted conversation in Mem0's next prompt). Exit status 1 if
  any claim fails, or if any world was invalid.

At smoke scale (--profile quick, 1-2 subjects) only the model-independent claims are checked.
"""
import argparse, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Table 5 of the paper, in percent. Sources: paper_results/{graphrag/run2, real2, zombie_rerun}.
# Mem0 cells read "next message unrelated / referring back".
PAPER = {
    ("graphrag", "update"):   {"repeat": 77, "reword": 69, "zombie": 90},
    ("graphrag", "reindex"):  {"repeat": 0, "reword": 0, "zombie": 0},
    ("lightrag", "default"):  {"repeat": 99, "reword": 0, "zombie": 100},
    ("lightrag", "thorough"): {"repeat": 98, "reword": 0, "zombie": 100},
    ("mem0", "lineage"):      {"repeat": 2, "zombie_neutral": 0, "zombie_ref": 30},
    ("mem0", "user"):         {"recov_neutral": 0, "recov_ref": 90, "zombie_neutral": 0, "zombie_ref": 90},
}
ROW_LABEL = {
    ("graphrag", "update"): "GraphRAG 3.2.0, incremental update",
    ("graphrag", "reindex"): "GraphRAG 3.2.0, full re-index",
    ("lightrag", "default"): "LightRAG 1.5.7, `adelete_by_doc_id`",
    ("lightrag", "thorough"): "LightRAG 1.5.7, `+ delete_llm_cache`",
    ("lightrag", "nocache"): "LightRAG 1.5.7, extraction cache off",
    ("mem0", "lineage"): "Mem0 2.2.1, one `add()`'s memories",
    ("mem0", "user"): "Mem0 2.2.1, `delete_all`",
    ("graphrag", "lsed"): "GraphRAG + LSED (P1, P5)",
    ("lightrag", "lsed"): "LightRAG + LSED (P5)",
    ("mem0", "lineage_lsed"): "Mem0 + LSED, one `add()` (P1, P5)",
    ("mem0", "user_lsed"): "Mem0 + LSED, `delete_all` (P1, P5)",
}


# ------------------------------------------------------------------ loading
def _load(p: Path):
    try:
        return json.load(open(p))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def locate(run: Path, profile: str, paper: bool) -> dict:
    if paper:
        pr = ROOT / "paper_results"
        files = {"lightrag": pr / "real2/lightrag.json", "mem0": pr / "real2/mem0.json",
                 "mem0_zombie": pr / "zombie_rerun/real_zombie/mem0_zombie.json",
                 "mem0_zombie_meta": pr / "zombie_rerun/real_zombie/meta.json",
                 "graphrag": pr / "graphrag/run2/graphrag.json",
                 "graphrag_zombie": pr / "zombie_rerun/graphrag_zombie/graphrag.json"}
    else:
        q = "_quick" if profile == "quick" else ""
        real, gr = Path(f"{run / 'real'}{q}"), Path(f"{run / 'graphrag'}{q}")
        files = {"lightrag": real / "lightrag.json", "mem0": real / "mem0.json",
                 "mem0_zombie": real / "mem0_zombie.json", "mem0_zombie_meta": real / "meta.json",
                 "graphrag": gr / "graphrag.json", "graphrag_zombie": gr / "graphrag.json"}
        # results of `real_all.py --lsed only`, added beside an existing run
        rl, gl = Path(f"{run / 'real_lsed'}{q}"), Path(f"{run / 'graphrag_lsed'}{q}")
        files |= {"lightrag_lsed": rl / "lightrag.json", "mem0_lsed": rl / "mem0.json",
                  "mem0_zombie_lsed": rl / "mem0_zombie.json", "graphrag_lsed": gl / "graphrag.json"}
    R = {k: _load(v) for k, v in files.items()}
    for k in ("lightrag", "mem0", "mem0_zombie", "graphrag"):
        R[k] = merge(R[k], R.pop(k + "_lsed", None))
    R["graphrag_zombie"] = R["graphrag"] if not paper else merge(R["graphrag_zombie"], None)
    shown = {k: str(v) for k, v in files.items() if not k.endswith("_lsed") or Path(v).exists()}
    return R | {"_files": shown}


def merge(base, extra):
    """Add the conditions of an LSED-only run to a base run's summary (base wins on overlap)."""
    if not extra:
        return base
    if not base:
        return extra
    sb, se = dict(base.get("summary") or {}), extra.get("summary") or {}
    for k, v in se.items():
        if k == "invalid_worlds":
            sb[k] = list(sb.get(k) or []) + list(v or [])
        elif isinstance(v, dict) and isinstance(sb.get(k), dict) and k in ("recovery", "zombie", "counterfactual"):
            sb[k] = {**v, **sb[k]}
        elif k not in sb:
            sb[k] = v
    return {**base, "summary": sb}


def S(d):
    return (d or {}).get("summary") or {}


def dig(d, *keys):
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return None
        d = d[k]
    return d


def mem0_benign(z, meta):
    """Benign facts re-extracted after delete_all + a follow-up, per follow-up kind.
    Newer runs record it (`benign_after`); for older runs (the paper's), recompute it from the
    memories the follow-up's add() created, the only memories a user has after delete_all."""
    out = {fu: dig(S(z), f"user/{fu}", "benign_after") for fu in ("neutral", "ref")}
    if all(v is not None for v in out.values()) or not z or not meta:
        return out
    from palimpsest.canaries import build_population
    a = meta["args"]
    spm = a.get("zombie_subjects_per_manager") or a["subjects_per_manager"]
    pop = {s.subject_id: [f.value.lower() for f in s.all_facts()]
           for s in build_population(a["n_subjects"], a["docs"], a["facts"], seed=a["seed"] + 101, subjects_per_manager=spm)}
    for fu in out:
        rows = (z.get("rows") or {}).get(f"user/{fu}") or []
        fr = []
        for r in rows:
            vals = pop.get(r["user"]) or []
            blob = " ".join(r.get("follow_up_memories") or []).lower()
            if vals:
                fr.append(sum(v in blob for v in vals) / len(vals))
        out[fu] = round(sum(fr) / len(fr), 3) if fr else None
    return out


def cells(R) -> dict:
    """Every Table 5 cell of a run as a fraction (None = not measured)."""
    g, gz, lr, m, mz = S(R["graphrag"]), S(R["graphrag_zombie"]), S(R["lightrag"]), S(R["mem0"]), S(R["mem0_zombie"])
    ben = mem0_benign(R["mem0_zombie"], R["mem0_zombie_meta"])
    c = {}
    for mode in ("update", "reindex", "lsed"):
        c[("graphrag", mode)] = {"repeat": dig(g, "recovery", mode, "answer"), "reword": dig(g, "recovery", mode, "reword"),
                                 "context": dig(g, "recovery", mode, "context"),
                                 "zombie": dig(gz, "zombie", mode, "after_given_effective"),
                                 "zombie_n_effective": dig(gz, "zombie", mode, "n_effective"),
                                 "zombie_raw": dig(gz, "zombie", mode, "after"),
                                 "docs_still_indexed": dig(g, "recovery", mode, "docs_still_indexed"),
                                 "live": dig(g, "recovery", mode, "live"),
                                 "at_rest": dig(g, "recovery", mode, "at_rest_stores")}
    for cond in ("default", "thorough", "nocache", "lsed"):
        c[("lightrag", cond)] = {"repeat": dig(lr, "recovery", cond, "answer"), "reword": dig(lr, "recovery", cond, "paraphrase"),
                                 "context": dig(lr, "recovery", cond, "context"), "live": dig(lr, "recovery", cond, "live"),
                                 "zombie": dig(lr, "zombie", cond, "after"), "zombie_before": dig(lr, "zombie", cond, "before"),
                                 "at_rest": dig(lr, "recovery", cond, "at_rest_stores")}
    for k in ("lineage_lsed",):
        c[("mem0", k)] = {"repeat": dig(m, k, "visible"),
                          "zombie_neutral": dig(mz, f"{k}/neutral", "after"), "zombie_ref": dig(mz, f"{k}/ref", "after"),
                          "poison_in_next_prompt": dig(mz, f"{k}/ref", "poison_in_next_prompt"),
                          "at_rest": dig(m, k, "at_rest_stores"), "at_rest_zombie": dig(mz, f"{k}/ref", "at_rest_deleted_stores")}
    c[("mem0", "user_lsed")] = {"visible_after_delete": dig(m, "user_lsed", "visible_after_delete"),
                                "recov_neutral": dig(m, "user_lsed", "visible_after_return"),
                                "recov_ref": dig(mz, "user_lsed/ref", "benign_after"),
                                "zombie_neutral": dig(mz, "user_lsed/neutral", "after"), "zombie_ref": dig(mz, "user_lsed/ref", "after"),
                                "poison_in_next_prompt": dig(mz, "user_lsed/ref", "poison_in_next_prompt"),
                                "at_rest": dig(m, "user_lsed", "at_rest_stores"),
                                "at_rest_zombie": dig(mz, "user_lsed/ref", "at_rest_deleted_stores")}
    c[("mem0", "lineage")] = {"repeat": dig(m, "lineage", "visible"),
                              "zombie_neutral": dig(mz, "lineage/neutral", "after"), "zombie_ref": dig(mz, "lineage/ref", "after"),
                              "zombie_before": dig(mz, "lineage/ref", "before"),
                              "poison_in_next_prompt": dig(mz, "lineage/ref", "poison_in_next_prompt"),
                              "at_rest": dig(m, "lineage", "at_rest_stores")}
    c[("mem0", "user")] = {"visible_after_delete": dig(m, "user", "visible_after_delete"),
                           "recov_neutral": dig(m, "user", "visible_after_return"), "recov_ref": ben["ref"],
                           "zombie_neutral": dig(mz, "user/neutral", "after"), "zombie_ref": dig(mz, "user/ref", "after"),
                           "zombie_deleted": dig(mz, "user/ref", "deleted"),
                           "poison_in_next_prompt": dig(mz, "user/ref", "poison_in_next_prompt"),
                           "at_rest": dig(m, "user", "at_rest_stores")}
    c["counterfactual"] = {
        "graphrag recovery": dig(g, "counterfactual", "recovery"), "graphrag zombie": dig(gz, "counterfactual", "zombie"),
        "lightrag answer (cache)": dig(lr, "counterfactual", "cache", "answer"),
        "lightrag context (cache)": dig(lr, "counterfactual", "cache", "context"),
        "lightrag answer (nocache)": dig(lr, "counterfactual", "nocache", "answer"),
        "lightrag zombie": dig(lr, "zombie_counterfactual"),
        "mem0 lineage": dig(m, "lineage_counterfactual"), "mem0 user": dig(m, "user_counterfactual"),
        "mem0 zombie (ref)": dig(mz, "cf/ref", "after"), "mem0 zombie (neutral)": dig(mz, "cf/neutral", "after")}
    c["invalid"] = {k: len(S(R[k]).get("invalid_worlds") or []) for k in ("lightrag", "mem0", "mem0_zombie", "graphrag", "graphrag_zombie")
                    if R[k] is not None}
    return c


# ------------------------------------------------------------------ verdicts
def claims(c, quick: bool):
    """(id, statement, holds: True/False/None, model_independent)."""
    gu, gr = c[("graphrag", "update")], c[("graphrag", "reindex")]
    ld, lt = c[("lightrag", "default")], c[("lightrag", "thorough")]
    ml, mu = c[("mem0", "lineage")], c[("mem0", "user")]
    ge = lambda x, t: None if x is None else x >= t
    le = lambda x, t: None if x is None else x <= t
    both = lambda *xs: None if any(x is None for x in xs) else all(xs)
    cf = [v for v in c["counterfactual"].values() if v is not None]
    out = [
        ("R0", "every world valid (all documents indexed)", all(v == 0 for v in c["invalid"].values()) if c["invalid"] else None, True),
        ("R1", "no counterfactual world ever returns a deleted fact or the poison", (max(cf) == 0) if cf else None, True),
        ("G1", "GraphRAG incremental update leaves every deleted document indexed", ge(gu["docs_still_indexed"], 1.0), True),
        ("G2", "GraphRAG full re-index removes them from the index", le(gr["docs_still_indexed"], 0.0), True),
        ("G3", "GraphRAG update: clients still recover deleted facts (>= 50%)", ge(gu["repeat"], 0.5), False),
        ("G4", "GraphRAG re-index: clients recover nothing", le(gr["repeat"], 0.0), False),
        ("L1", "LightRAG: a repeated question returns the deleted facts from the answer cache (>= 90%), both options",
         both(ge(ld["repeat"], 0.9), ge(lt["repeat"], 0.9)), False),
        ("L2", "LightRAG: reworded questions and retrieved context recover nothing (entities are re-derived, M1 closed)",
         both(le(ld["reword"], 0.0), le(ld["context"], 0.0), le(lt["reword"], 0.0), le(lt["context"], 0.0)), False),
        ("L3", "LightRAG: deleted poison stays fully effective through the cache",
         both(ge(ld["zombie"], 1.0), ge(lt["zombie"], 1.0)), False),
        ("M1", "Mem0 delete_all hides every memory from clients", le(mu["visible_after_delete"], 0.0), True),
        ("M2", "Mem0: the deleted conversation is in the next extraction prompt, every world",
         both(ge(ml["poison_in_next_prompt"], 1.0), ge(mu["poison_in_next_prompt"], 1.0)), True),
        ("M3", "Mem0: a referring-back message revives deleted poison after delete_all (>= 50%)", ge(mu["zombie_ref"], 0.5), False),
        ("M4", "Mem0: an unrelated message revives nothing", both(le(mu["zombie_neutral"], 0.0), le(mu["recov_neutral"], 0.0)), False),
    ]
    # LSED applied to the real systems. A deleted canary or poison value is a random token that no
    # model can produce without residue, so "nothing recovered" holds whatever the model: these
    # claims are model-independent.
    gs, ls = c[("graphrag", "lsed")], c[("lightrag", "lsed")]
    mls, mus = c[("mem0", "lineage_lsed")], c[("mem0", "user_lsed")]
    empty = lambda x: None if x is None else len(x) == 0
    out += [
        ("S1", "GraphRAG + LSED: deleted documents leave the index and no store holds a deleted fact",
         both(le(gs["docs_still_indexed"], 0.0), empty(gs["at_rest"])), True),
        ("S2", "GraphRAG + LSED: clients recover nothing and deleted poison has no effect",
         both(le(gs["repeat"], 0.0), le(gs["reword"], 0.0), le(gs["zombie_raw"], 0.0)), True),
        ("S3", "LightRAG + LSED: no repeated, reworded, or context recovery, no zombie, nothing at rest",
         both(le(ls["repeat"], 0.0), le(ls["reword"], 0.0), le(ls["context"], 0.0), le(ls["zombie"], 0.0), empty(ls["at_rest"])), True),
        ("S4", "Mem0 + LSED: the deleted conversation is not in the next extraction prompt",
         both(le(mls["poison_in_next_prompt"], 0.0), le(mus["poison_in_next_prompt"], 0.0)), True),
        ("S5", "Mem0 + LSED: no follow-up message revives deleted facts or poison, and nothing is at rest",
         both(le(mls["repeat"], 0.0), le(mls["zombie_ref"], 0.0), le(mls["zombie_neutral"], 0.0),
              le(mus["recov_ref"], 0.0), le(mus["recov_neutral"], 0.0), le(mus["zombie_ref"], 0.0),
              le(mus["zombie_neutral"], 0.0), empty(mls["at_rest"]), empty(mus["at_rest"]),
              empty(mls["at_rest_zombie"]), empty(mus["at_rest_zombie"])), True),
    ]
    if quick:   # 1-2 subjects: model-dependent rates are noise
        out = [(i, s, h if mi else None, mi) for i, s, h, mi in out]
    return out


def pct(x):
    return "n/a" if x is None else f"{100 * x:.0f}"


def compare(c, tol):
    """(row, column, paper %, run %, verdict) for every cell the paper reports."""
    rows = []
    for key, ref in PAPER.items():
        for col, pv in ref.items():
            rv = c[key].get(col)
            v = "n/a" if rv is None else ("match" if abs(100 * rv - pv) <= tol else "DIFFERS")
            rows.append((ROW_LABEL[key], col, pv, None if rv is None else round(100 * rv, 1), v))
    return rows


def render(c, cmp_rows, cl, R, title, quick, tol) -> str:
    L = [f"# {title}", ""]
    if quick:
        L += ["> **Smoke scale (1-2 subjects per system).** These numbers only show that every system, the "
              "LLM server and the scoring run end to end; they are not comparable with the paper. "
              "Only model-independent claims are checked. Run the `paper` profile for Table 5.", ""]
    L += ["## Table 5", "",
          "Deleted canary facts a client recovers, and zombie-poisoning success after deletion (%). "
          "Paper values in parentheses. Mem0 cells: next message unrelated / referring back.", "",
          "| System and deletion | Repeat | Reword | Zombie | At rest |", "|---|---|---|---|---|"]
    def cell(key, col):
        p = PAPER.get(key, {}).get(col)
        return pct(c[key].get(col)) + (f" ({p})" if p is not None else "")
    rest = lambda x: "n/a" if x is None else (", ".join(x) or "**none**")
    def row(key):
        x = c[key]
        if key[0] == "mem0":
            first = cell(key, "repeat") if "lineage" in key[1] else f"{cell(key, 'recov_neutral')} / {cell(key, 'recov_ref')}"
            return f"| {ROW_LABEL[key]} | {first} | | {cell(key, 'zombie_neutral')} / {cell(key, 'zombie_ref')} | {rest(x.get('at_rest'))} |"
        z = cell(key, "zombie")
        if key[0] == "graphrag" and x.get("zombie_n_effective") is not None:
            z += f", {x['zombie_n_effective']}/10 reached"
        return f"| {ROW_LABEL[key]} | {cell(key, 'repeat')} | {cell(key, 'reword')} | {z} | {rest(x.get('at_rest'))} |"
    for key in [("graphrag", "update"), ("graphrag", "reindex"), ("graphrag", "lsed"),
                ("lightrag", "default"), ("lightrag", "thorough"), ("lightrag", "nocache"), ("lightrag", "lsed"),
                ("mem0", "lineage"), ("mem0", "lineage_lsed"), ("mem0", "user"), ("mem0", "user_lsed")]:
        if key[1].endswith("lsed") and all(v is None for k, v in c[key].items() if k != "at_rest"):
            continue                                       # LSED not run (e.g. the paper's raw results)
        L.append(row(key))
    L += ["", "Counterfactual worlds (never held the data): " +
          ", ".join(f"{k} {pct(v)}" for k, v in c["counterfactual"].items() if v is not None) + ".", ""]
    L += ["## Claims", "", "R/G/L/M: the paper's findings; S: LSED applied to the real systems.", "",
          "| | Claim | Result | |", "|---|---|---|---|"]
    for i, s, h, mi in cl:
        L.append(f"| {i} | {s} | {'PASS' if h else ('n/a' if h is None else '**FAIL**')} | {'model-independent' if mi else ''} |")
    if not quick:
        diff = [r for r in cmp_rows if r[4] == "DIFFERS"]
        L += ["", f"## Numbers vs. the paper (tolerance {tol:g} pp)", "",
              f"{sum(r[4] == 'match' for r in cmp_rows)} of {len(cmp_rows)} cells match"
              + (f"; {len(diff)} differ:" if diff else "."), ""]
        for r in diff:
            L.append(f"* {r[0]}, {r[1]}: {r[3]} vs. {r[2]} in the paper")
        if diff:
            L += ["", "Greedy decoding on another GPU or software stack changes individual completions "
                  "(the paper's own rerun on a second machine moved MiniGraphRAG zombie success from 60% to 50%). "
                  "A differing number with every claim passing reproduces the paper's conclusions."]
    def note(k):
        if k.endswith("_lsed"):
            return " (LSED conditions, merged)"
        return "" if R.get(k) is not None else " (missing)"
    L += ["", "## Inputs", ""] + [f"* `{k}`: `{v}`{note(k)}" for k, v in R["_files"].items()]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="results/real_eval")
    ap.add_argument("--profile", choices=["paper", "quick"], default="paper")
    ap.add_argument("--paper", action="store_true", help="report on paper_results/ (writes to results/paper_table5/)")
    ap.add_argument("--tol", type=float, default=15.0, help="percentage points")
    a = ap.parse_args()
    run = Path(a.run) if Path(a.run).is_absolute() else ROOT / a.run
    if a.paper:
        run = ROOT / "results" / "paper_table5"
    run.mkdir(parents=True, exist_ok=True)
    quick = a.profile == "quick" and not a.paper
    R = locate(run, a.profile, a.paper)
    if all(R[k] is None for k in ("lightrag", "mem0", "mem0_zombie", "graphrag")):
        sys.exit(f"no results found for {run} (profile {a.profile}); expected e.g. {R['_files']['lightrag']}")
    c = cells(R)
    cl = claims(c, quick)
    cmp_rows = compare(c, a.tol)
    title = "Table 5 from the paper's raw results" if a.paper else f"Real-system evaluation ({a.profile} profile)"
    md = render(c, cmp_rows, cl, R, title, quick, a.tol)
    (run / "REPORT.md").write_text(md)
    ser = {f"{k[0]}/{k[1]}" if isinstance(k, tuple) else k: v for k, v in c.items()}
    json.dump({"cells": ser, "claims": [dict(id=i, claim=s, holds=h, model_independent=mi) for i, s, h, mi in cl],
               "vs_paper": [dict(row=r[0], column=r[1], paper=r[2], run=r[3], verdict=r[4]) for r in cmp_rows],
               "inputs": R["_files"]}, open(run / "table5.json", "w"), indent=1)
    print(md)
    failed = [i for i, _, h, _ in cl if h is False]
    if failed:
        sys.exit(f"claims failed: {', '.join(failed)}")


if __name__ == "__main__":
    main()
