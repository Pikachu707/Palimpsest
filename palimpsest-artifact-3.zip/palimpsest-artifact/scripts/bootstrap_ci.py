#!/usr/bin/env python3
"""95% confidence intervals for every Table 5 cell, from the per-world rows of a run.

    python scripts/bootstrap_ci.py --run results/real_eval            # a run of scripts/real_all.py
    python scripts/bootstrap_ci.py --paper                            # the paper's raw results

A cell is a mean over worlds (one subject or poison target per world). The interval is a
percentile bootstrap over worlds (10,000 resamples). When every world scores 0 (or 1) the
bootstrap interval collapses to a point, so the exact one-sided Clopper-Pearson bound for
0 of n (or n of n) worlds is given instead. Writes <run>/table5_ci.{json,md}.
"""
import argparse, importlib.util, json, sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rr", ROOT / "scripts" / "report_real.py")
rr = importlib.util.module_from_spec(spec); spec.loader.exec_module(rr)


def rows(R, k):
    return ((R.get(k) or {}).get("rows")) or {}


def merged_rows(R, base_key, run, profile, paper):
    """Rows of a run plus those of an LSED-only run beside it (report_real merges only summaries)."""
    out = {}
    for k, v in rows(R, base_key).items():
        out[k] = v
    if not paper:
        q = "_quick" if profile == "quick" else ""
        sub = {"lightrag": "real_lsed", "mem0": "real_lsed", "mem0_zombie": "real_lsed", "graphrag": "graphrag_lsed"}[base_key]
        f = Path(f"{run / sub}{q}") / f"{base_key}.json"
        if f.exists():
            for k, v in (json.load(open(f)).get("rows") or {}).items():
                if isinstance(v, dict) and isinstance(out.get(k), dict):
                    out[k] = {**v, **out[k]}
                else:
                    out.setdefault(k, v)
    return out


def ci(xs, n_boot=10000, seed=0):
    xs = np.asarray([x for x in xs if x is not None], dtype=float)
    n = len(xs)
    if n == 0:
        return None
    m = float(xs.mean())
    if np.all(xs == 0):                 # exact one-sided 95% bound for 0 of n
        return {"n": n, "mean": 0.0, "lo": 0.0, "hi": round(1 - 0.05 ** (1 / n), 4), "method": "clopper-pearson"}
    if np.all(xs == 1):
        return {"n": n, "mean": 1.0, "lo": round(0.05 ** (1 / n), 4), "hi": 1.0, "method": "clopper-pearson"}
    rng = np.random.default_rng(seed)
    bs = xs[rng.integers(0, n, (n_boot, n))].mean(1)
    return {"n": n, "mean": round(m, 4), "lo": round(float(np.percentile(bs, 2.5)), 4),
            "hi": round(float(np.percentile(bs, 97.5)), 4), "method": "bootstrap"}


def cells(R, run, profile, paper):
    g = merged_rows(R, "graphrag", run, profile, paper)
    gz = g if not paper else (R.get("graphrag_zombie") or {}).get("rows") or {}
    lr = merged_rows(R, "lightrag", run, profile, paper)
    m = merged_rows(R, "mem0", run, profile, paper)
    mz = merged_rows(R, "mem0_zombie", run, profile, paper)
    col = lambda rs, f: [f(r) for r in (rs or [])]
    out = []
    for c in ("update", "reindex", "lsed"):
        rs, zs = (g.get("rr") or {}).get(c), (gz.get("zp") or {}).get(c)
        if rs:
            out += [(("graphrag", c), "repeat", ci(col(rs, lambda r: r["answer"]))),
                    (("graphrag", c), "reword", ci(col(rs, lambda r: r["reword"])))]
        if zs:
            out.append((("graphrag", c), "zombie (reached)", ci([r["after"] for r in zs if r["before"] > 0])))
    for c in ("default", "thorough", "nocache", "lsed"):
        rs, zs = (lr.get("rr") or {}).get(c), (lr.get("zp") or {}).get(c)
        if rs:
            out += [(("lightrag", c), "repeat", ci(col(rs, lambda r: r["answer"]))),
                    (("lightrag", c), "reword", ci(col(rs, lambda r: r["paraphrase"]))),
                    (("lightrag", c), "context", ci(col(rs, lambda r: r["context"])))]
        if zs:
            out.append((("lightrag", c), "zombie", ci(col(zs, lambda r: r["after"]))))
    for k in ("lineage", "lineage_lsed"):
        if m.get(k):
            out.append((("mem0", k), "repeat", ci(col(m[k], lambda r: r["visible"]))))
        for fu in ("neutral", "ref"):
            zs = mz.get(f"{k}/{fu}")
            if zs:
                out.append((("mem0", k), f"zombie ({fu})", ci(col(zs, lambda r: r["after"]))))
                out.append((("mem0", k), f"benign kept ({fu})", ci(col(zs, lambda r: r.get("benign_after")))))
    for k in ("user", "user_lsed"):
        if m.get(k):
            out.append((("mem0", k), "recovered (neutral)", ci(col(m[k], lambda r: r["visible_after_return"]))))
        for fu in ("neutral", "ref"):
            zs = mz.get(f"{k}/{fu}")
            if zs:
                if fu == "ref":
                    out.append((("mem0", k), "recovered (ref)", ci(col(zs, lambda r: r.get("benign_after")))))
                out.append((("mem0", k), f"zombie ({fu})", ci(col(zs, lambda r: r["after"]))))
    for fu in ("neutral", "ref"):
        zs = mz.get(f"cf/{fu}")
        if zs:
            out.append((("mem0", "counterfactual"), f"benign kept ({fu})", ci(col(zs, lambda r: r.get("benign_after")))))
            out.append((("mem0", "counterfactual"), f"zombie ({fu})", ci(col(zs, lambda r: r["after"]))))
    return [(k, c, v) for k, c, v in out if v is not None]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="results/real_eval"); ap.add_argument("--paper", action="store_true")
    ap.add_argument("--profile", choices=["paper", "quick"], default="paper")
    a = ap.parse_args()
    run = Path(a.run) if Path(a.run).is_absolute() else ROOT / a.run
    if a.paper:
        run = ROOT / "results" / "paper_table5"
    run.mkdir(parents=True, exist_ok=True)
    R = rr.locate(run, a.profile, a.paper)
    res = cells(R, run, a.profile, a.paper)
    if not res:
        sys.exit(f"no per-world rows found under {run}")
    pct = lambda x: f"{100 * x:.0f}"
    md = ["| System | Condition | Cell | Worlds | Mean (%) | 95% CI (%) |", "|---|---|---|---:|---:|---|"]
    for (s, c), cell, v in res:
        md.append(f"| {s} | {c} | {cell} | {v['n']} | {pct(v['mean'])} | [{pct(v['lo'])}, {pct(v['hi'])}]"
                  + (" (exact)" if v["method"] != "bootstrap" else "") + " |")
    (run / "table5_ci.md").write_text("\n".join(md) + "\n")
    json.dump([{"system": s, "condition": c, "cell": cell, **v} for (s, c), cell, v in res],
              open(run / "table5_ci.json", "w"), indent=1)
    print("\n".join(md))


if __name__ == "__main__":
    main()
