#!/usr/bin/env python3
"""Deletion latency per system and condition, from the per-op timings the worlds record.

    python scripts/deletion_timing.py --run results/real_eval/timing [--run results/real_eval/graphiti]

Every world writes op_seconds (one [op, seconds] pair per op, aligned with its ops list; the
Graphiti worlds write timing["remove"]). The deletion step is:
  LightRAG   the delete op (adelete_by_doc_id per document, plus the cache flush under LSED)
  Mem0       delete_from_add / delete_all (plus erasure and replay of dependent adds under LSED)
  GraphRAG   the removal op after the live checks: an incremental update, a full re-index,
             or LSED's erase-and-re-index
  Graphiti   remove (remove_episode, plus validity restore and community rebuild under LSED)
Writes deletion_timing.json and deletion_timing.md next to the first --run.
"""
import argparse, json, statistics
from pathlib import Path

CONDS = {"lightrag": ["default", "thorough", "nocache", "lsed"],
         "graphrag": ["update", "reindex", "lsed"],
         "graphiti": ["native_rebuild", "native", "lsed"]}
MEM0_KINDS = ["lineage_lsed", "lineage", "user_lsed", "user"]
DELETE_OPS = {"lightrag": {"delete"}, "mem0": {"delete_from_add", "delete_all"}, "mem0_zombie": {"delete_from_add", "delete_all"}}


def system_of(p: Path):
    for part in reversed(p.parts):
        if part in ("lightrag", "mem0", "mem0_zombie", "graphrag", "graphiti"):
            return part
    return None


def cond_of(system, name):
    if system in CONDS:
        for c in CONDS[system]:                      # longest names first where they overlap
            if name.endswith("_" + c):
                return c
        return None
    for k in sorted(MEM0_KINDS, key=len, reverse=True):
        if name.startswith(k + "_"):
            return k
    return None


def delete_seconds(system, ops, out):
    if system == "graphiti":
        return (out.get("timing") or {}).get("remove")
    secs = out.get("op_seconds")
    if not secs or len(secs) != len(ops):
        return None
    if system == "graphrag":
        first_status = next((i for i, o in enumerate(ops) if o["op"] == "status"), None)
        if first_status is None:
            return None
        i = next((i for i in range(first_status + 1, len(ops)) if ops[i]["op"] in ("update", "index", "lsed_reindex")), None)
        return secs[i][1] if i is not None else None
    tot = [s for (name, s), o in zip(secs, ops) if o["op"] in DELETE_OPS[system]]
    return sum(tot) if tot else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", nargs="+", required=True)
    a = ap.parse_args()
    rows = {}
    for run in a.run:
        for outf in Path(run).rglob("*.out.json"):
            if outf.parent.name != "ops":
                continue
            system, name = system_of(outf), outf.name[:-len(".out.json")]
            opf = outf.with_name(name + ".ops.json")
            if system is None or not opf.exists() or name.startswith(("S0", "cf_", "zp_cf")):
                continue
            cond = cond_of(system, name)
            try:
                s = delete_seconds(system, json.load(open(opf)), json.load(open(outf)))
            except Exception:
                s = None
            if cond and s is not None:
                rows.setdefault((system, cond), []).append(s)
    res = []
    for (system, cond), xs in sorted(rows.items()):
        xs = sorted(xs)
        res.append({"system": system, "condition": cond, "n": len(xs), "median_s": round(statistics.median(xs), 2),
                    "p90_s": round(xs[min(len(xs) - 1, int(0.9 * len(xs)))], 2), "max_s": round(xs[-1], 2)})
    dst = Path(a.run[0])
    json.dump(res, open(dst / "deletion_timing.json", "w"), indent=1)
    md = ["| System | Condition | Worlds | Median (s) | p90 (s) | Max (s) |", "|---|---|---:|---:|---:|---:|"]
    md += [f"| {r['system']} | {r['condition']} | {r['n']} | {r['median_s']} | {r['p90_s']} | {r['max_s']} |" for r in res]
    (dst / "deletion_timing.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    if not res:
        raise SystemExit("no timed worlds found (runs before op timing was recorded have none)")


if __name__ == "__main__":
    main()
