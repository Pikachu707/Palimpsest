#!/usr/bin/env python3
"""HotpotQA quality cost of LSED's atomize-then-render on one GPU: start vLLM, smoke-test, run, stop.

    python scripts/run_hotpot.py --n-questions 300 --out results/hotpot

The dataset (HotpotQA distractor, validation split) is downloaded from the Hugging Face hub,
or from the official site if the hub is unreachable, or read from --data.
"""
import argparse, importlib.util, json, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)


def run(cmd, env, log):
    with open(log, "w") as f:
        p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=ROOT)
        for line in p.stdout:
            sys.stdout.write(line); f.write(line)
        return p.wait()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen7b"); ap.add_argument("--n-questions", type=int, default=300)
    ap.add_argument("--out", default="results/hotpot"); ap.add_argument("--data", default=None)
    ap.add_argument("--skip-smoke", action="store_true"); ap.add_argument("--smoke-only", action="store_true")
    ap.add_argument("--max-model-len", type=int, default=32768)
    a = ap.parse_args()
    os.chdir(ROOT)
    cfg = rb.load_backends(); cfg["max_model_len"] = a.max_model_len
    b = next(x for x in cfg["backends"] if x["tag"] == a.model)
    emb = rb.emb_model(cfg)
    for path in (b["path"], emb):
        ok, why = rb.weights_complete(Path(path))
        if not ok:
            sys.exit(f"model files incomplete at {path}: {why}")
    Path("logs").mkdir(exist_ok=True)
    env = dict(os.environ, PAL_LLM_BASE_URL=f"http://127.0.0.1:{cfg['port']}/v1", PAL_LLM_MODEL=b["path"],
               PAL_EMB_MODEL=emb, PYTHONPATH=str(ROOT))
    base = [sys.executable, "-m", "palimpsest.experiments.hotpot_quality"] + (["--data", a.data] if a.data else [])
    # fetch the data before starting the GPU server, so a download problem costs nothing
    chk = subprocess.run([sys.executable, "-c", "from palimpsest.experiments.hotpot_quality import load_hotpot; "
                          "from pathlib import Path; import os, sys; "
                          f"d = load_hotpot({a.data!r}, Path(os.environ.get('PAL_DATA_DIR', 'data')) / 'hotpot'); "
                          "print(len(d), 'questions')"], env=env, cwd=ROOT, capture_output=True, text=True)
    if chk.returncode:
        sys.exit(f"HotpotQA could not be loaded: {chk.stderr[-600:]}\nDownload hotpot_dev_distractor_v1.json "
                 "yourself and pass --data")
    rb.log("HotpotQA: " + chk.stdout.strip().splitlines()[-1])
    proc = rb.start_server(b, cfg, Path("logs"), dry=False)
    try:
        if not a.skip_smoke:
            rb.log("smoke test (10 questions)")
            if run(base + ["--n-questions", "10", "--out", a.out + "_quick"], env, "logs/hotpot_smoke.log"):
                sys.exit("smoke test failed; see logs/hotpot_smoke.log")
            s = json.load(open(f"{a.out}_quick/hotpot.json"))["summary"]
            if s["build"]["paragraphs_without_facts"] > 0.5 * s["build"]["n_paragraphs"]:
                sys.exit(f"smoke test: the atom extraction parsed nothing for most paragraphs: {s['build']}")
            if (s["before"]["scores"]["chunks"]["f1"][0] or 0) == 0:
                if os.environ.get("PAL_FAKE_EMBED") == "1":      # tests only: the stub LLM cannot answer
                    rb.log("smoke test: 0 F1 (expected with the stub LLM)")
                else:
                    sys.exit("smoke test: answers from the retrieved paragraphs scored 0 F1; the answerer is broken")
            rb.log("smoke test passed")
            if a.smoke_only:
                return
        if run(base + ["--n-questions", str(a.n_questions), "--out", a.out], env, "logs/hotpot_full.log"):
            sys.exit("full run failed; see logs/hotpot_full.log")
    finally:
        rb.stop_server(proc, cfg["port"])
    rb.log(f"done: {a.out}/hotpot.json")


if __name__ == "__main__":
    main()
