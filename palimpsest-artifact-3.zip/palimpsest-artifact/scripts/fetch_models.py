#!/usr/bin/env python3
"""Download the two models the real-system experiments need, if not already complete.

    python scripts/fetch_models.py                    # ModelScope (what the paper used)
    python scripts/fetch_models.py --hub hf           # Hugging Face Hub
    python scripts/fetch_models.py --check            # only verify, never download

Paths follow configs/backends.yaml and configs/local.yaml, moved by PAL_MODELS_DIR.
A model counts as present only if every safetensors shard is complete (see
run_backends.weights_complete), so an interrupted download is resumed, not trusted.
"""
import argparse, importlib.util, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)

HF_IDS = {"Qwen/Qwen2.5-7B-Instruct": "Qwen/Qwen2.5-7B-Instruct",
          "BAAI/bge-large-en-v1.5": "BAAI/bge-large-en-v1.5"}


def needed(model_tag: str):
    import os
    os.chdir(ROOT)
    cfg = rb.load_backends()
    b = next(x for x in cfg["backends"] if x["tag"] == model_tag)
    return [(b["modelscope"], Path(b["path"])), ("BAAI/bge-large-en-v1.5", Path(rb.emb_model(cfg)))]


def download(hub: str, mid: str, path: Path):
    path.mkdir(parents=True, exist_ok=True)
    if hub == "modelscope":
        from modelscope import snapshot_download
        snapshot_download(mid, local_dir=str(path))
    else:
        from huggingface_hub import snapshot_download
        snapshot_download(HF_IDS.get(mid, mid), local_dir=str(path),
                          allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model", "tokenizer*",
                                          "1_Pooling/*", "*.py", "merges.txt", "vocab*"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hub", choices=["modelscope", "hf"], default="modelscope")
    ap.add_argument("--model", default="qwen7b", help="tag in configs/backends.yaml")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    bad = []
    for mid, path in needed(a.model):
        ok, why = rb.weights_complete(path)
        if ok:
            rb.log(f"present: {path} ({why})"); continue
        if a.check:
            bad.append(f"{path}: {why}"); continue
        rb.log(f"downloading {mid} from {a.hub} -> {path} ({why})")
        try:
            download(a.hub, mid, path)
        except Exception as e:
            other = "hf" if a.hub == "modelscope" else "modelscope"
            sys.exit(f"download of {mid} failed: {e}\nRetry, or use the other hub: HUB={other} bash run_real.sh")
        ok, why = rb.weights_complete(path)
        if not ok:
            sys.exit(f"{path} still incomplete after download: {why}")
        rb.log(f"ok: {path} ({why})")
    if bad:
        sys.exit("models incomplete:\n  " + "\n  ".join(bad))


if __name__ == "__main__":
    main()
