#!/usr/bin/env python3
"""Report of the follow-up experiments: Graphiti, HotpotQA quality cost, deletion latency, CIs.

    python scripts/report_extra.py --run results/real_eval [--profile quick]

Writes <run>/EXTRA_REPORT.md and <run>/extra.json. Exit status 1 if a model-independent claim
fails or a Graphiti world was invalid.
"""
import argparse, json, sys
from pathlib import Path


def load(p):
    try:
        return json.load(open(p))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


pct = lambda x: "n/a" if x is None else f"{100 * x:.0f}"


def llm_json(w):
    """A world that failed because the LLM returned malformed JSON to one of Graphiti's structured
    calls. Greedy decoding repeats the same output, so such a world fails under every condition."""
    return "JSONDecodeError" in (w.get("why") or "")


def graphiti(g, quick):
    s = g["summary"]; rec, zom, cf = s["recovery"], s["zombie"], s["counterfactual"]
    L = ["## Graphiti (graphiti-core 0.31.2): `remove_episode`", "",
         f"Background: {s['background']['episodes']} episodes. Recovery: deleted canary facts a client recovers "
         "(answer to a repeated / reworded question, or the retrieved context). Zombie: the deleted poison value in "
         "answers. Invalidated: worlds where the poison invalidated the person's true employer edge; still invalid: "
         "of those, worlds where the edge stays invalid after the poison is deleted.", "",
         "| Deletion | Repeat | Reword | Context | Channels after (edges/entities/communities) | Zombie | Invalidated | Still invalid | At rest | Delete (s) |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    label = {"native": "`remove_episode`", "native_rebuild": "`remove_episode` + `build_communities`",
             "lsed": "LSED (P1, P3): restore validity, rebuild communities"}
    for c in ("native", "native_rebuild", "lsed"):
        r, z = rec.get(c), zom.get(c)
        if not r and not z:
            continue
        ch = (r or {}).get("channels_after") or {}
        L.append(f"| {label[c]} | {pct((r or {}).get('answer'))} | {pct((r or {}).get('reword'))} | {pct((r or {}).get('context'))} | "
                 f"{'/'.join(pct(ch.get(k)) for k in ('edges', 'nodes', 'communities'))} | {pct((z or {}).get('after'))} | "
                 f"{(z or {}).get('n_invalidated', 'n/a')}/{(z or {}).get('n', 'n/a')} | {(z or {}).get('still_invalid_after', 'n/a')} | "
                 f"{', '.join(sorted(set((r or {}).get('at_rest_stores', []) + (z or {}).get('at_rest_stores', [])))) or '**none**'} | "
                 f"{(r or {}).get('delete_seconds', 'n/a')} |")
    L += ["", f"Counterfactual (never held the records): recovery {pct(cf.get('recovery'))}, zombie {pct(cf.get('zombie'))}, "
          f"true employer edges valid {pct(cf.get('true_edge_valid'))}.", ""]
    nat, reb, ls = rec.get("native", {}), rec.get("native_rebuild", {}), rec.get("lsed", {})
    zn, zr, zl = zom.get("native", {}), zom.get("native_rebuild", {}), zom.get("lsed", {})
    def still(z):
        n = z.get("n_invalidated")
        return None if not n else z.get("still_invalid_after") == n
    def zero(*xs):
        return None if any(x is None for x in xs) else all(x == 0 for x in xs)
    claims = [
        ("X0", "every Graphiti world valid, except worlds where the LLM returned invalid JSON to a structured "
               f"call (listed and excluded: {sum(llm_json(w) for w in s['invalid_worlds'])})",
         all(llm_json(w) for w in s["invalid_worlds"]), True),
        ("X1", "`remove_episode` leaves deleted facts at rest in community summaries",
         None if not nat else "community_summaries" in nat.get("at_rest_stores", []), False),
        ("X2", "after `remove_episode`, with or without a community rebuild, the true employer edge the poison "
               "invalidated stays invalid in every such world", None if still(zn) is None or still(zr) is None else (still(zn) and still(zr)), True),
        ("X3", "`remove_episode` + `build_communities`: nothing recovered, nothing at rest",
         None if not reb else (zero(reb.get("answer"), reb.get("reword"), reb.get("context")) and not reb.get("at_rest_stores")), True),
        ("X4", "LSED: nothing recovered, no zombie, nothing at rest, every invalidated edge valid again",
         None if not ls or not zl else (zero(ls.get("answer"), ls.get("reword"), ls.get("context"), zl.get("after"))
                                       and not ls.get("at_rest_stores") and not zl.get("at_rest_stores")
                                       and (zl.get("n_invalidated") == 0 or zl.get("still_invalid_after") == 0)), True),
        ("X5", "the counterfactual recovers nothing", zero(cf.get("recovery"), cf.get("zombie")), True),
    ]
    if quick:
        claims = [(i, t, h if mi else None, mi) for i, t, h, mi in claims]
    return L, claims


def hotpot(h):
    s = h["summary"]; b, a, bu = s["before"], s["after"], s["build"]
    ci = lambda v: "n/a" if not v else f"{100 * v[0]:.1f} [{100 * v[1]:.1f}, {100 * v[2]:.1f}]"
    L = ["## HotpotQA: quality cost of atomize-then-render (P4)", "",
         f"{bu.get('n_questions', h['args']['n_questions'])} distractor-dev questions, {bu['n_paragraphs']} paragraphs, top-{h['args']['k']} retrieval, "
         f"{h['llm'].rsplit('/', 1)[-1]}. EM and F1 (%) with 95% bootstrap intervals.", "",
         "| Context | EM | F1 |", "|---|---|---|"]
    for k, v in sorted(b["scores"].items()):
        L.append(f"| {k} | {ci(v['em'])} | {ci(v['f1'])} |")
    d = b["lsed_minus_native_f1"]
    L += ["", f"Paired F1 difference LSED - native: with passages {ci(d['+chunks'])}, entity descriptions only {ci(d['_only'])}. "
          f"Supporting-paragraph recall@k {ci(b['support_recall_at_k'])}.",
          f"Build: native {bu['native_entities']} entities ({bu['native_merge_calls']} merge calls, mean {bu['native_desc_chars']} chars); "
          f"LSED {bu['lsed_entities']} entities from {bu['lsed_facts']} facts ({bu['lsed_render_calls']} render calls, mean {bu['lsed_desc_chars']} chars).", "",
          f"### After deleting {a['deleted_paragraphs']} paragraphs ({a['surviving_questions']} questions keep both supporting paragraphs)", "",
          "| Context | EM | F1 |", "|---|---|---|"]
    for k, v in sorted(a["scores"].items()):
        L.append(f"| {k} | {ci(v['em'])} | {ci(v['f1'])} |")
    c = a["cost"]; same = a["lsed_vs_cf_identical_descriptions"]
    L += ["", f"LSED vs. counterfactual: {same[0]}/{same[1]} descriptions identical; paired F1 difference {ci(a['lsed_minus_cf_f1'])}.",
          f"Deletion cost: LSED re-renders {c['lsed_rerender_calls']} entities ({c['lsed_seconds']} s); native re-merge "
          f"{c['native_remerge_calls']} calls ({c['native_remerge_seconds']} s); a full rebuild needs {c['full_rebuild_calls']} calls.", ""]
    claims = [("H1", "after deletion, LSED holds exactly the counterfactual's entities", a["lsed_entity_sets_equal"], True)]
    return L, claims


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="results/real_eval"); ap.add_argument("--profile", choices=["paper", "quick"], default="paper")
    a = ap.parse_args()
    run = Path(a.run); q = "_quick" if a.profile == "quick" else ""
    L, claims, found = [f"# Follow-up experiments ({a.profile} profile)", ""], [], []
    g = load(Path(f"{run / 'graphiti'}{q}") / "graphiti.json")
    if g:
        x, c = graphiti(g, a.profile == "quick"); L += x; claims += c; found.append("graphiti")
    h = load(Path(f"{run / 'hotpot'}{q}") / "hotpot.json")
    if h:
        x, c = hotpot(h); L += x; claims += c; found.append("hotpot")
    t = (run / "timing" / "deletion_timing.md")
    if not t.exists():
        t = run / "graphiti" / "deletion_timing.md"
    if t.exists():
        L += ["## Deletion latency (per world, two worlds at a time)", "", t.read_text(), ""]; found.append("timing")
    if (run / "table5_ci.md").exists():
        L += ["## Table 5 with 95% confidence intervals", "", (run / "table5_ci.md").read_text(), ""]; found.append("ci")
    if not found:
        sys.exit(f"no follow-up results under {run}")
    if claims:
        L += ["## Claims", "", "| | Claim | Result | |", "|---|---|---|---|"]
        L += [f"| {i} | {t_} | {'PASS' if h_ else ('n/a' if h_ is None else '**FAIL**')} | {'model-independent' if mi else ''} |"
              for i, t_, h_, mi in claims]
    (run / "EXTRA_REPORT.md").write_text("\n".join(L) + "\n")
    json.dump({"found": found, "claims": [dict(id=i, claim=t_, holds=h_, model_independent=mi) for i, t_, h_, mi in claims]},
              open(run / "extra.json", "w"), indent=1)
    print("\n".join(L))
    bad = [i for i, _, h_, mi in claims if mi and h_ is False]
    if bad:
        sys.exit(f"model-independent claims failed: {', '.join(bad)}")


if __name__ == "__main__":
    main()
