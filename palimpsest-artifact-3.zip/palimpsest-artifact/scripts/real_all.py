#!/usr/bin/env python3
"""Every real-system experiment of the paper (Table 5, Appendix H) in one command.

Normally started by ./run_real.sh, which first builds the environments and fetches the
weights. It can also be run directly from the main virtualenv:

    python scripts/real_all.py                         # paper profile: everything in Table 5
    python scripts/real_all.py --profile quick         # smoke tests only (~15 min): is the stack sound?
    python scripts/real_all.py --systems graphrag      # one driver only
    python scripts/real_all.py --dry-run               # preflight + plan, starts nothing
    python scripts/real_all.py --lsed only             # add only the LSED conditions to an existing run
    python scripts/real_all.py --systems graphiti hotpotqa timing   # the follow-up experiments

Stages: preflight -> plumbing tests (stub LLM, no GPU) -> LightRAG + Mem0 -> GraphRAG -> report.
Follow-up stages (Appendix H), selected with --systems: graphiti (a fourth system, Graphiti),
hotpotqa (quality cost of LSED's atomize-then-render on HotpotQA), timing (deletion latency of
every system and condition, at reduced scale). The report adds bootstrap confidence intervals
for Table 5 whenever its results are present.
Each driver starts and stops its own vLLM, so they run one after another. The run is
resumable: a stage whose outputs are complete and valid is skipped (--force reruns it), and
GraphRAG additionally reuses finished worlds. Status and every log end up under --out.
"""
import argparse, importlib.metadata as md, importlib.util, json, os, shutil, socket, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)

PINS = {"lightrag-hku": "1.5.7", "mem0ai": "2.2.1"}
GRAPHRAG_PIN = "3.2.0"
GRAPHITI_PIN = "0.31.2"
STAGES = ["lightrag-mem0", "graphrag", "hotpotqa", "timing", "graphiti"]   # Graphiti, the longest, last
MIN_GPU_GIB, ROOMY_GPU_GIB, MIN_DISK_GIB = 40, 70, 20
DRIVER_LOGS = {"lightrag-mem0": ["real_smoke.log", "real_full.log", "vllm_qwen7b.log"],
               "graphrag": ["graphrag_smoke.log", "graphrag_full.log", "embed_server.log", "vllm_qwen7b.log"],
               "graphiti": ["graphiti_smoke.log", "graphiti_full.log", "embed_server_graphiti.log", "vllm_qwen7b.log"],
               "hotpotqa": ["hotpot_smoke.log", "hotpot_full.log", "vllm_qwen7b.log"],
               "timing": ["real_full.log", "graphrag_full.log", "embed_server.log", "vllm_qwen7b.log"]}
uses_emb = lambda systems: any(s in systems for s in ("graphrag", "graphiti", "timing"))


def log(msg):
    print(f"[real_all {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def banner(msg):
    print(f"\n{'=' * 78}\n  {msg}\n{'=' * 78}", flush=True)


# ------------------------------------------------------------------ outputs and resume
def subdir(system: str, lsed: str) -> str:
    """Results of `--lsed only` go next to an existing run instead of replacing it."""
    return system + ("_lsed" if lsed == "only" else "")


def outputs(stage: str, out: Path, profile: str, lsed: str = "include"):
    """Files a finished stage leaves behind. The drivers' smoke tests write to <out>_quick."""
    q = "_quick" if profile == "quick" else ""
    if stage == "lightrag-mem0":
        d = Path(f"{out / subdir('real', lsed)}{q}")
        return [d / f for f in ("lightrag.json", "mem0.json", "mem0_zombie.json", "meta.json")]
    if stage == "graphrag":
        d = Path(f"{out / subdir('graphrag', lsed)}{q}")
        return [d / "graphrag.json", d / "meta.json"]
    if stage == "graphiti":
        d = Path(f"{out / 'graphiti'}{q}")
        return [d / "graphiti.json", d / "meta.json"]
    if stage == "hotpotqa":
        return [Path(f"{out / 'hotpot'}{q}") / "hotpot.json"]
    if stage == "timing":
        r, g = Path(f"{out / 'timing' / 'real'}{q}"), Path(f"{out / 'timing' / 'graphrag'}{q}")
        return [r / "lightrag.json", r / "mem0.json", r / "meta.json", g / "graphrag.json"]
    return []


def stage_complete(stage, out, profile, lsed="include"):
    """Complete = every output exists, parses, and reports no invalid world."""
    files = outputs(stage, out, profile, lsed)
    if not files:
        return False
    for f in files:
        if not f.exists():
            return False
        try:
            d = json.load(open(f))
        except Exception:
            return False
        inv = (d.get("summary") or {}).get("invalid_worlds") or []
        # Graphiti: a world whose LLM output was malformed JSON fails the same way on every rerun
        # (greedy decoding); it is reported and excluded, not retried
        if [w for w in inv if not (stage == "graphiti" and "JSONDecodeError" in (w.get("why") or ""))]:
            return False
    if stage != "hotpotqa" and lsed == "include" and not has_lsed(files):
        log(f"{stage}: existing results predate the LSED conditions; rerunning. "
            "To keep them and add only LSED, use --lsed only")
        return False
    return True


def has_lsed(files) -> bool:
    """Whether results already contain the LSED conditions (runs before they existed do not)."""
    for f in files:
        sm = (json.load(open(f)).get("summary") or {}) if f.name != "meta.json" else None
        if sm is None:
            continue
        keys = set(sm) | set(sm.get("recovery", {})) | set(sm.get("zombie", {}))
        if not any(k == "lsed" or "_lsed" in k for k in keys):
            return False
    return True


class Status:
    def __init__(self, path: Path):
        self.path = path
        self.d = json.load(open(path)) if path.exists() else {"stages": {}}

    def set(self, stage, **kv):
        self.d["stages"].setdefault(stage, {}).update(kv)
        self.path.write_text(json.dumps(self.d, indent=1))


# ------------------------------------------------------------------ preflight
def gpu_info():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=30)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if r.returncode:
        return None
    gpus = []
    for line in r.stdout.strip().splitlines():
        name, mem = [x.strip() for x in line.rsplit(",", 1)]
        gpus.append((name, int(float(mem)) / 1024))
    return gpus


def port_in_use(port):
    for host in ("127.0.0.1", "::1"):
        try:
            with socket.create_connection((host, port), timeout=1):
                return True
        except OSError:
            pass
    return False


def preflight(a, out: Path) -> list:
    """Every problem we can detect before starting a GPU server. Returns the problems found."""
    problems, warn = [], []
    gpus = gpu_info()
    if not gpus:
        problems.append("no NVIDIA GPU visible (nvidia-smi failed)")
    else:
        name, gib = gpus[0]
        log(f"GPU 0: {name}, {gib:.0f} GiB" + (f" (+{len(gpus) - 1} more, unused)" if len(gpus) > 1 else ""))
        if gib < MIN_GPU_GIB:
            problems.append(f"GPU 0 has {gib:.0f} GiB; the experiments need >= {MIN_GPU_GIB} GiB "
                            "(Qwen2.5-7B in vLLM plus one bge-large per parallel world)")
        elif gib < ROOMY_GPU_GIB and not os.environ.get("PAL_GPU_UTIL"):
            # The paper's 0.40 of an 80 GB H100 is 32 GB; on a 40-48 GB card that is too little for
            # weights plus a 32k-token KV cache, so give vLLM a larger share there.
            os.environ["PAL_GPU_UTIL"] = "0.60"
            warn.append(f"{gib:.0f} GiB GPU: vLLM gets 60% of it (PAL_GPU_UTIL=0.60); "
                        "use --parallel-real 3 if worlds run out of memory")
    port = int(os.environ.get("PAL_VLLM_PORT", "8000"))
    if port_in_use(port):
        problems.append(f"port {port} is in use (leftover vLLM? `pkill -f vllm.entrypoints`), or set PAL_VLLM_PORT")
    if uses_emb(a.systems) and port_in_use(a.emb_port):
        problems.append(f"port {a.emb_port} is in use; pass --emb-port with a free port")
    out.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(out).free / 2**30
    if free < MIN_DISK_GIB:
        problems.append(f"only {free:.0f} GiB free under {out}; need >= {MIN_DISK_GIB} GiB")
    for p, v in PINS.items():
        try:
            have = md.version(p)
        except md.PackageNotFoundError:
            have = None
        if ("lightrag-mem0" in a.systems or "timing" in a.systems) and have != v:
            problems.append(f"{p}=={v} required in {sys.executable}, found {have}: results are version-specific")
    try:
        import vllm  # noqa: F401
    except Exception as e:
        problems.append(f"vLLM not importable in {sys.executable}: {e.__class__.__name__}: {e}")
    if "graphiti" in a.systems:
        chk = subprocess.run([a.graphiti_python, "-c", "import redislite, importlib.metadata as m; print(m.version('graphiti-core'))"],
                             capture_output=True, text=True) if Path(a.graphiti_python).exists() else None
        have = chk.stdout.strip() if chk is not None and chk.returncode == 0 else None
        if have != GRAPHITI_PIN:
            problems.append(f"graphiti-core=={GRAPHITI_PIN} with falkordblite required at {a.graphiti_python}, found {have}")
    if "graphrag" in a.systems or "timing" in a.systems:
        chk = subprocess.run([a.graphrag_python, "-c", "import importlib.metadata as m; print(m.version('graphrag'))"],
                             capture_output=True, text=True) if Path(a.graphrag_python).exists() else None
        have = chk.stdout.strip() if chk is not None and chk.returncode == 0 else None
        if have != GRAPHRAG_PIN:
            problems.append(f"graphrag=={GRAPHRAG_PIN} required at {a.graphrag_python}, found {have}")
    fm = subprocess.run([sys.executable, str(ROOT / "scripts" / "fetch_models.py"), "--check"],
                        capture_output=True, text=True, cwd=ROOT)
    sys.stdout.write(fm.stdout)
    if fm.returncode:
        problems.append((fm.stderr or fm.stdout).strip().splitlines()[-1] + "  (run: python scripts/fetch_models.py)")
    for w in warn:
        log("note: " + w)
    return problems


# ------------------------------------------------------------------ stages
def tee(cmd, env, logfile: Path) -> int:
    logfile.parent.mkdir(parents=True, exist_ok=True)
    with open(logfile, "w") as f:
        p = subprocess.Popen(cmd, env=env, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in p.stdout:
            sys.stdout.write(line); f.write(line)
        return p.wait()


def driver_cmd(stage, a, out: Path):
    """The driver command(s) of a stage."""
    py = sys.executable
    quick = ["--smoke-only"] if a.profile == "quick" else []
    nosmoke = ["--skip-smoke"] if a.skip_smoke and a.profile != "quick" else []
    if stage == "graphiti":
        return [[py, "scripts/run_graphiti.py", "--out", str(out / "graphiti"), "--graphiti-python", a.graphiti_python,
                 "--emb-port", str(a.emb_port), "--n-subjects", str(a.n_subjects_graphiti),
                 "--n-background", str(a.n_background_graphiti), "--n-poison", str(a.n_background_graphiti),
                 "--parallel", str(a.parallel_graphiti), "--world-timeout", "10800"] + quick + nosmoke]
    if stage == "hotpotqa":
        return [[py, "scripts/run_hotpot.py", "--out", str(out / "hotpot"), "--n-questions", str(a.n_questions)]
                + (["--data", a.hotpot_data] if a.hotpot_data else []) + quick + nosmoke]
    if stage == "timing":
        # deletion latency of every condition, at reduced scale; two worlds at a time
        if a.profile == "quick":
            return []
        return [[py, "scripts/run_real_systems.py", "--out", str(out / "timing" / "real"), "--skip-smoke",
                 "--subjects-per-manager", "1", "--zombie-subjects-per-manager", "10",
                 "--n-subjects", "5", "--n-poison", "3", "--parallel", "2"],
                [py, "scripts/run_graphrag.py", "--out", str(out / "timing" / "graphrag"), "--skip-smoke", "--only", "recovery",
                 "--graphrag-python", a.graphrag_python, "--vllm-python", py, "--emb-port", str(a.emb_port),
                 "--n-subjects", "2", "--parallel", "2"]]
    return [_paper_cmd(stage, a, out, py)]


def _paper_cmd(stage, a, out, py):
    if stage == "lightrag-mem0":
        cmd = [py, "scripts/run_real_systems.py", "--out", str(out / subdir("real", a.lsed)), "--lsed", a.lsed,
               "--subjects-per-manager", "1",            # LightRAG/Mem0 as in the paper's run 2 (paper_results/real2)
               "--zombie-subjects-per-manager", "10",    # Mem0 zombie as in paper_results/zombie_rerun/real_zombie
               "--n-subjects", str(a.n_subjects_real), "--n-poison", "10", "--parallel", str(a.parallel_real)]
    else:
        cmd = [py, "scripts/run_graphrag.py", "--out", str(out / subdir("graphrag", a.lsed)), "--lsed", a.lsed,
               "--graphrag-python", a.graphrag_python,
               "--vllm-python", py, "--emb-port", str(a.emb_port),
               "--n-subjects", str(a.n_subjects_graphrag), "--n-poison", "10", "--parallel", str(a.parallel_graphrag)]
    if a.profile == "quick":
        cmd.append("--smoke-only")
    return cmd


def collect_logs(stage, out: Path, key=None):
    dst = out / "logs" / (key or stage); dst.mkdir(parents=True, exist_ok=True)
    for name in DRIVER_LOGS.get(stage, []):
        src = ROOT / "logs" / name
        if src.exists():
            shutil.copy2(src, dst / name)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", choices=["paper", "quick"], default="paper",
                    help="paper: the full Table 5 runs (~2.5 h on one H100); quick: each driver's smoke test only")
    ap.add_argument("--systems", nargs="+", choices=STAGES, default=["lightrag-mem0", "graphrag"],
                    help="Table 5: lightrag-mem0 graphrag (default); follow-ups: graphiti hotpotqa timing")
    ap.add_argument("--out", default="results/real_eval")
    ap.add_argument("--graphrag-python", default=os.environ.get("PAL_GRAPHRAG_PYTHON", "/workspace/venv-graphrag/bin/python"))
    ap.add_argument("--graphiti-python", default=os.environ.get("PAL_GRAPHITI_PYTHON", "/workspace/venv-graphiti/bin/python"))
    ap.add_argument("--emb-port", type=int, default=8001)
    ap.add_argument("--n-subjects-graphiti", type=int, default=8, help="Graphiti recovery targets")
    ap.add_argument("--n-background-graphiti", type=int, default=10,
                    help="Graphiti background people (those with a valid employer edge become poison targets)")
    ap.add_argument("--parallel-graphiti", type=int, default=16)
    ap.add_argument("--skip-smoke", action="store_true", help="follow-up stages: no smoke test before the full run")
    ap.add_argument("--n-questions", type=int, default=300, help="HotpotQA questions")
    ap.add_argument("--hotpot-data", default=None, help="a local HotpotQA distractor-dev file, if the download is blocked")
    ap.add_argument("--n-subjects-real", type=int, default=20)
    ap.add_argument("--n-subjects-graphrag", type=int, default=10)
    ap.add_argument("--parallel-real", type=int, default=6)
    ap.add_argument("--parallel-graphrag", type=int, default=4)
    ap.add_argument("--lsed", choices=["include", "skip", "only"], default="include",
                    help="LSED deletion conditions: with the others (include), none (skip: the paper's original "
                         "set), or only them, written to real_lsed/ and graphrag_lsed/ beside an existing run (only)")
    ap.add_argument("--skip-tests", action="store_true", help="skip the stub-LLM plumbing tests")
    ap.add_argument("--force", action="store_true", help="rerun stages whose outputs already exist")
    ap.add_argument("--dry-run", action="store_true", help="preflight and print the plan; start nothing")
    a = ap.parse_args()
    os.chdir(ROOT)
    a.graphrag_python = str(Path(a.graphrag_python)); a.graphiti_python = str(Path(a.graphiti_python))
    a.systems = [s for s in STAGES if s in a.systems]          # canonical order
    out = Path(a.out) if Path(a.out).is_absolute() else ROOT / a.out
    out.mkdir(parents=True, exist_ok=True)
    (ROOT / "logs").mkdir(exist_ok=True)
    os.environ.setdefault("PAL_GRAPHRAG_PYTHON", a.graphrag_python)
    status = Status(out / "status.json")
    status.d.update(profile=a.profile, systems=a.systems, started=status.d.get("started") or time.strftime("%Y-%m-%d %H:%M:%S"))
    t0 = time.time()

    banner(f"Palimpsest real-system evaluation  |  profile={a.profile}  |  out={out}")
    problems = preflight(a, out)
    if problems:
        for p in problems:
            log("PREFLIGHT: " + p)
        if not a.dry_run:
            status.set("preflight", state="failed", problems=problems)
            sys.exit(f"preflight failed ({len(problems)} problem(s)); nothing was started")
    else:
        log("preflight ok")
    status.set("preflight", state="ok" if not problems else "failed", problems=problems)

    plan = ([] if a.skip_tests else ["tests"]) + a.systems + ["report"]
    lsed_of = lambda st: a.lsed if st in ("lightrag-mem0", "graphrag") else "include"
    tests = (["tests/test_real_systems.py"] if any(x in a.systems for x in ("lightrag-mem0", "timing")) else []) \
        + (["tests/test_graphrag.py"] if any(x in a.systems for x in ("graphrag", "timing")) else []) \
        + (["tests/test_graphiti.py"] if "graphiti" in a.systems else []) \
        + (["tests/test_hotpot.py"] if "hotpotqa" in a.systems else [])
    if a.dry_run:
        banner("plan (dry run)")
        for s in plan:
            if s == "tests":
                print(f"  tests          pytest {' '.join(tests)} (stub LLM)")
            elif s == "report":
                print(f"  report         report_real.py, bootstrap_ci.py, deletion_timing.py, report_extra.py on {out}")
            else:
                done = (stage_complete(s, out, a.profile, lsed_of(s)) and not a.force
                        and status.d["stages"].get(s, {}).get("state") != "failed")
                cmds = driver_cmd(s, a, out)
                print(f"  {s:<14} " + ("SKIP (complete)" if done else ("SKIP (nothing at quick scale)" if not cmds
                                                                       else "\n                 ".join(" ".join(c[1:]) for c in cmds))))
        return

    for stage in plan:
        if stage == "tests":
            banner("stage: plumbing tests (stub OpenAI server, no GPU)")
            env = dict(os.environ, PAL_GRAPHRAG_PYTHON=a.graphrag_python, PAL_GRAPHITI_PYTHON=a.graphiti_python)
            rc = tee([sys.executable, "-m", "pytest", "-q", "-rs", *tests], env, out / "logs" / "tests.log")
            # these tests skip themselves when a library is missing; here that is a setup error
            skipped = "skipped" in (out / "logs" / "tests.log").read_text().splitlines()[-1]
            status.set("tests", state="ok" if rc == 0 and not skipped else "failed", rc=rc, skipped=skipped)
            if rc or skipped:
                sys.exit(f"plumbing tests {'were skipped' if skipped else 'failed'}; see {out / 'logs' / 'tests.log'}")
            continue
        if stage == "report":
            banner("stage: report")
            env, rc = dict(os.environ), 0
            have_t5 = any(f.exists() for x in ("lightrag-mem0", "graphrag") for l in ("include", "only")
                          for f in outputs(x, out, a.profile, l))
            if have_t5:
                rc = tee([sys.executable, "scripts/report_real.py", "--run", str(out), "--profile", a.profile],
                         env, out / "logs" / "report.log")
                if a.profile == "paper":
                    tee([sys.executable, "scripts/bootstrap_ci.py", "--run", str(out)], env, out / "logs" / "bootstrap_ci.log")
            timed = [str(d) for d in (out / "timing", out / "graphiti") if d.exists()]
            if timed and a.profile == "paper":
                tee([sys.executable, "scripts/deletion_timing.py", "--run", *timed], env, out / "logs" / "deletion_timing.log")
            if any(x in a.systems for x in ("graphiti", "hotpotqa", "timing")) or (out / "graphiti").exists() or (out / "hotpot").exists():
                rc = tee([sys.executable, "scripts/report_extra.py", "--run", str(out), "--profile", a.profile],
                         env, out / "logs" / "report_extra.log") or rc
            status.set("report", state="ok" if rc == 0 else "checks_failed", rc=rc)
            break
        ls = lsed_of(stage)
        key = stage + ("-lsed" if ls == "only" else "")
        banner(f"stage: {key}")
        cmds = driver_cmd(stage, a, out)
        if not cmds:
            log(f"{key}: nothing to run at {a.profile} scale"); status.set(key, state="skipped_profile"); continue
        prev = status.d["stages"].get(key, {}).get("state")
        if stage_complete(stage, out, a.profile, ls) and prev != "failed" and not a.force:
            log(f"{key}: outputs complete, skipping (use --force to rerun)")
            status.set(key, state="skipped_complete"); continue
        ts = time.time(); status.set(key, state="running", started=time.strftime("%H:%M:%S"), cmd=cmds)
        rc = 0
        for i, cmd in enumerate(cmds):
            log(" ".join(cmd[1:]))
            rc = tee(cmd, dict(os.environ), out / "logs" / f"{key}.driver{'' if len(cmds) == 1 else i + 1}.log")
            collect_logs(stage, out, key if len(cmds) == 1 else f"{key}/{i + 1}")
            if rc:
                break
        mins = round((time.time() - ts) / 60, 1)
        if rc or not stage_complete(stage, out, a.profile, ls):
            status.set(key, state="failed", rc=rc, minutes=mins)
            sys.exit(f"{key} failed (rc={rc}) after {mins} min; logs in {out / 'logs' / key}/. "
                     "Rerun the same command to resume.")
        status.set(key, state="ok", minutes=mins)
        log(f"{key}: done in {mins} min")

    total = round((time.time() - t0) / 60, 1)
    status.d["minutes_this_invocation"] = total; status.set("report", finished=time.strftime("%Y-%m-%d %H:%M:%S"))
    banner(f"finished in {total} min  |  reports: {out / 'REPORT.md'}, {out / 'EXTRA_REPORT.md'}")
    if status.d["stages"].get("report", {}).get("state") != "ok":
        sys.exit(1)


if __name__ == "__main__":
    main()
