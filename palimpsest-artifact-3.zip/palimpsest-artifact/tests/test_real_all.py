"""The one-click real-system pipeline (run_real.sh -> scripts/real_all.py -> report_real.py).

Fast tests (always run): model-path remapping, and the Table 5 report reproducing every
cell of the paper from paper_results/.

End-to-end test (needs LightRAG and Mem0; GraphRAG too if PAL_GRAPHRAG_PYTHON is set):
scripts/real_all.py --profile quick with stand-ins for the GPU (tests/fake_gpu: a fake
`nvidia-smi` and a fake `vllm` that serves tests/stub_openai.py), tiny valid weight files
and hash embeddings. It checks the whole chain: preflight, both drivers starting and stopping
their servers, the smoke experiments, the report, and resuming without redoing finished stages.
"""
import importlib.util, json, os, socket, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent


def _rb():
    spec = importlib.util.spec_from_file_location("rb", ROOT / "scripts" / "run_backends.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def test_models_dir_remaps_config_paths(monkeypatch):
    rb = _rb()
    monkeypatch.chdir(ROOT)
    monkeypatch.delenv("PAL_MODELS_DIR", raising=False)
    assert rb.model_path("/workspace/models/Qwen2.5-7B-Instruct") == "/workspace/models/Qwen2.5-7B-Instruct"
    monkeypatch.setenv("PAL_MODELS_DIR", "/data/w")
    assert rb.model_path("/workspace/models/Qwen2.5-7B-Instruct") == "/data/w/Qwen2.5-7B-Instruct"
    assert rb.model_path("/elsewhere/m") == "/elsewhere/m"                 # only the default root moves
    cfg = rb.load_backends()
    assert all(b["path"].startswith("/data/w/") for b in cfg["backends"])
    assert rb.emb_model(cfg) == "/data/w/bge-large-en-v1.5"
    monkeypatch.setenv("PAL_ATTN_BACKEND", "auto"); monkeypatch.setenv("PAL_VLLM_PORT", "9123")
    cfg = rb.load_backends()
    assert cfg["attention_backend"] is None and cfg["port"] == 9123


def test_report_reproduces_paper_table5(tmp_path):
    r = subprocess.run([sys.executable, "scripts/report_real.py", "--paper"], cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout[-2000:] + r.stderr[-2000:]
    t = json.load(open(ROOT / "results" / "paper_table5" / "table5.json"))
    assert t["vs_paper"] and all(c["verdict"] == "match" and round(c["run"]) == c["paper"] for c in t["vs_paper"]), \
        [c for c in t["vs_paper"] if round(c["run"]) != c["paper"]]          # the paper prints whole percents
    assert all(c["holds"] for c in t["claims"] if not c["id"].startswith("S"))
    assert all(c["holds"] is None for c in t["claims"] if c["id"].startswith("S"))   # the paper never ran LSED


# ------------------------------------------------------------------ end to end
def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close()
    return p


def _fake_weights(root: Path):
    for m in ("Qwen2.5-7B-Instruct", "bge-large-en-v1.5"):
        d = root / m; d.mkdir(parents=True)
        (d / "config.json").write_text("{}")
        h = json.dumps({"__metadata__": {}}).encode()       # a valid, empty safetensors file
        (d / "model.safetensors").write_bytes(len(h).to_bytes(8, "little") + h)


def _env(tmp_path):
    fake = ROOT / "tests" / "fake_gpu"
    return dict(os.environ, PATH=f"{fake / 'bin'}:{os.environ['PATH']}", PYTHONPATH=str(fake),
                PAL_FAKE_EMBED="1", PAL_MODELS_DIR=str(tmp_path / "models"), PAL_VLLM_PORT=str(_free_port()),
                MEM0_TELEMETRY="False")


@pytest.mark.skipif(importlib.util.find_spec("lightrag") is None or importlib.util.find_spec("mem0") is None,
                    reason="needs lightrag-hku and mem0ai (requirements-real.txt)")
def test_one_click_quick_profile(tmp_path):
    _fake_weights(tmp_path / "models")
    env = _env(tmp_path)
    gpy = os.environ.get("PAL_GRAPHRAG_PYTHON")
    systems = ["lightrag-mem0"] + (["graphrag"] if gpy and Path(gpy).exists() else [])
    out = tmp_path / "out"
    cmd = [sys.executable, "scripts/real_all.py", "--profile", "quick", "--out", str(out), "--skip-tests",
           "--emb-port", str(_free_port()), "--systems", *systems] + (["--graphrag-python", gpy] if "graphrag" in systems else [])

    dry = subprocess.run(cmd + ["--dry-run"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
    assert dry.returncode == 0 and "preflight ok" in dry.stdout and "--smoke-only" in dry.stdout, dry.stdout + dry.stderr

    r = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, timeout=1800)
    assert r.returncode == 0, r.stdout[-4000:] + r.stderr[-2000:]
    st = json.load(open(out / "status.json"))["stages"]
    assert all(st[s]["state"] == "ok" for s in systems + ["preflight", "report"]), st
    t = json.load(open(out / "table5.json"))
    held = {c["id"]: c["holds"] for c in t["claims"]}
    # every model-independent claim is checked at smoke scale and holds with the real libraries,
    # including LSED closing every channel in all three systems
    for cid in ["R0", "R1", "M1", "M2", "S3", "S4", "S5"] + (["G1", "G2", "S1", "S2"] if "graphrag" in systems else []):
        assert held[cid] is True, (cid, t["claims"])
    assert (out / "REPORT.md").exists() and (out / "logs" / "lightrag-mem0" / "real_smoke.log").exists()
    # the Mem0 zombie run used its own population (--zombie-subjects-per-manager 10)
    meta = json.load(open(out / "real_quick" / "meta.json"))
    assert meta["args"]["zombie_subjects_per_manager"] == 10 and meta["args"]["subjects_per_manager"] == 1
    assert "benign_after" in json.load(open(out / "real_quick" / "mem0_zombie.json"))["summary"]["user/ref"]

    # resuming: finished stages are skipped, no server is started again
    r2 = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, timeout=600)
    assert r2.returncode == 0 and "vLLM:" not in r2.stdout, r2.stdout[-3000:]
    assert all(f"{s}: outputs complete, skipping" in r2.stdout for s in systems)


@pytest.mark.skipif(not os.environ.get("PAL_GRAPHITI_PYTHON") or not Path(os.environ["PAL_GRAPHITI_PYTHON"]).exists()
                    or importlib.util.find_spec("openai") is None,
                    reason="needs PAL_GRAPHITI_PYTHON (requirements-graphiti.txt) and openai")
def test_one_click_followups_quick(tmp_path):
    """The follow-up stages (Graphiti, HotpotQA) through real_all at smoke scale, and their report."""
    _fake_weights(tmp_path / "models")
    env = _env(tmp_path)
    out = tmp_path / "out"
    cmd = [sys.executable, "scripts/real_all.py", "--profile", "quick", "--out", str(out), "--skip-tests",
           "--emb-port", str(_free_port()), "--systems", "graphiti", "hotpotqa", "timing",
           "--graphiti-python", os.environ["PAL_GRAPHITI_PYTHON"], "--hotpot-data", str(ROOT / "tests" / "data" / "hotpot_tiny.json")]
    r = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, timeout=1800)
    assert r.returncode == 0, r.stdout[-4000:] + r.stderr[-2000:]
    st = json.load(open(out / "status.json"))["stages"]
    assert st["graphiti"]["state"] == "ok" and st["hotpotqa"]["state"] == "ok" and st["timing"]["state"] == "skipped_profile", st
    assert st["report"]["state"] == "ok", st
    ex = json.load(open(out / "extra.json"))
    held = {c["id"]: c["holds"] for c in ex["claims"]}
    assert set(ex["found"]) >= {"graphiti", "hotpot"}
    for cid in ("X0", "X2", "X3", "X4", "X5", "H1"):
        assert held[cid] is True, (cid, ex["claims"])
    assert not (out / "REPORT.md").exists()          # no Table 5 results in this run, so no Table 5 report


def test_preflight_refuses_without_gpu(tmp_path):
    _fake_weights(tmp_path / "models")
    env = _env(tmp_path)
    env["PATH"] = "/usr/bin:/bin"                         # no nvidia-smi
    r = subprocess.run([sys.executable, "scripts/real_all.py", "--out", str(tmp_path / "o"), "--systems", "lightrag-mem0"],
                       cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
    assert r.returncode != 0 and "no NVIDIA GPU visible" in r.stdout
    assert "nothing was started" in r.stderr


@pytest.mark.skipif(importlib.util.find_spec("lightrag") is None or importlib.util.find_spec("mem0") is None,
                    reason="needs lightrag-hku and mem0ai (requirements-real.txt)")
def test_lsed_only_adds_to_an_existing_run(tmp_path):
    """The flow for results that predate LSED: a run without it, then `--lsed only` beside it;
    the report merges both, and the first run's files are left untouched."""
    _fake_weights(tmp_path / "models")
    env = _env(tmp_path)
    out = tmp_path / "out"
    base = [sys.executable, "scripts/real_all.py", "--profile", "quick", "--out", str(out), "--skip-tests",
            "--systems", "lightrag-mem0"]
    r = subprocess.run(base + ["--lsed", "skip"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=1200)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-1500:]
    first = (out / "real_quick" / "lightrag.json").read_bytes()
    assert "lsed" not in json.loads(first)["summary"]["recovery"]
    held = {c["id"]: c["holds"] for c in json.load(open(out / "table5.json"))["claims"]}
    assert held["S3"] is None and held["S4"] is None                 # not run yet

    r = subprocess.run(base + ["--lsed", "only"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=1200)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-1500:]
    assert (out / "real_quick" / "lightrag.json").read_bytes() == first   # existing results untouched
    lsed = json.load(open(out / "real_lsed_quick" / "lightrag.json"))["summary"]
    assert set(lsed["recovery"]) == {"lsed"} and lsed["counterfactual"] == {}
    t = json.load(open(out / "table5.json"))
    held = {c["id"]: c["holds"] for c in t["claims"]}
    assert held["S3"] is True and held["S4"] is True and held["S5"] is True, t["claims"]
    assert held["M2"] is True                                         # baseline claims still from the first run
    st = json.load(open(out / "status.json"))["stages"]
    assert st["lightrag-mem0"]["state"] == "ok" and st["lightrag-mem0-lsed"]["state"] == "ok"
    rep = (out / "REPORT.md").read_text()
    assert "LightRAG + LSED (P5)" in rep and "Mem0 + LSED, `delete_all` (P1, P5)" in rep
