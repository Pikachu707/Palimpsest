"""End-to-end plumbing of the Graphiti experiment against the stub LLM. Graphiti lives in its own
virtualenv, so this runs only when PAL_GRAPHITI_PYTHON points at a python that has it. The stub
is a faithful extractor and summarizer; the assertions are about Graphiti's own deletion code."""
import json, os, subprocess, sys, threading
import pytest
PY = os.environ.get("PAL_GRAPHITI_PYTHON")
if not PY or subprocess.run([PY, "-c", "import graphiti_core, redislite"], capture_output=True).returncode:
    pytest.skip("PAL_GRAPHITI_PYTHON with graphiti-core and falkordblite not available", allow_module_level=True)
sys.path.insert(0, os.path.dirname(__file__))
import stub_openai


def test_graphiti_quick_pipeline(tmp_path):
    os.environ["PAL_FAKE_EMBED"] = "1"
    from palimpsest.real import embed_server, common
    common.FAKE_EMBED = True
    srv, url = stub_openai.start()
    es = embed_server.serve(0); threading.Thread(target=es.serve_forever, daemon=True).start()
    env = dict(os.environ, PAL_LLM_BASE_URL=url, PAL_LLM_MODEL="stub", PAL_GRAPHITI_PYTHON=PY,
               PAL_EMB_BASE_URL=f"http://127.0.0.1:{es.server_address[1]}/v1", PYTHONPATH=os.getcwd())
    r = subprocess.run([sys.executable, "-m", "palimpsest.experiments.graphiti_exp", "--quick", "--parallel", "4",
                        "--out", str(tmp_path / "g")], env=env, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stderr[-2000:]
    s = json.load(open(f"{tmp_path}/g_quick/graphiti.json"))["summary"]
    rec, zom = s["recovery"], s["zombie"]
    assert s["invalid_worlds"] == []
    assert all(rec[c]["live"] == 1.0 for c in rec)
    # remove_episode deletes the episodes' own edges and nodes and rebuilds the surviving entity
    # summaries, but leaves the community summaries: only they still return the deleted facts
    assert rec["native"]["channels_after"] == {"edges": 0.0, "nodes": 0.0, "communities": 1.0}
    assert rec["native"]["at_rest_stores"] == ["community_summaries"]
    assert rec["native_rebuild"]["context"] == 0.0 and rec["native_rebuild"]["at_rest_stores"] == []
    # the poison invalidated the true employer edge; deleting the poison does not restore it,
    # with or without a community rebuild; LSED's lineage does
    for c in ("native", "native_rebuild", "lsed"):
        assert zom[c]["n_invalidated"] == 1
    assert zom["native"]["still_invalid_after"] == 1 and zom["native_rebuild"]["still_invalid_after"] == 1
    assert zom["lsed"]["still_invalid_after"] == 0
    assert rec["lsed"]["context"] == 0.0 and rec["lsed"]["at_rest_stores"] == [] and zom["lsed"]["at_rest_stores"] == []
    assert s["counterfactual"]["recovery"] == 0.0 and s["counterfactual"]["true_edge_valid"] == 1.0
