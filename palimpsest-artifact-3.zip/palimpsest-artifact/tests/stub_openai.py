"""Minimal OpenAI-compatible chat server for plumbing tests (no GPU, no network).

It is NOT a language model: it emits LightRAG's extraction format for the synthetic
canary sentences, keyword JSON for LightRAG queries, a JSON fact list for Mem0, and
otherwise echoes. It lets tests drive the real LightRAG/Mem0 code paths end to end.
"""
import http.server, json, re, threading

_NAME = r"[A-Z][a-z]+ [A-Z][a-z]+-\d{4,5}"
_FACT = re.compile(rf"({_NAME}) (lives at unit|holds clearance code|uses device serial|works at|"
                   rf"is associated with|has employee id|drives vehicle|owns account) ([A-Z0-9]{{12}})")
_REPORTS = re.compile(rf"({_NAME}) reports to ({_NAME})")
T = "<|#|>"


def _lightrag_extract(text):
    """LightRAG's line format: entities (person, manager) and a reports-to relation."""
    people, out = {}, []
    for m in _FACT.finditer(text):
        people.setdefault(m.group(1), []).append(f"{m.group(2)} {m.group(3)}")
    for who, mgr in _REPORTS.findall(text):
        people.setdefault(who, [])
        out.append(f"entity{T}{mgr}{T}person{T}{mgr} is a manager.")
        out.append(f"relation{T}{who}{T}{mgr}{T}reports to{T}{who} reports to {mgr}.")
    for who, facts in people.items():
        out.insert(0, f"entity{T}{who}{T}person{T}{who} is an employee who " + "; ".join(facts) + ".")
    return "\n".join(out + ["<|COMPLETE|>"])


G = "<|>"


def _graphrag_extract(text):
    """GraphRAG's tuple format: ("entity"<|>NAME<|>TYPE<|>DESC)##...<|COMPLETE|>."""
    people, recs = {}, []
    for m in _FACT.finditer(text):
        people.setdefault(m.group(1), []).append(f"{m.group(2)} {m.group(3)}")
    for who, mgr in _REPORTS.findall(text):
        people.setdefault(who, [])
        recs.append(f'("entity"{G}{mgr.upper()}{G}PERSON{G}{mgr} is a manager.)')
        recs.append(f'("relationship"{G}{who.upper()}{G}{mgr.upper()}{G}{who} reports to {mgr}.{G}8)')
    for who, facts in people.items():
        recs.insert(0, f'("entity"{G}{who.upper()}{G}PERSON{G}{who} is an employee who ' + "; ".join(facts) + ".)")
    return "##".join(recs) + "<|COMPLETE|>"


# --------------------------------------------------------------------------------------
# Structured output (json_schema requests): Graphiti, Cognee, A-MEM. The stub copies
# canary sentences into whatever structure is asked for, i.e. it behaves like a perfectly
# faithful extractor and summarizer. That exercises every derived-artifact code path of
# the real libraries; how much a real model copies is what the GPU runs measure.
_TOKEN = re.compile(r"\b[A-Z0-9]{12}\b")


def _content(m):
    c = m.get("content") or ""
    return c if isinstance(c, str) else " ".join(p.get("text", "") for p in c if isinstance(p, dict))


def _sentences(text):
    return [s.strip() for s in re.split(r"(?<=\.)\s+|\n+", text or "") if s.strip()]


def _canary_facts(text):
    """(person, value, sentence) for every sentence that ties a named person to a canary value."""
    out = []
    for s in _sentences(text):
        for who in re.findall(_NAME, s):
            for v in _TOKEN.findall(s):
                out.append((who, v, s.rstrip(".") + "."))
    return out


def _between(text, tag):
    m = re.search(rf"<{tag}>\s*(.*?)\s*</{tag}>", text or "", re.S)
    return m.group(1) if m else ""


def _schema_fill(s, defs):
    """Smallest object that validates against a JSON schema (fallback for unknown models)."""
    if "$ref" in s:
        return _schema_fill(defs[s["$ref"].split("/")[-1]], defs)
    for k in ("anyOf", "oneOf"):
        if k in s:
            opts = [o for o in s[k] if o.get("type") != "null"] or s[k]
            return None if any(o.get("type") == "null" for o in s[k]) else _schema_fill(opts[0], defs)
    t = s.get("type")
    if t == "object":
        return {k: _schema_fill(v, defs) for k, v in s.get("properties", {}).items() if k in s.get("required", [])}
    return {"array": [], "string": "", "integer": 0, "number": 0, "boolean": False}.get(t)


def _graphiti(name, text):
    if name == "ExtractedEntities":
        cur = _between(text, "CURRENT MESSAGE") or _between(text, "TEXT") or _between(text, "JSON") or text
        ents = list(dict.fromkeys(re.findall(_NAME, cur) + [v for _, v, _ in _canary_facts(cur)]))
        return {"extracted_entities": [{"name": e, "entity_type_id": 0, "episode_indices": [0]} for e in ents]}
    if name == "ExtractedEdges":
        cur, known = _between(text, "CURRENT_MESSAGE"), set(re.findall(r'"name": "([^"]+)"', _between(text, "ENTITIES")))
        # an ongoing fact is valid from the episode's time, as the extraction prompt instructs
        ref = _between(text, "REFERENCE_TIME").split("#")[0].strip()
        ref = ref.replace(" ", "T", 1).replace("+00:00", "Z") if ref else None
        edges = [{"source_entity_name": w, "target_entity_name": v, "relation_type": "HAS_RECORD", "fact": s,
                  "valid_at": ref, "invalid_at": None, "episode_indices": [0]}
                 for w, v, s in _canary_facts(cur) if w in known and v in known]
        edges += [{"source_entity_name": w, "target_entity_name": m, "relation_type": "REPORTS_TO",
                   "fact": f"{w} reports to {m}.", "valid_at": ref, "invalid_at": None, "episode_indices": [0]}
                  for w, m in _REPORTS.findall(cur) if w in known and m in known]
        return {"edges": edges}
    if name == "NodeResolutions":
        new = re.findall(r'"id": (\d+), "name": "([^"]+)"', _between(text, "ENTITIES"))
        old = {n: int(i) for i, n in re.findall(r'"candidate_id": (\d+), "name": "([^"]+)"', _between(text, "EXISTING ENTITIES"))}
        return {"entity_resolutions": [{"id": int(i), "name": n, "duplicate_candidate_id": old.get(n, -1)} for i, n in new]}
    if name == "EdgeDuplicate":
        new = _between(text, "NEW FACT").strip()
        def facts(x):                                  # Graphiti lists facts as Python reprs or JSON
            return [(int(i), f) for i, f in re.findall(r"""['"]idx['"]: (\d+), ['"]fact['"]: ['"](.*?)['"]\}""", x)]
        dup = [i for i, f in facts(_between(text, "EXISTING FACTS")) if f and f.rstrip(".") == new.rstrip(".")]
        # one employer at a time: "X works at A" contradicts "X works at B"
        m = re.match(rf"({_NAME}) (?:now )?works at (\w+)", new)
        con = [i for i, f in facts(_between(text, "FACT INVALIDATION CANDIDATES"))
               if m and (k := re.match(rf"({_NAME}) (?:now )?works at (\w+)", f)) and k[1] == m[1] and k[2] != m[2]]
        return {"duplicate_facts": dup, "contradicted_facts": con}
    if name == "Summary":                              # community summaries: merge the members' summaries
        arr = re.search(r"Summaries:\s*(\[.*\])", text, re.S)
        try:
            parts = [x.get("summary", "") for x in json.loads(arr.group(1))] if arr else []
        except Exception:
            parts = []
        return {"summary": " ".join(dict.fromkeys(x.strip(' "') for p in parts for x in _sentences(p) if x.strip(' "')))}
    if name == "SummaryDescription":
        return {"description": "Facts about people and their records."}
    if name == "SummarizedEntities":
        msgs = (_between(text, "MESSAGES") or _between(text, "EPISODES") or text).replace("\\n", "\n")
        ents = re.findall(r'"name": "([^"]+)", "summary": "((?:[^"\\]|\\.)*)"', _between(text, "ENTITIES"))
        def upd(n, old):                              # newest facts first, as the 1000-character cap drops the tail
            old = json.loads(f'"{old}"')
            new = [x for x in dict.fromkeys(s for s in _sentences(msgs) if n in s) if x not in old]
            return (" ".join(reversed(new)) + " " + old).strip()[:1000]
        return {"summaries": [{"name": n, "summary": upd(n, old)} for n, old in ents]}
    return None


def _cognee(title, user):
    """Cognee asks for JSON in the prompt (litellm json_object mode) and names the model."""
    facts = _canary_facts(user)
    if title == "KnowledgeGraph":
        people = list(dict.fromkeys(re.findall(_NAME, user)))
        nodes = [{"id": p, "name": p, "type": "Person",
                  "description": " ".join(s for s in _sentences(user) if p in s)} for p in people]
        nodes += [{"id": v, "name": v, "type": "Identifier", "description": s} for _, v, s in facts]
        edges = [{"source_node_id": w, "target_node_id": v, "relationship_name": "has_record", "description": s}
                 for w, v, s in facts]
        edges += [{"source_node_id": w, "target_node_id": m, "relationship_name": "reports_to",
                   "description": f"{w} reports to {m}."} for w, m in _REPORTS.findall(user)]
        return {"nodes": nodes, "edges": edges}
    if title == "SummarizedContent":
        people = ", ".join(dict.fromkeys(re.findall(_NAME, user)))
        return {"summary": f"This chunk is about:\n- People: {people}\nFacts:\n"
                           + "\n".join(f"- {s}" for s in _sentences(user)), "description": ""}
    return None


def _amem(schema, text):
    """A-MEM: note construction and memory evolution (both named "response")."""
    props = set((schema or {}).get("properties", {}))
    if {"keywords", "context", "tags"} <= props:
        content = text.split("Content for analysis:")[-1].strip()
        return {"keywords": list(dict.fromkeys(re.findall(_NAME, content) + _TOKEN.findall(content))) or ["record"],
                "context": " ".join(_sentences(content)), "tags": ["employee", "record"]}
    if "should_evolve" in props:
        n = int((re.search(r"number of neighbors is (\d+)", text) or [0, 0])[1])
        new = text.split("content:", 1)[1].split("keywords:", 1)[0] if "content:" in text else ""
        olds = re.findall(r"memory context: (.*?)\tmemory keywords", text)
        tags = [json.loads(t.replace("'", '"')) if t.startswith("[") else [] for t in re.findall(r"memory tags: (\[.*?\])", text)]
        add = " ".join(s for _, _, s in _canary_facts(new))
        return {"should_evolve": True, "actions": ["strengthen", "update_neighbor"], "suggested_connections": [],
                "tags_to_update": ["employee", "record"],
                "new_context_neighborhood": [((olds[i] if i < len(olds) else "") + " " + add).strip() for i in range(n)],
                "new_tags_neighborhood": [tags[i] if i < len(tags) else [] for i in range(n)]}
    return None


def _schema(body):
    js = ((body or {}).get("response_format") or {}).get("json_schema") or {}
    return js.get("name", ""), js.get("schema") or {}


def _structured(body, messages):
    """A known response model -> faithful JSON; otherwise None (the caller falls through)."""
    name, schema = _schema(body)
    text = "\n".join(_content(m) for m in messages)
    out = _graphiti(name, text)
    if out is None and name == "response":
        out = _amem(schema, text)
    if out is None:                                   # schema embedded in the prompt (json_object mode)
        m = re.search(r"conforming to this schema:\s*```json\s*(\{.*?\})\s*```", text, re.S)
        if m:
            user = next((_content(x) for x in reversed(messages) if x["role"] == "user"), "")
            out = _cognee(json.loads(m.group(1)).get("title", ""), user)
            if out is None:
                sch = json.loads(m.group(1)); out = _schema_fill(sch, sch.get("$defs", {}))
    return None if out is None else json.dumps(out)


def _answer(messages, body=None):
    out = _structured(body, messages) if body else None
    if out is not None:
        return out
    text_out = _answer_text(messages, body)
    name, schema = _schema(body)
    if schema and not text_out.lstrip().startswith(("{", "[")):    # unknown model: schema-minimal JSON
        return json.dumps(_schema_fill(schema, schema.get("$defs", {})))
    return text_out


_CAP = re.compile(r"\b[A-Z][a-z]+(?: [A-Z][a-z]+)+\b")


def _hotpot(system, text):
    """The HotpotQA quality experiment (palimpsest/experiments/hotpot_quality.py)."""
    sents = _sentences(text.split("Question:")[0])
    if "HOTPOT-NATIVE" in system:
        names = list(dict.fromkeys(_CAP.findall(text)))
        return "\n".join(f"{n} | " + " ".join(x for x in sents if n in x) for n in names)
    if "HOTPOT-ATOMS" in system:
        out = []
        for x in sents:
            ns = list(dict.fromkeys(_CAP.findall(x)))
            out += [f"{ns[0]}; mentioned with; {o}" for o in ns[1:]] if ns else []
            out += [f"{ns[0]}; states; {x.rstrip('.')}"] if ns else []
        return "\n".join(out)
    if "HOTPOT-MERGE" in system or "HOTPOT-RENDER" in system:
        return " ".join(l.lstrip("- ") for l in text.splitlines() if l.startswith("- "))
    if "HOTPOT-ANSWER" in system:
        q = text.split("Question:")[-1]
        cand = [n for n in _CAP.findall(text.split("Question:")[0]) if n not in q]
        return cand[0] if cand else "yes"
    return None


def _answer_text(messages, body=None):
    user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    system = " ".join(m["content"] for m in messages if m["role"] == "system")
    if "HOTPOT-" in system:
        return _hotpot(system, user if isinstance(user, str) else json.dumps(user)) or ""
    text = user if isinstance(user, str) else json.dumps(user)
    low = (system + text).lower()
    if body and body.get("response_format") and "findings" in low and "rating" in low:   # GraphRAG community report only
        return json.dumps({"title": "Community", "summary": text[-300:], "rating": 1.0, "rating_explanation": "stub",
                           "findings": [{"summary": "stub finding", "explanation": text[-200:]}]})
    if any(m["role"] == "assistant" for m in messages) and (T in system + text or G in system + text):
        return "N" if "Y or N" in text or "Y/N" in text else "<|COMPLETE|>"   # gleaning: nothing new
    if G in system + text and T not in system + text and '"entity"' in system + text:
        return _graphrag_extract(text)
    if any(m["role"] == "assistant" for m in messages) and T in system + text:
        return "<|COMPLETE|>"                                   # gleaning round: nothing new
    if T in system + text and "entity" in (system + text):
        return _lightrag_extract(text)
    if "high_level_keywords" in system + text:
        names = re.findall(_NAME, text)
        return json.dumps({"high_level_keywords": ["employee"], "low_level_keywords": names[:5] or ["employee"]})
    if "json" in (system + text).lower() and ("fact" in (system + text).lower() or "memory" in (system + text).lower()):
        # Mem0: extract from New Messages; like the prompt says, use Last k Messages only to
        # resolve references, i.e. when the new message points back at earlier ones.
        sec = dict(re.findall(r"## ([^\n]+)\n(.*?)(?=\n## |\n# Output|\Z)", text, re.S))
        src = sec.get("New Messages", text)
        if "New Messages" in sec and re.search(r"\b(earlier|mentioned|before|previous(ly)?)\b", src, re.I):
            src += "\n" + sec.get("Last k Messages", "")
        sents = list(dict.fromkeys(s.strip(' "\'') for s in re.split(r"(?<=\.)\s+|\n+", src)
                                   if re.search(r"\b[A-Z0-9]{12}\b", s)))
        return json.dumps({"memory": [{"id": str(i), "text": s, "attributed_to": "user"} for i, s in enumerate(sents)],
                           "facts": sents})
    # A faithful answerer: every canary fact in the prompt about a person the question names.
    asked = set(re.findall(_NAME, user if isinstance(user, str) else text))
    known = list(dict.fromkeys(s for w, _, s in _canary_facts(system + "\n" + text) if w in asked))
    return "STUB ANSWER: " + " ".join(known) + " " + (system[-1500:] if "Data tables" in system or "---Data" in system else text[-400:])


class _H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if body.get("stream"):                                     # GraphRAG's local search streams
            text = _answer(body["messages"], body)
            self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.end_headers()
            for piece in [text[i:i + 64] for i in range(0, len(text), 64)] or [""]:
                chunk = {"id": "x", "object": "chat.completion.chunk", "created": 0, "model": body.get("model", "stub"),
                         "choices": [{"index": 0, "delta": {"role": "assistant", "content": piece}, "finish_reason": None}]}
                self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
            end = {"id": "x", "object": "chat.completion.chunk", "created": 0, "model": body.get("model", "stub"),
                   "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]}
            self.wfile.write(f"data: {json.dumps(end)}\n\ndata: [DONE]\n\n".encode())
            return
        out = {"id": "x", "object": "chat.completion", "created": 0, "model": body.get("model", "stub"),
               "choices": [{"index": 0, "finish_reason": "stop",
                            "message": {"role": "assistant", "content": _answer(body["messages"], body)}}],
               "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}}
        b = json.dumps(out).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        b = json.dumps({"data": [{"id": "stub"}]}).encode()
        self.send_response(200); self.end_headers(); self.wfile.write(b)

    def log_message(self, *a):
        pass


def start():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}/v1"
