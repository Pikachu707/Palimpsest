"""Plumbing of the HotpotQA quality experiment against the stub LLM on a tiny invented
HotpotQA-format file. Scores are meaningless with the stub; the test checks the pipeline and
LSED's history independence (after deletion it equals the counterfactual)."""
import json, os, subprocess, sys
import pytest
pytest.importorskip("openai")
sys.path.insert(0, os.path.dirname(__file__))
import stub_openai

HERE = os.path.dirname(__file__)


def test_hotpot_quick(tmp_path):
    srv, url = stub_openai.start()
    env = dict(os.environ, PAL_LLM_BASE_URL=url, PAL_LLM_MODEL="stub", PAL_FAKE_EMBED="1", PYTHONPATH=os.getcwd())
    r = subprocess.run([sys.executable, "-m", "palimpsest.experiments.hotpot_quality", "--data",
                        os.path.join(HERE, "data", "hotpot_tiny.json"), "--n-questions", "4", "--k", "3",
                        "--delete-frac", "0.25", "--out", str(tmp_path / "h")], env=env, capture_output=True, text=True, timeout=600)
    assert r.returncode == 0, r.stderr[-2000:]
    s = json.load(open(tmp_path / "h" / "hotpot.json"))["summary"]
    assert set(s["before"]["scores"]) == {"chunks", "native+chunks", "lsed+chunks", "native_only", "lsed_only"}
    assert s["build"]["paragraphs_without_facts"] == 0 and s["build"]["lsed_entities"] > 0
    a = s["after"]
    assert a["deleted_paragraphs"] == 2 and a["lsed_entity_sets_equal"]
    same, total = a["lsed_vs_cf_identical_descriptions"]
    assert same == total > 0
    assert 0 < a["cost"]["lsed_rerender_calls"] < a["cost"]["full_rebuild_calls"]
