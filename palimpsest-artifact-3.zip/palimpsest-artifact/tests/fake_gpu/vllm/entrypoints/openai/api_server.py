import argparse, http.server, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))   # tests/
import stub_openai

ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True); ap.add_argument("--port", type=int, required=True)
a, _ = ap.parse_known_args()          # ignore --gpu-memory-utilization, --max-model-len, ...


class H(stub_openai._H):
    def do_GET(self):                  # /v1/models must name the served model, as vLLM does
        b = json.dumps({"data": [{"id": a.model}]}).encode()
        self.send_response(200); self.end_headers(); self.wfile.write(b)


print(f"fake vLLM serving {a.model} on :{a.port}", flush=True)
http.server.ThreadingHTTPServer(("127.0.0.1", a.port), H).serve_forever()
