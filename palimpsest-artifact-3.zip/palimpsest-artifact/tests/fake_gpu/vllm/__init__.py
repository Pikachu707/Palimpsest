"""Stand-in for vLLM in tests of the one-click pipeline (scripts/real_all.py): no GPU, no model.
`python -m vllm.entrypoints.openai.api_server --model M --port P` serves tests/stub_openai.py
under the model id M, exactly the contract the drivers check."""
__version__ = "0.30.0+fake"
